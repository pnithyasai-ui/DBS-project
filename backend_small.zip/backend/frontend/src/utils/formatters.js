// Frontend formatting and configuration utilities

export const BUDGET_OPTIONS = [
    { id: '', label: 'Any Budget' },
    { id: 'under_25_lakhs', label: 'Under ₹25 Lakhs' },
    { id: '25_50_lakhs', label: '₹25 Lakhs – ₹50 Lakhs' },
    { id: '50_75_lakhs', label: '₹50 Lakhs – ₹75 Lakhs' },
    { id: '75_lakhs_1_crore', label: '₹75 Lakhs – ₹1 Crore' },
    { id: '1_2_crore', label: '₹1 Crore – ₹2 Crore' },
    { id: '2_5_crore', label: '₹2 Crore – ₹5 Crore' },
    { id: '5_crore_plus', label: '₹5 Crore+' }
];

export const PROPERTY_TYPES = [
    'All Types',
    'Apartment',
    'Villa',
    'House',
    'Residential Plot',
    'Agricultural Land',
    'Commercial Plot',
    'Office',
    'Shop',
    'Warehouse'
];

export const CATEGORY_CARDS = [
    { title: 'Apartments', type: 'Apartment', icon: '🏢', desc: 'Modern flats & luxury high-rises' },
    { title: 'Villas', type: 'Villa', icon: '🏡', desc: 'Gated enclaves & duplex villas' },
    { title: 'Houses', type: 'House', icon: '🏠', desc: 'Independent homes & bungalows' },
    { title: 'Lands & Plots', type: 'Lands & Plots', icon: '🌳', desc: 'Residential & agricultural lands' },
    { title: 'Commercial', type: 'Commercial', icon: '🏬', desc: 'Offices, shops & warehouses' }
];

export const POPULAR_LOCATIONS = [
    'Hyderabad',
    'Gachibowli',
    'Kondapur',
    'Madhapur',
    'Bachupally',
    'Kukatpally',
    'Miyapur',
    'Nizampet',
    'Manikonda',
    'Secunderabad'
];

export function formatIndianPrice(amount) {
    if (amount === null || amount === undefined || isNaN(amount)) return '₹0';
    const num = Number(amount);
    if (num >= 10000000) {
        const cr = (num / 10000000).toFixed(2).replace(/\.00$/, '');
        return `₹${cr} Crore`;
    } else if (num >= 100000) {
        const lk = (num / 100000).toFixed(2).replace(/\.00$/, '');
        return `₹${lk} Lakhs`;
    } else {
        return `₹${num.toLocaleString('en-IN')}`;
    }
}

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { CompareProvider } from './context/CompareContext';
import Navbar from './layouts/Navbar';
import Footer from './layouts/Footer';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';

// Pages
import Home from './pages/Home';
import Properties from './pages/Properties';
import PropertyDetails from './pages/PropertyDetails';
import CompareProperties from './pages/CompareProperties';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import Favorites from './pages/Favorites';
import MyEnquiries from './pages/MyEnquiries';
import UserDashboard from './pages/UserDashboard';
import OwnerDashboard from './pages/OwnerDashboard';
import AgentDashboard from './pages/AgentDashboard';
import ManageProperties from './pages/ManageProperties';
import AddEditProperty from './pages/AddEditProperty';
import PropertyEnquiries from './pages/PropertyEnquiries';
import DatabaseDesign from './pages/DatabaseDesign';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import PropertyVerification from './pages/admin/PropertyVerification';
import UserManagement from './pages/admin/UserManagement';
import ActivityMonitoring from './pages/admin/ActivityMonitoring';
import AdminAnalytics from './pages/admin/AdminAnalytics';

export default function App() {
    return (
        <ToastProvider>
            <AuthProvider>
                <CompareProvider>
                    <BrowserRouter>
                        <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
                            <Navbar />
                            <main className="main-content">
                                <Routes>
                                    {/* Public Routes */}
                                    <Route path="/" element={<Home />} />
                                    <Route path="/properties" element={<Properties />} />
                                    <Route path="/properties/:id" element={<PropertyDetails />} />
                                    <Route path="/compare" element={<CompareProperties />} />
                                    <Route path="/login/:role" element={<Login />} />
                                    <Route path="/login" element={<Navigate to="/login/user" replace />} />
                                    <Route path="/register" element={<Register />} />
                                    <Route path="/database-design" element={<DatabaseDesign />} />

                                    {/* Protected Common Routes */}
                                    <Route path="/profile" element={
                                        <ProtectedRoute>
                                            <Profile />
                                        </ProtectedRoute>
                                    } />

                                    {/* User / Buyer Protected Routes */}
                                    <Route path="/favorites" element={
                                        <ProtectedRoute allowedRoles={['user', 'owner', 'agent', 'admin']}>
                                            <Favorites />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/my-enquiries" element={
                                        <ProtectedRoute allowedRoles={['user', 'owner', 'agent', 'admin']}>
                                            <MyEnquiries />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/dashboard" element={
                                        <ProtectedRoute allowedRoles={['user', 'owner', 'agent', 'admin']}>
                                            <UserDashboard />
                                        </ProtectedRoute>
                                    } />

                                    {/* Owner / Agent Protected Routes */}
                                    <Route path="/owner-dashboard" element={
                                        <ProtectedRoute allowedRoles={['owner', 'admin']}>
                                            <OwnerDashboard />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/agent-dashboard" element={
                                        <ProtectedRoute allowedRoles={['agent', 'admin']}>
                                            <AgentDashboard />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/my-properties" element={
                                        <ProtectedRoute allowedRoles={['owner', 'agent', 'admin']}>
                                            <ManageProperties />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/add-property" element={
                                        <ProtectedRoute allowedRoles={['owner', 'agent', 'admin']}>
                                            <AddEditProperty />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/edit-property/:id" element={
                                        <ProtectedRoute allowedRoles={['owner', 'agent', 'admin']}>
                                            <AddEditProperty />
                                        </ProtectedRoute>
                                    } />
                                    <Route path="/property-enquiries" element={
                                        <ProtectedRoute allowedRoles={['owner', 'agent', 'admin']}>
                                            <PropertyEnquiries />
                                        </ProtectedRoute>
                                    } />

                                    {/* Admin Protected Routes */}
                                    <Route path="/admin" element={
                                        <AdminRoute>
                                            <AdminDashboard />
                                        </AdminRoute>
                                    } />
                                    <Route path="/admin/dashboard" element={
                                        <AdminRoute>
                                            <AdminDashboard />
                                        </AdminRoute>
                                    } />
                                    <Route path="/admin/verification" element={
                                        <AdminRoute>
                                            <PropertyVerification />
                                        </AdminRoute>
                                    } />
                                    <Route path="/admin/users" element={
                                        <AdminRoute>
                                            <UserManagement />
                                        </AdminRoute>
                                    } />
                                    <Route path="/admin/activity" element={
                                        <AdminRoute>
                                            <ActivityMonitoring />
                                        </AdminRoute>
                                    } />
                                    <Route path="/admin/analytics" element={
                                        <AdminRoute>
                                            <AdminAnalytics />
                                        </AdminRoute>
                                    } />

                                    {/* Fallback 404 */}
                                    <Route path="*" element={
                                        <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                                            <div style={{ fontSize: '4rem', fontWeight: '800', color: '#cbd5e1' }}>404</div>
                                            <h2 style={{ fontSize: '1.75rem', marginBottom: '0.75rem' }}>Page Not Found</h2>
                                            <p style={{ color: '#64748b', marginBottom: '1.5rem' }}>
                                                The page you are looking for might have been moved or does not exist.
                                            </p>
                                            <a href="/" className="btn btn-primary">Return to Homepage</a>
                                        </div>
                                    } />
                                </Routes>
                            </main>
                            <Footer />
                        </div>
                    </BrowserRouter>
                </CompareProvider>
            </AuthProvider>
        </ToastProvider>
    );
}

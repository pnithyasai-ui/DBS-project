import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ProtectedRoute({ children, allowedRoles }) {
    const { user, isAuthenticated, loading } = useAuth();

    if (loading) {
        return (
            <div style={{ padding: '4rem', textAlign: 'center' }}>
                <p>Loading session...</p>
            </div>
        );
    }

    if (!isAuthenticated) {
        return <Navigate to="/login/user" replace />;
    }

    if (allowedRoles && !allowedRoles.includes(user.role)) {
        return (
            <div className="container" style={{ padding: '5rem 1.5rem', textAlign: 'center' }}>
                <div style={{ maxWidth: '500px', margin: '0 auto', background: '#ffffff', padding: '3rem', borderRadius: '16px', border: '1px solid #e2e8f0', boxShadow: 'var(--shadow-md)' }}>
                    <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🚫</div>
                    <h2 style={{ fontSize: '1.5rem', marginBottom: '0.75rem', color: '#dc2626' }}>Access Denied</h2>
                    <p style={{ color: '#64748b', marginBottom: '1.5rem' }}>
                        You do not have permission to access this page. This section requires [{allowedRoles.join(', ')}] privileges.
                    </p>
                    <a href="/" className="btn btn-primary">Return to Home</a>
                </div>
            </div>
        );
    }

    return children;
}

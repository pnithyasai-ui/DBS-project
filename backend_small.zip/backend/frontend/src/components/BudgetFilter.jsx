import React from 'react';
import { BUDGET_OPTIONS } from '../utils/formatters';
import { IndianRupee } from 'lucide-react';

export default function BudgetFilter({ value, onChange, isCompact = false }) {
    const selectedOption = BUDGET_OPTIONS.find(b => b.id === value) || BUDGET_OPTIONS[0];

    return (
        <div className="form-group" style={{ marginBottom: 0 }}>
            {!isCompact && (
                <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <IndianRupee size={15} color="#2563eb" />
                    <span>Budget Range</span>
                </label>
            )}
            <select
                className="form-control"
                value={value || ''}
                onChange={(e) => onChange(e.target.value)}
                aria-label="Select Budget"
            >
                {BUDGET_OPTIONS.map((option) => (
                    <option key={option.id} value={option.id}>
                        {option.label}
                    </option>
                ))}
            </select>
            {value && !isCompact && (
                <div style={{ fontSize: '0.8rem', color: '#2563eb', fontWeight: '600', marginTop: '0.2rem' }}>
                    Selected: {selectedOption.label}
                </div>
            )}
        </div>
    );
}

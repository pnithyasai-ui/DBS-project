import React, { useState, useMemo } from 'react';
import { Calculator, IndianRupee, Percent, Calendar, HelpCircle, CheckCircle } from 'lucide-react';
import { formatIndianPrice } from '../utils/formatters';

export default function EmiCalculator({ defaultPropertyPrice }) {
    // Default principal is 80% of property price if available, else 50 Lakhs
    const initialPrice = defaultPropertyPrice ? Math.round(Number(defaultPropertyPrice) * 0.8) : 5000000;

    const [principal, setPrincipal] = useState(initialPrice);
    const [interestRate, setInterestRate] = useState(8.5); // 8.5% p.a.
    const [tenureYears, setTenureYears] = useState(20); // 20 years

    // EMI Calculation
    const { monthlyEmi, totalInterest, totalPayment, principalPercent, interestPercent } = useMemo(() => {
        const p = Number(principal);
        const r = (Number(interestRate) / 12) / 100; // monthly rate
        const n = Number(tenureYears) * 12; // total months

        if (p <= 0 || r <= 0 || n <= 0) {
            return { monthlyEmi: 0, totalInterest: 0, totalPayment: 0, principalPercent: 50, interestPercent: 50 };
        }

        const emi = Math.round((p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1));
        const payment = emi * n;
        const interest = payment - p;

        const pPercent = Math.round((p / payment) * 100);
        const iPercent = 100 - pPercent;

        return {
            monthlyEmi: emi,
            totalInterest: interest,
            totalPayment: payment,
            principalPercent: pPercent,
            interestPercent: iPercent
        };
    }, [principal, interestRate, tenureYears]);

    return (
        <div className="card emi-calculator-card" style={{
            background: '#ffffff',
            borderRadius: '20px',
            border: '1.5px solid var(--border-light)',
            padding: '2rem',
            boxShadow: 'var(--shadow-md)',
            marginTop: '2.5rem'
        }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '0.75rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                    <div style={{
                        width: '42px',
                        height: '42px',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #eff6ff, #dbeafe)',
                        color: 'var(--primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Calculator size={22} />
                    </div>
                    <div>
                        <h3 style={{ fontSize: '1.3rem', fontWeight: '800', color: 'var(--primary-dark)', margin: 0 }}>
                            Home Loan EMI Calculator
                        </h3>
                        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', margin: 0 }}>
                            Estimate your monthly installment based on current Indian bank home loan rates
                        </p>
                    </div>
                </div>
                <div className="role-badge agent" style={{ fontSize: '0.75rem' }}>
                    Bank Rate: ~8.50% p.a.
                </div>
            </div>

            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                gap: '2.5rem',
                alignItems: 'center'
            }}>
                {/* Sliders Input Column */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    {/* Loan Amount */}
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                            <label className="form-label" style={{ fontWeight: '700', marginBottom: 0 }}>
                                Loan Amount (₹)
                            </label>
                            <span style={{ fontWeight: '800', color: 'var(--primary)', fontSize: '1.05rem', fontFamily: 'Outfit' }}>
                                {formatIndianPrice(principal)}
                            </span>
                        </div>
                        <input
                            type="range"
                            min="500000"
                            max="50000000"
                            step="50000"
                            value={principal}
                            onChange={(e) => setPrincipal(Number(e.target.value))}
                            style={{ width: '100%', accentColor: 'var(--primary)' }}
                        />
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.25rem' }}>
                            <span>₹5 Lakhs</span>
                            <span>₹2.5 Crore</span>
                            <span>₹5 Crore</span>
                        </div>
                    </div>

                    {/* Interest Rate */}
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                            <label className="form-label" style={{ fontWeight: '700', marginBottom: 0 }}>
                                Interest Rate (% p.a.)
                            </label>
                            <span style={{ fontWeight: '800', color: 'var(--primary)', fontSize: '1.05rem' }}>
                                {interestRate}%
                            </span>
                        </div>
                        <input
                            type="range"
                            min="6.5"
                            max="15"
                            step="0.1"
                            value={interestRate}
                            onChange={(e) => setInterestRate(Number(e.target.value))}
                            style={{ width: '100%', accentColor: 'var(--primary)' }}
                        />
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.25rem' }}>
                            <span>6.5%</span>
                            <span>10%</span>
                            <span>15%</span>
                        </div>
                    </div>

                    {/* Loan Tenure */}
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                            <label className="form-label" style={{ fontWeight: '700', marginBottom: 0 }}>
                                Loan Tenure
                            </label>
                            <span style={{ fontWeight: '800', color: 'var(--primary)', fontSize: '1.05rem' }}>
                                {tenureYears} Years ({tenureYears * 12} Months)
                            </span>
                        </div>
                        <input
                            type="range"
                            min="1"
                            max="30"
                            step="1"
                            value={tenureYears}
                            onChange={(e) => setTenureYears(Number(e.target.value))}
                            style={{ width: '100%', accentColor: 'var(--primary)' }}
                        />
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.25rem' }}>
                            <span>1 Year</span>
                            <span>15 Years</span>
                            <span>30 Years</span>
                        </div>
                    </div>
                </div>

                {/* Calculation Output Box */}
                <div style={{
                    background: 'linear-gradient(145deg, #f8fafc 0%, #eff6ff 100%)',
                    borderRadius: '18px',
                    padding: '1.75rem',
                    border: '1px solid #dbeafe',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1.25rem'
                }}>
                    {/* Monthly EMI Highlight */}
                    <div style={{ textAlign: 'center', paddingBottom: '1rem', borderBottom: '1px solid #e2e8f0' }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                            Monthly Home Loan EMI
                        </div>
                        <div style={{ fontSize: '2.4rem', fontWeight: '900', color: 'var(--primary)', fontFamily: 'Outfit', marginTop: '0.25rem' }}>
                            ₹{monthlyEmi.toLocaleString('en-IN')}
                        </div>
                        <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
                            per month for {tenureYears} years
                        </span>
                    </div>

                    {/* Ratio Bar */}
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', fontWeight: '700', marginBottom: '0.35rem' }}>
                            <span style={{ color: '#2563eb' }}>Principal: {principalPercent}%</span>
                            <span style={{ color: '#f59e0b' }}>Total Interest: {interestPercent}%</span>
                        </div>
                        <div style={{ width: '100%', height: '10px', background: '#f59e0b', borderRadius: '999px', overflow: 'hidden', display: 'flex' }}>
                            <div style={{ width: `${principalPercent}%`, height: '100%', background: '#2563eb' }} />
                        </div>
                    </div>

                    {/* Cost Breakdown Items */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.9rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', color: '#475569' }}>
                            <span>Principal Amount:</span>
                            <strong style={{ color: '#0f172a' }}>₹{principal.toLocaleString('en-IN')}</strong>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', color: '#475569' }}>
                            <span>Total Interest Payable:</span>
                            <strong style={{ color: '#d97706' }}>₹{totalInterest.toLocaleString('en-IN')}</strong>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', color: '#0f172a', fontWeight: '700', paddingTop: '0.5rem', borderTop: '1px solid #e2e8f0' }}>
                            <span>Total Amount (P + I):</span>
                            <strong style={{ color: 'var(--primary)', fontSize: '1.05rem' }}>₹{totalPayment.toLocaleString('en-IN')}</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

import React, { useState } from 'react';
import BudgetFilter from './BudgetFilter';
import { PROPERTY_TYPES } from '../utils/formatters';
import { Search, RotateCcw, SlidersHorizontal, MapPin, Building, Bed, Bath, Maximize2, ArrowUpDown, ChevronDown, ChevronUp, Check } from 'lucide-react';

const AMENITY_OPTIONS = [
    'Parking',
    'Lift',
    'Security',
    'Garden',
    'Swimming Pool',
    'Gym',
    'Power Backup',
    'CCTV',
    'Club House'
];

export default function PropertyFilterBar({
    filters,
    onFilterChange,
    onClearFilters,
    onSearch
}) {
    const [showAdvanced, setShowAdvanced] = useState(false);

    const isLand = ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(filters.propertyType);
    const isCommercial = ['Office', 'Shop', 'Warehouse'].includes(filters.propertyType);

    const handleInputChange = (field, value) => {
        onFilterChange({ ...filters, [field]: value, page: 1 });
    };

    const handleAmenityToggle = (amenityName) => {
        const currentList = filters.amenities ? filters.amenities.split(',').map(a => a.trim()).filter(Boolean) : [];
        const exists = currentList.includes(amenityName);
        const updated = exists ? currentList.filter(a => a !== amenityName) : [...currentList, amenityName];
        handleInputChange('amenities', updated.join(','));
    };

    const selectedAmenitiesList = filters.amenities ? filters.amenities.split(',').map(a => a.trim()).filter(Boolean) : [];

    return (
        <div style={{
            background: '#ffffff',
            borderRadius: '20px',
            border: '1.5px solid var(--border-light)',
            padding: '1.75rem',
            boxShadow: 'var(--shadow-sm)',
            marginBottom: '2rem'
        }}>
            {/* Category Quick Filter Pills */}
            <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
                {[
                    { label: 'All Listings', type: '' },
                    { label: 'Apartments', type: 'Apartment' },
                    { label: 'Villas', type: 'Villa' },
                    { label: 'Houses', type: 'House' },
                    { label: 'Plots & Land', type: 'Residential Plot' },
                    { label: 'Commercial', type: 'Commercial' }
                ].map(cat => {
                    const isSelected = (!filters.propertyType && !cat.type) || (filters.propertyType === cat.type);
                    return (
                        <button
                            key={cat.label}
                            type="button"
                            onClick={() => handleInputChange('propertyType', cat.type)}
                            style={{
                                border: isSelected ? '1.5px solid var(--primary-light)' : '1px solid var(--border-light)',
                                background: isSelected ? 'var(--primary-surface)' : '#f8fafc',
                                color: isSelected ? 'var(--primary-light)' : 'var(--text-secondary)',
                                padding: '0.4rem 0.85rem',
                                borderRadius: '999px',
                                fontSize: '0.825rem',
                                fontWeight: '700',
                                cursor: 'pointer',
                                transition: 'var(--transition)'
                            }}
                        >
                            {cat.label}
                        </button>
                    );
                })}
            </div>

            {/* Primary Filter Grid: Location, Property Type, Budget, Bedrooms */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
                gap: '1rem',
                alignItems: 'flex-end',
                marginBottom: '1.25rem'
            }}>
                {/* 1. Location with partial match */}
                <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <MapPin size={15} color="#2563eb" />
                        <span>Location / City</span>
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. Hyderabad, Bachupally..."
                        value={filters.location || ''}
                        onChange={(e) => handleInputChange('location', e.target.value)}
                    />
                </div>

                {/* 2. Property Type */}
                <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <Building size={15} color="#2563eb" />
                        <span>Property Type</span>
                    </label>
                    <select
                        className="form-control"
                        value={filters.propertyType || 'All Types'}
                        onChange={(e) => handleInputChange('propertyType', e.target.value === 'All Types' ? '' : e.target.value)}
                    >
                        {PROPERTY_TYPES.map((t) => (
                            <option key={t} value={t}>{t}</option>
                        ))}
                    </select>
                </div>

                {/* 3. Budget (Predefined Indian Range) */}
                <BudgetFilter
                    value={filters.budget || ''}
                    onChange={(val) => handleInputChange('budget', val)}
                />

                {/* 4. Adaptive Specs: Bedrooms for Residential */}
                {!isLand && (
                    <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <Bed size={15} color="#2563eb" />
                            <span>Bedrooms</span>
                        </label>
                        <select
                            className="form-control"
                            value={filters.bedrooms || 'Any'}
                            onChange={(e) => handleInputChange('bedrooms', e.target.value)}
                        >
                            <option value="Any">Any BHK</option>
                            <option value="1">1 BHK</option>
                            <option value="2">2 BHK</option>
                            <option value="3">3 BHK</option>
                            <option value="4">4 BHK</option>
                            <option value="5+">5+ BHK</option>
                        </select>
                    </div>
                )}

                {/* Land Indicator for Plots */}
                {isLand && (
                    <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label">Plot &amp; Land Filter</label>
                        <div style={{
                            padding: '0.65rem 0.95rem',
                            background: '#ecfdf5',
                            borderRadius: '8px',
                            fontSize: '0.85rem',
                            color: '#059669',
                            fontWeight: '700',
                            border: '1px solid #a7f3d0'
                        }}>
                            Plot Area (sq.ft) Active
                        </div>
                    </div>
                )}
            </div>

            {/* Advanced Filters Expandable Section (Bathrooms, Area, Availability, Amenities) */}
            {showAdvanced && (
                <div style={{
                    padding: '1.25rem',
                    background: '#f8fafc',
                    borderRadius: '14px',
                    border: '1px solid #e2e8f0',
                    marginBottom: '1.25rem',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1.25rem'
                }}>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                        gap: '1rem',
                        alignItems: 'flex-end'
                    }}>
                        {/* Bathrooms Filter */}
                        {!isLand && (
                            <div className="form-group" style={{ marginBottom: 0 }}>
                                <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                    <Bath size={15} color="#2563eb" />
                                    <span>Bathrooms</span>
                                </label>
                                <select
                                    className="form-control"
                                    value={filters.bathrooms || 'Any'}
                                    onChange={(e) => handleInputChange('bathrooms', e.target.value)}
                                >
                                    <option value="Any">Any Bathrooms</option>
                                    <option value="1">1+ Bathrooms</option>
                                    <option value="2">2+ Bathrooms</option>
                                    <option value="3">3+ Bathrooms</option>
                                    <option value="4">4+ Bathrooms</option>
                                </select>
                            </div>
                        )}

                        {/* Min Area (sq.ft) */}
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                <Maximize2 size={15} color="#2563eb" />
                                <span>Min Area (sq.ft)</span>
                            </label>
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Min sq.ft (e.g. 1000)"
                                value={filters.minArea || ''}
                                onChange={(e) => handleInputChange('minArea', e.target.value)}
                            />
                        </div>

                        {/* Max Area (sq.ft) */}
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                <Maximize2 size={15} color="#2563eb" />
                                <span>Max Area (sq.ft)</span>
                            </label>
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Max sq.ft (e.g. 3500)"
                                value={filters.maxArea || ''}
                                onChange={(e) => handleInputChange('maxArea', e.target.value)}
                            />
                        </div>

                        {/* Availability */}
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label">Availability</label>
                            <select
                                className="form-control"
                                value={filters.availability || 'All'}
                                onChange={(e) => handleInputChange('availability', e.target.value)}
                            >
                                <option value="All">All Availabilities</option>
                                <option value="Available">Available</option>
                                <option value="Sold">Sold</option>
                                <option value="Rented">Rented</option>
                            </select>
                        </div>

                        {/* Furnishing */}
                        {!isLand && (
                            <div className="form-group" style={{ marginBottom: 0 }}>
                                <label className="form-label">Furnishing</label>
                                <select
                                    className="form-control"
                                    value={filters.furnishing || 'All'}
                                    onChange={(e) => handleInputChange('furnishing', e.target.value)}
                                >
                                    <option value="All">All Furnishings</option>
                                    <option value="Furnished">Furnished</option>
                                    <option value="Semi-Furnished">Semi-Furnished</option>
                                    <option value="Unfurnished">Unfurnished</option>
                                </select>
                            </div>
                        )}
                    </div>

                    {/* Amenities Multi-Select Filter */}
                    <div>
                        <label className="form-label" style={{ marginBottom: '0.5rem', display: 'block' }}>
                            Included Amenities &amp; Facilities
                        </label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                            {AMENITY_OPTIONS.map((amenity) => {
                                const isChecked = selectedAmenitiesList.includes(amenity);
                                return (
                                    <button
                                        key={amenity}
                                        type="button"
                                        onClick={() => handleAmenityToggle(amenity)}
                                        style={{
                                            border: isChecked ? '1.5px solid #2563eb' : '1px solid #cbd5e1',
                                            background: isChecked ? '#eff6ff' : '#ffffff',
                                            color: isChecked ? '#1d4ed8' : '#475569',
                                            borderRadius: '8px',
                                            padding: '0.35rem 0.75rem',
                                            fontSize: '0.825rem',
                                            fontWeight: isChecked ? '700' : '500',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '0.35rem',
                                            transition: 'var(--transition)'
                                        }}
                                    >
                                        {isChecked && <Check size={13} />}
                                        <span>{amenity}</span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                </div>
            )}

            {/* Bottom Bar: Sort, Toggle Advanced, Actions */}
            <div style={{
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '1rem',
                paddingTop: '1rem',
                borderTop: '1px solid var(--border-light)'
            }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '1rem' }}>
                    {/* Sort Options */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <ArrowUpDown size={15} color="#64748b" />
                        <span style={{ fontSize: '0.85rem', fontWeight: '700', color: '#475569' }}>Sort by:</span>
                        <select
                            className="form-control"
                            style={{ width: 'auto', padding: '0.4rem 2rem 0.4rem 0.75rem', fontSize: '0.85rem' }}
                            value={filters.sort || 'newest'}
                            onChange={(e) => handleInputChange('sort', e.target.value)}
                        >
                            <option value="newest">Newest First</option>
                            <option value="oldest">Oldest First</option>
                            <option value="price_asc">Price: Low to High</option>
                            <option value="price_desc">Price: High to Low</option>
                            <option value="area_asc">Area: Small to Large</option>
                            <option value="area_desc">Area: Large to Small</option>
                        </select>
                    </div>

                    {/* Advanced Filters Button */}
                    <button
                        type="button"
                        onClick={() => setShowAdvanced(!showAdvanced)}
                        style={{
                            background: showAdvanced ? '#eff6ff' : 'transparent',
                            border: '1px solid #cbd5e1',
                            borderRadius: '8px',
                            padding: '0.4rem 0.85rem',
                            fontSize: '0.85rem',
                            fontWeight: '600',
                            color: showAdvanced ? '#2563eb' : '#475569',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.4rem',
                            transition: 'var(--transition)'
                        }}
                    >
                        <SlidersHorizontal size={14} />
                        <span>{showAdvanced ? 'Hide Advanced Filters' : 'More Filters (Bathrooms, Area, Amenities)'}</span>
                        {showAdvanced ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    </button>
                </div>

                {/* Reset & Search Buttons */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <button
                        type="button"
                        onClick={onClearFilters}
                        className="btn btn-secondary btn-sm"
                        title="Reset all filters to defaults"
                    >
                        <RotateCcw size={14} /> Clear Filters
                    </button>
                    <button
                        type="button"
                        onClick={onSearch}
                        className="btn btn-primary btn-sm"
                    >
                        <Search size={14} /> Search Properties
                    </button>
                </div>
            </div>
        </div>
    );
}

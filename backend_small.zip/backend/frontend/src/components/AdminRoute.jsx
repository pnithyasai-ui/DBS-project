import React from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, ArrowLeft } from 'lucide-react';

export default function AdminRoute({ children }) {
    const { user, isAuthenticated, loading, isAdmin } = useAuth();

    if (loading) {
        return (
            <div style={{ padding: '5rem', textAlign: 'center' }}>
                <p>Verifying admin authorization...</p>
            </div>
        );
    }

    if (!isAuthenticated) {
        return <Navigate to="/login/admin" replace />;
    }

    // Role check: If logged in as User, Owner, or Agent, display explicit Access Denied
    if (!isAdmin) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', display: 'flex', justifyContent: 'center' }}>
                <div style={{
                    maxWidth: '540px',
                    width: '100%',
                    background: '#ffffff',
                    padding: '3rem 2.5rem',
                    borderRadius: '20px',
                    border: '1.5px solid #fecaca',
                    boxShadow: '0 20px 40px -10px rgba(220, 38, 38, 0.12)',
                    textAlign: 'center'
                }}>
                    <div style={{
                        width: '72px',
                        height: '72px',
                        margin: '0 auto 1.5rem',
                        background: '#fef2f2',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#dc2626'
                    }}>
                        <ShieldAlert size={38} />
                    </div>
                    
                    <h1 style={{ fontSize: '1.75rem', fontWeight: '800', color: '#991b1b', marginBottom: '0.75rem' }}>
                        Access Denied
                    </h1>
                    
                    <p style={{ color: '#475569', fontSize: '1rem', lineHeight: '1.6', marginBottom: '2rem' }}>
                        You do not have permission to access this page. This administrative portal is strictly restricted to system administrators.
                    </p>

                    <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
                        <Link to="/" className="btn btn-secondary">
                            <ArrowLeft size={16} /> Home
                        </Link>
                        {user.role === 'owner' && (
                            <Link to="/owner-dashboard" className="btn btn-primary">Go to Owner Dashboard</Link>
                        )}
                        {user.role === 'agent' && (
                            <Link to="/agent-dashboard" className="btn btn-primary">Go to Agent Dashboard</Link>
                        )}
                        {user.role === 'user' && (
                            <Link to="/dashboard" className="btn btn-primary">Go to Buyer Dashboard</Link>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    return children;
}

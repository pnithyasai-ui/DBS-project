import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useCompare } from '../context/CompareContext';
import { favoriteApi } from '../services/api';
import { formatIndianPrice } from '../utils/formatters';
import { MapPin, Bed, Bath, Maximize2, CheckCircle, Heart, Scale } from 'lucide-react';

export default function PropertyCard({ property, onFavoriteChange }) {
    const { isAuthenticated } = useAuth();
    const toast = useToast();
    const { addToCompare, isInCompare } = useCompare();
    const navigate = useNavigate();

    const [isFav, setIsFav] = useState(property.is_favorite || false);
    const [loadingFav, setLoadingFav] = useState(false);

    const isCompared = isInCompare(property.property_id);
    const isLand = ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(property.property_type);
    const isCommercial = ['Office', 'Shop', 'Warehouse', 'Commercial Plot'].includes(property.property_type);

    const handleFavoriteToggle = async (e) => {
        e.preventDefault();
        e.stopPropagation();

        if (!isAuthenticated) {
            toast.info('Please log in to save properties to your favorites.', 'Login Required');
            navigate('/login/user');
            return;
        }

        try {
            setLoadingFav(true);
            if (isFav) {
                await favoriteApi.remove(property.property_id);
                setIsFav(false);
                toast.info('Removed from your saved favorites.', 'Favorite Removed');
                if (onFavoriteChange) onFavoriteChange(property.property_id, false);
            } else {
                await favoriteApi.add(property.property_id);
                setIsFav(true);
                toast.success('Saved to your favorites!', 'Favorite Added');
                if (onFavoriteChange) onFavoriteChange(property.property_id, true);
            }
        } catch (err) {
            console.error('Error toggling favorite:', err);
            toast.error('Could not update favorite status.', 'Error');
        } finally {
            setLoadingFav(false);
        }
    };

    const handleCompareToggle = (e) => {
        e.preventDefault();
        e.stopPropagation();
        addToCompare(property);
    };

    return (
        <div className="card card-hover property-card">
            {/* Image & Badges */}
            <div className="prop-img-wrapper">
                <img
                    src={property.primary_image || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=80'}
                    alt={property.title}
                    className="prop-img"
                    loading="lazy"
                />

                {/* Verified Badge */}
                {property.verification_status === 'Verified' && (
                    <div className="prop-badge-verified">
                        <CheckCircle size={13} />
                        <span>Verified</span>
                    </div>
                )}

                {/* Property Type Badge */}
                <div className="prop-badge-type">
                    {property.property_type}
                </div>

                {/* Action Buttons: Compare & Favorite */}
                <div style={{ position: 'absolute', top: '12px', right: '12px', display: 'flex', gap: '0.4rem', zIndex: 3 }}>
                    <button
                        onClick={handleCompareToggle}
                        className={`prop-favorite-btn ${isCompared ? 'favorited' : ''}`}
                        title={isCompared ? 'Remove from Compare' : 'Add to Compare'}
                        aria-label="Toggle Compare"
                        style={{
                            background: isCompared ? 'var(--primary)' : 'rgba(255, 255, 255, 0.92)',
                            color: isCompared ? '#ffffff' : 'var(--text-secondary)'
                        }}
                    >
                        <Scale size={16} />
                    </button>

                    <button
                        onClick={handleFavoriteToggle}
                        disabled={loadingFav}
                        className={`prop-favorite-btn ${isFav ? 'favorited' : ''}`}
                        title={isFav ? 'Remove from Favorites' : 'Save to Favorites'}
                        aria-label="Toggle Favorite"
                    >
                        <Heart size={17} fill={isFav ? '#ef4444' : 'none'} color={isFav ? '#ef4444' : '#64748b'} />
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="prop-content">
                {/* Price */}
                <div className="prop-price">
                    {property.formatted_price || formatIndianPrice(property.price)}
                </div>

                {/* Title */}
                <h3 className="prop-title" title={property.title}>
                    <Link to={`/properties/${property.property_id}`} style={{ color: 'inherit' }}>
                        {property.title}
                    </Link>
                </h3>

                {/* Location */}
                <div className="prop-location">
                    <MapPin size={15} color="#94a3b8" />
                    <span>{property.location}</span>
                </div>

                {/* Adaptive Specs */}
                <div className="prop-specs">
                    {/* Area - shown for all */}
                    <div className="spec-item" title="Built-up / Plot Area">
                        <Maximize2 size={14} color="#64748b" />
                        <span>{property.area?.toLocaleString('en-IN')} sq.ft</span>
                    </div>

                    {/* Bedrooms - ONLY for residential! Never show for land */}
                    {!isLand && property.bedrooms && (
                        <div className="spec-item" title="Bedrooms">
                            <Bed size={14} color="#64748b" />
                            <span>{property.bedrooms} Beds</span>
                        </div>
                    )}

                    {/* Bathrooms - for residential & commercial with bathrooms */}
                    {!isLand && property.bathrooms && (
                        <div className="spec-item" title="Bathrooms">
                            <Bath size={14} color="#64748b" />
                            <span>{property.bathrooms} Baths</span>
                        </div>
                    )}

                    {/* Land/Plot label for plots */}
                    {isLand && (
                        <div className="spec-item" style={{ color: '#059669', fontWeight: '700' }}>
                            <span>Plot / Land</span>
                        </div>
                    )}

                    {/* Commercial label */}
                    {isCommercial && !isLand && (
                        <div className="spec-item" style={{ color: '#2563eb', fontWeight: '700' }}>
                            <span>Commercial</span>
                        </div>
                    )}
                </div>

                {/* Card Footer: Status & View Details Button */}
                <div className="prop-footer">
                    <span className={`status-badge ${property.availability?.toLowerCase()}`}>
                        {property.availability}
                    </span>

                    <Link to={`/properties/${property.property_id}`} className="btn btn-outline-primary btn-sm">
                        View Details
                    </Link>
                </div>
            </div>
        </div>
    );
}

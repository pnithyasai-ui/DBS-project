import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCompare } from '../context/CompareContext';
import {
    Building2, Heart, MessageSquare, PlusCircle, LayoutDashboard,
    CheckCircle, Users, Activity, BarChart3, Database, User, LogOut,
    LogIn, UserPlus, Scale, Menu, X
} from 'lucide-react';

export default function Navbar() {
    const { user, isAuthenticated, logout, isAdmin, isOwner, isAgent, isUser } = useAuth();
    const { compareList } = useCompare();
    const navigate = useNavigate();
    const [mobileOpen, setMobileOpen] = useState(false);

    const handleLogout = () => {
        logout();
        setMobileOpen(false);
        navigate('/');
    };

    const closeMobile = () => {
        setMobileOpen(false);
    };

    return (
        <header className="navbar">
            <div className="container nav-container">
                {/* Brand Logo */}
                <Link to="/" className="nav-brand" onClick={closeMobile}>
                    <div className="brand-icon-box">
                        <Building2 size={24} />
                    </div>
                    <span>PropertyPortal</span>
                </Link>

                {/* Desktop Navigation Links */}
                <nav className="desktop-nav">
                    <ul className="nav-links">
                        {/* Common */}
                        <li>
                            <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                Home
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/properties" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                Properties
                            </NavLink>
                        </li>

                        {/* Compare Link */}
                        <li>
                            <NavLink to="/compare" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`} title="Compare Properties">
                                <Scale size={16} />
                                <span>Compare</span>
                                {compareList.length > 0 && (
                                    <span style={{
                                        background: 'var(--primary)',
                                        color: '#ffffff',
                                        fontSize: '0.7rem',
                                        fontWeight: '800',
                                        borderRadius: '999px',
                                        padding: '0.1rem 0.45rem',
                                        marginLeft: '0.15rem'
                                    }}>
                                        {compareList.length}
                                    </span>
                                )}
                            </NavLink>
                        </li>

                        {/* Guest Links */}
                        {!isAuthenticated && (
                            <>
                                <li>
                                    <NavLink to="/login/user" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <LogIn size={16} /> Login
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/register" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <UserPlus size={16} /> Register
                                    </NavLink>
                                </li>
                            </>
                        )}

                        {/* USER / BUYER Navigation */}
                        {isAuthenticated && isUser && (
                            <>
                                <li>
                                    <NavLink to="/favorites" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <Heart size={16} /> Favorites
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/my-enquiries" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <MessageSquare size={16} /> My Enquiries
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/dashboard" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <LayoutDashboard size={16} /> Dashboard
                                    </NavLink>
                                </li>
                            </>
                        )}

                        {/* OWNER Navigation */}
                        {isAuthenticated && isOwner && (
                            <>
                                <li>
                                    <NavLink to="/add-property" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <PlusCircle size={16} /> Add Property
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/my-properties" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <Building2 size={16} /> My Properties
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/property-enquiries" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <MessageSquare size={16} /> Enquiries
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/owner-dashboard" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <LayoutDashboard size={16} /> Dashboard
                                    </NavLink>
                                </li>
                            </>
                        )}

                        {/* AGENT Navigation */}
                        {isAuthenticated && isAgent && (
                            <>
                                <li>
                                    <NavLink to="/add-property" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <PlusCircle size={16} /> Add Property
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/my-properties" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <Building2 size={16} /> My Listings
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/property-enquiries" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <MessageSquare size={16} /> Enquiries
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/agent-dashboard" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <LayoutDashboard size={16} /> Dashboard
                                    </NavLink>
                                </li>
                            </>
                        )}

                        {/* ADMIN Navigation */}
                        {isAuthenticated && isAdmin && (
                            <>
                                <li>
                                    <NavLink to="/admin/dashboard" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <LayoutDashboard size={16} /> Admin
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/admin/verification" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <CheckCircle size={16} /> Verification
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/admin/users" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <Users size={16} /> Users
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/admin/activity" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <Activity size={16} /> Activity
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/admin/analytics" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <BarChart3 size={16} /> Analytics
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/database-design" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                        <Database size={16} /> DB Design
                                    </NavLink>
                                </li>
                            </>
                        )}
                    </ul>
                </nav>

                {/* Right Actions / User Pill */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    {isAuthenticated && (
                        <div className="nav-actions">
                            <Link to="/profile" className="user-pill" title="View Profile" onClick={closeMobile}>
                                <User size={16} />
                                <span className="user-name-text">{user.name}</span>
                                <span className={`role-badge ${user.role}`}>{user.role}</span>
                            </Link>
                            <button onClick={handleLogout} className="btn btn-secondary btn-sm" title="Log Out">
                                <LogOut size={16} />
                                <span className="logout-text">Logout</span>
                            </button>
                        </div>
                    )}

                    {/* Mobile Menu Hamburger Button */}
                    <button
                        onClick={() => setMobileOpen(!mobileOpen)}
                        className="mobile-menu-btn"
                        aria-label="Toggle navigation menu"
                    >
                        {mobileOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* Mobile Navigation Drawer */}
            {mobileOpen && (
                <div className="mobile-drawer animate-fade-in">
                    <ul className="mobile-nav-links">
                        <li>
                            <NavLink to="/" end className="mobile-nav-link" onClick={closeMobile}>
                                Home
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/properties" className="mobile-nav-link" onClick={closeMobile}>
                                Properties
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/compare" className="mobile-nav-link" onClick={closeMobile}>
                                <Scale size={18} /> Compare Properties ({compareList.length})
                            </NavLink>
                        </li>

                        {!isAuthenticated ? (
                            <>
                                <li>
                                    <NavLink to="/login/user" className="mobile-nav-link" onClick={closeMobile}>
                                        <LogIn size={18} /> Login
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to="/register" className="mobile-nav-link" onClick={closeMobile}>
                                        <UserPlus size={18} /> Register Account
                                    </NavLink>
                                </li>
                            </>
                        ) : (
                            <>
                                <li>
                                    <NavLink to="/profile" className="mobile-nav-link" onClick={closeMobile}>
                                        <User size={18} /> My Profile ({user.name})
                                    </NavLink>
                                </li>

                                {isUser && (
                                    <>
                                        <li>
                                            <NavLink to="/favorites" className="mobile-nav-link" onClick={closeMobile}>
                                                <Heart size={18} /> Favorites
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/my-enquiries" className="mobile-nav-link" onClick={closeMobile}>
                                                <MessageSquare size={18} /> My Enquiries
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/dashboard" className="mobile-nav-link" onClick={closeMobile}>
                                                <LayoutDashboard size={18} /> Dashboard
                                            </NavLink>
                                        </li>
                                    </>
                                )}

                                {(isOwner || isAgent) && (
                                    <>
                                        <li>
                                            <NavLink to="/add-property" className="mobile-nav-link" onClick={closeMobile}>
                                                <PlusCircle size={18} /> Add Property Listing
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/my-properties" className="mobile-nav-link" onClick={closeMobile}>
                                                <Building2 size={18} /> {isOwner ? 'My Properties' : 'My Listings'}
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/property-enquiries" className="mobile-nav-link" onClick={closeMobile}>
                                                <MessageSquare size={18} /> Received Enquiries
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to={isOwner ? '/owner-dashboard' : '/agent-dashboard'} className="mobile-nav-link" onClick={closeMobile}>
                                                <LayoutDashboard size={18} /> Dashboard
                                            </NavLink>
                                        </li>
                                    </>
                                )}

                                {isAdmin && (
                                    <>
                                        <li>
                                            <NavLink to="/admin/dashboard" className="mobile-nav-link" onClick={closeMobile}>
                                                <LayoutDashboard size={18} /> Admin Dashboard
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/admin/verification" className="mobile-nav-link" onClick={closeMobile}>
                                                <CheckCircle size={18} /> Property Verification
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/admin/users" className="mobile-nav-link" onClick={closeMobile}>
                                                <Users size={18} /> User Management
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/admin/activity" className="mobile-nav-link" onClick={closeMobile}>
                                                <Activity size={18} /> Activity Logs
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/admin/analytics" className="mobile-nav-link" onClick={closeMobile}>
                                                <BarChart3 size={18} /> Analytics &amp; Reports
                                            </NavLink>
                                        </li>
                                        <li>
                                            <NavLink to="/database-design" className="mobile-nav-link" onClick={closeMobile}>
                                                <Database size={18} /> Database Schema
                                            </NavLink>
                                        </li>
                                    </>
                                )}

                                <li style={{ paddingTop: '1rem', borderTop: '1px solid #e2e8f0', marginTop: '0.5rem' }}>
                                    <button onClick={handleLogout} className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center' }}>
                                        <LogOut size={18} /> Logout
                                    </button>
                                </li>
                            </>
                        )}
                    </ul>
                </div>
            )}
        </header>
    );
}

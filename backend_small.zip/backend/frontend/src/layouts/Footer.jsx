import React from 'react';
import { Link } from 'react-router-dom';
import { Building2, Phone, Mail, MapPin } from 'lucide-react';

export default function Footer() {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-grid">
                    {/* Brand Info */}
                    <div>
                        <div className="footer-brand">
                            <Building2 size={26} color="#3b82f6" />
                            <span>PropertyPortal</span>
                        </div>
                        <p className="footer-tagline">
                            The premier real estate marketplace connecting buyers, property owners, and trusted agents with verified listings across all budgets.
                        </p>
                    </div>

                    {/* Quick Links */}
                    <div>
                        <h4 className="footer-heading">Quick Links</h4>
                        <ul className="footer-links">
                            <li><Link to="/" className="footer-link">Home</Link></li>
                            <li><Link to="/properties" className="footer-link">Browse Properties</Link></li>
                            <li><Link to="/properties?propertyType=Apartment" className="footer-link">Apartments</Link></li>
                            <li><Link to="/properties?propertyType=Villa" className="footer-link">Luxury Villas</Link></li>
                            <li><Link to="/database-design" className="footer-link">Database Design</Link></li>
                        </ul>
                    </div>

                    {/* Portals */}
                    <div>
                        <h4 className="footer-heading">Access Portals</h4>
                        <ul className="footer-links">
                            <li><Link to="/login/user" className="footer-link">Buyer Login</Link></li>
                            <li><Link to="/login/owner" className="footer-link">Owner Login</Link></li>
                            <li><Link to="/login/agent" className="footer-link">Agent Login</Link></li>
                            <li><Link to="/login/admin" className="footer-link">Admin Console</Link></li>
                            <li><Link to="/register" className="footer-link">Create Account</Link></li>
                        </ul>
                    </div>

                    {/* Contact & Support */}
                    <div>
                        <h4 className="footer-heading">Contact & Legal</h4>
                        <ul className="footer-links">
                            <li className="footer-link" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                                <MapPin size={15} /> HITEC City, Hyderabad
                            </li>
                            <li className="footer-link" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                                <Phone size={15} /> +91 98765 43210
                            </li>
                            <li className="footer-link" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                                <Mail size={15} /> support@propertyportal.com
                            </li>
                            <li><a href="#privacy" className="footer-link">Privacy Policy</a></li>
                            <li><a href="#terms" className="footer-link">Terms of Service</a></li>
                        </ul>
                    </div>
                </div>

                <div className="footer-bottom">
                    <p>© {new Date().getFullYear()} PropertyPortal. All rights reserved.</p>
                    <p>Designed with Clean Architecture &amp; Real MySQL Integration</p>
                </div>
            </div>
        </footer>
    );
}

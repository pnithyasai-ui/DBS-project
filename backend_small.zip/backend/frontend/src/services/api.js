import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Attach JWT token automatically
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('property_portal_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error) => {
    return Promise.reject(error);
});

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response && error.response.status === 401) {
            // Expired or invalid token
            // Only remove if token exists to prevent loops
            if (localStorage.getItem('property_portal_token')) {
                localStorage.removeItem('property_portal_token');
                localStorage.removeItem('property_portal_user');
            }
        }
        return Promise.reject(error);
    }
);

// Auth APIs
export const authApi = {
    register: (userData) => api.post('/auth/register', userData),
    login: (credentials) => api.post('/auth/login', credentials),
    getMe: () => api.get('/auth/me'),
    updateProfile: (profileData) => api.put('/auth/profile', profileData),
    changePassword: (passwordData) => api.put('/auth/change-password', passwordData)
};

// Properties APIs
export const propertyApi = {
    getAll: (params) => api.get('/properties', { params }),
    getFeatured: () => api.get('/properties/featured'),
    getLocations: () => api.get('/properties/locations'),
    getAmenities: () => api.get('/properties/amenities'),
    getMyProperties: () => api.get('/properties/my-properties'),
    getById: (id) => api.get(`/properties/${id}`),
    getSimilar: (id) => api.get(`/properties/${id}/similar`),
    create: (propertyData) => api.post('/properties', propertyData),
    update: (id, propertyData) => api.put(`/properties/${id}`, propertyData),
    delete: (id) => api.delete(`/properties/${id}`),
    updateAvailability: (id, availability) => api.patch(`/properties/${id}/availability`, { availability })
};

// Favorites APIs
export const favoriteApi = {
    getAll: () => api.get('/favorites'),
    add: (propertyId) => api.post(`/favorites/${propertyId}`),
    remove: (propertyId) => api.delete(`/favorites/${propertyId}`)
};

// Enquiry APIs
export const enquiryApi = {
    send: (enquiryData) => api.post('/enquiries', enquiryData),
    getUserEnquiries: () => api.get('/enquiries'),
    getReceivedEnquiries: () => api.get('/enquiries/received'),
    updateStatus: (id, status) => api.patch(`/enquiries/${id}/status`, { status })
};

// Admin APIs
export const adminApi = {
    getDashboardStats: () => api.get('/admin/dashboard'),
    getAnalytics: () => api.get('/admin/analytics'),
    getUsers: () => api.get('/admin/users'),
    updateUserRole: (id, role) => api.patch(`/admin/users/${id}/role`, { role }),
    getProperties: () => api.get('/admin/properties'),
    approveProperty: (id) => api.put(`/admin/properties/${id}/approve`),
    rejectProperty: (id) => api.put(`/admin/properties/${id}/reject`),
    getActivityLogs: () => api.get('/admin/activity'),
    getAllEnquiries: () => api.get('/admin/enquiries')
};

export default api;

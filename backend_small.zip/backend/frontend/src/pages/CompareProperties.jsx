import React from 'react';
import { Link } from 'react-router-dom';
import { useCompare } from '../context/CompareContext';
import { formatIndianPrice } from '../utils/formatters';
import { Scale, Trash2, CheckCircle2, XCircle, ArrowLeft, Building2, MapPin, Maximize2, Bed, Bath } from 'lucide-react';

const ALL_AMENITY_NAMES = [
    'Parking',
    'Lift',
    'Security',
    'Garden',
    'Swimming Pool',
    'Gym',
    'Power Backup',
    'CCTV',
    'Club House'
];

export default function CompareProperties() {
    const { compareList, removeFromCompare, clearCompare } = useCompare();

    if (compareList.length === 0) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                <div style={{
                    width: '80px',
                    height: '80px',
                    borderRadius: '50%',
                    background: '#eff6ff',
                    color: 'var(--primary-light)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 1.5rem'
                }}>
                    <Scale size={40} />
                </div>
                <h1 style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--primary-dark)', marginBottom: '0.75rem' }}>
                    No Properties Selected for Comparison
                </h1>
                <p style={{ color: 'var(--text-muted)', maxWidth: '520px', margin: '0 auto 2rem', fontSize: '1rem', lineHeight: '1.6' }}>
                    Click the <strong>Compare</strong> button on any property card or details page to compare up to 4 listings side-by-side.
                </p>
                <Link to="/properties" className="btn btn-primary btn-lg">
                    <Building2 size={18} /> Browse Properties
                </Link>
            </div>
        );
    }

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem', flexWrap: 'wrap', gap: '1rem' }}>
                <div>
                    <Link to="/properties" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontSize: '0.9rem', fontWeight: '600', marginBottom: '0.5rem' }}>
                        <ArrowLeft size={16} /> Back to Properties
                    </Link>
                    <h1 className="page-title" style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                        <Scale size={28} color="var(--primary)" /> Side-by-Side Property Comparison
                    </h1>
                    <p className="page-subtitle">
                        Comparing {compareList.length} of 4 maximum properties
                    </p>
                </div>

                <div style={{ display: 'flex', gap: '0.75rem' }}>
                    <Link to="/properties" className="btn btn-secondary">
                        + Add Another Property
                    </Link>
                    <button onClick={clearCompare} className="btn btn-outline-danger">
                        <Trash2 size={16} /> Clear All
                    </button>
                </div>
            </div>

            {/* Comparison Table */}
            <div className="table-responsive" style={{
                background: '#ffffff',
                borderRadius: '20px',
                border: '1.5px solid var(--border-light)',
                boxShadow: 'var(--shadow-lg)',
                overflowX: 'auto'
            }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                    <thead>
                        <tr style={{ background: '#f8fafc', borderBottom: '2px solid var(--border-light)' }}>
                            <th style={{ padding: '1.5rem', width: '220px', fontSize: '0.9rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                Property Feature
                            </th>
                            {compareList.map((p) => (
                                <th key={p.property_id} style={{ padding: '1.5rem', minWidth: '260px', verticalAlign: 'top' }}>
                                    <div style={{ position: 'relative' }}>
                                        <button
                                            onClick={() => removeFromCompare(p.property_id)}
                                            style={{
                                                position: 'absolute',
                                                top: '-6px',
                                                right: '-6px',
                                                background: '#fee2e2',
                                                color: '#ef4444',
                                                border: 'none',
                                                borderRadius: '50%',
                                                width: '28px',
                                                height: '28px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                cursor: 'pointer',
                                                boxShadow: 'var(--shadow-xs)'
                                            }}
                                            title="Remove from comparison"
                                        >
                                            &times;
                                        </button>
                                        <img
                                            src={p.primary_image}
                                            alt={p.title}
                                            style={{ width: '100%', height: '140px', objectFit: 'cover', borderRadius: '12px', marginBottom: '0.75rem' }}
                                        />
                                        <div style={{ fontWeight: '800', fontSize: '1.05rem', color: 'var(--primary-dark)', marginBottom: '0.25rem', lineHeight: '1.3' }}>
                                            {p.title}
                                        </div>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#64748b', fontSize: '0.85rem', marginBottom: '0.75rem' }}>
                                            <MapPin size={13} color="#2563eb" /> {p.location}
                                        </div>
                                        <Link to={`/properties/${p.property_id}`} className="btn btn-outline-primary btn-sm" style={{ width: '100%' }}>
                                            View Details
                                        </Link>
                                    </div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {/* 1. Price */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Price
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem', fontWeight: '900', fontSize: '1.25rem', color: 'var(--primary)', fontFamily: 'Outfit' }}>
                                    {p.formatted_price || formatIndianPrice(p.price)}
                                </td>
                            ))}
                        </tr>

                        {/* 2. Price per Sq.ft */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Rate / Sq.ft
                            </td>
                            {compareList.map((p) => {
                                const rate = p.area && p.price ? Math.round(p.price / p.area) : null;
                                return (
                                    <td key={p.property_id} style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#334155' }}>
                                        {rate ? `₹${rate.toLocaleString('en-IN')} / sq.ft` : 'N/A'}
                                    </td>
                                );
                            })}
                        </tr>

                        {/* 3. Property Type */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Property Type
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem' }}>
                                    <span className="role-badge agent" style={{ fontSize: '0.8rem' }}>
                                        {p.property_type}
                                    </span>
                                </td>
                            ))}
                        </tr>

                        {/* 4. Built-up / Plot Area */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Area
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem', fontWeight: '600' }}>
                                    {p.area ? `${p.area.toLocaleString('en-IN')} sq.ft` : 'N/A'}
                                </td>
                            ))}
                        </tr>

                        {/* 5. Bedrooms */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Bedrooms (BHK)
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem', fontWeight: '600' }}>
                                    {p.bedrooms ? `${p.bedrooms} BHK` : 'Not Applicable'}
                                </td>
                            ))}
                        </tr>

                        {/* 6. Bathrooms */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Bathrooms
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem', fontWeight: '600' }}>
                                    {p.bathrooms ? `${p.bathrooms} Bathrooms` : 'N/A'}
                                </td>
                            ))}
                        </tr>

                        {/* 7. Furnishing */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Furnishing
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem' }}>
                                    {p.furnishing || 'N/A'}
                                </td>
                            ))}
                        </tr>

                        {/* 8. Parking */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Parking
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem' }}>
                                    {p.parking || 'N/A'}
                                </td>
                            ))}
                        </tr>

                        {/* 9. Availability Status */}
                        <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Availability
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem' }}>
                                    <span className={`status-badge ${p.availability?.toLowerCase()}`}>
                                        {p.availability}
                                    </span>
                                </td>
                            ))}
                        </tr>

                        {/* 10. Verification Status */}
                        <tr style={{ borderBottom: '2px solid var(--border-light)' }}>
                            <td style={{ padding: '1.1rem 1.5rem', fontWeight: '700', color: '#475569', background: '#f8fafc' }}>
                                Verification
                            </td>
                            {compareList.map((p) => (
                                <td key={p.property_id} style={{ padding: '1.1rem 1.5rem' }}>
                                    {p.verification_status === 'Verified' ? (
                                        <span className="status-badge verified">
                                            <CheckCircle2 size={13} /> Verified
                                        </span>
                                    ) : (
                                        <span className="status-badge pending">
                                            {p.verification_status}
                                        </span>
                                    )}
                                </td>
                            ))}
                        </tr>

                        {/* Section Header: Amenities */}
                        <tr style={{ background: '#f1f5f9' }}>
                            <td colSpan={compareList.length + 1} style={{ padding: '0.85rem 1.5rem', fontWeight: '800', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>
                                Amenities &amp; Facilities Checklist
                            </td>
                        </tr>

                        {/* Amenities Rows */}
                        {ALL_AMENITY_NAMES.map((amenityName) => (
                            <tr key={amenityName} style={{ borderBottom: '1px solid #f1f5f9' }}>
                                <td style={{ padding: '0.85rem 1.5rem', fontWeight: '600', color: '#475569', background: '#f8fafc' }}>
                                    {amenityName}
                                </td>
                                {compareList.map((p) => {
                                    const hasAmenity = p.amenities && p.amenities.some(a => a.name === amenityName);
                                    return (
                                        <td key={p.property_id} style={{ padding: '0.85rem 1.5rem' }}>
                                            {hasAmenity ? (
                                                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem', color: '#059669', fontWeight: '700', fontSize: '0.85rem' }}>
                                                    <CheckCircle2 size={16} /> Yes
                                                </div>
                                            ) : (
                                                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem', color: '#94a3b8', fontSize: '0.85rem' }}>
                                                    <XCircle size={16} /> No
                                                </div>
                                            )}
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { User, Mail, Phone, Lock, Building2, ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function Register() {
    const navigate = useNavigate();
    const { register } = useAuth();

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('user'); // Default to 'user'

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);

        if (password.length < 6) {
            setError('Password must be at least 6 characters long.');
            return;
        }

        try {
            setLoading(true);
            const newUser = await register({
                name,
                email,
                phone,
                password,
                role // 'user', 'owner', or 'agent'
            });

            if (newUser.role === 'owner') navigate('/owner-dashboard');
            else if (newUser.role === 'agent') navigate('/agent-dashboard');
            else navigate('/dashboard');
        } catch (err) {
            setError(err.response?.data?.message || err.message || 'Registration failed.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container" style={{ padding: '4rem 1.5rem 6rem', display: 'flex', justifyContent: 'center' }}>
            <div style={{
                maxWidth: '540px',
                width: '100%',
                background: '#ffffff',
                borderRadius: '24px',
                padding: '2.5rem',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-lg)'
            }}>
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <h1 style={{ fontSize: '1.85rem', fontWeight: '800', color: 'var(--primary-dark)', marginBottom: '0.35rem' }}>
                        Create an Account
                    </h1>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
                        Join PropertyPortal to discover, list, or broker properties
                    </p>
                </div>

                {error && (
                    <div style={{
                        padding: '0.85rem 1rem',
                        background: '#fef2f2',
                        border: '1px solid #fecaca',
                        borderRadius: '10px',
                        color: '#b91c1c',
                        fontSize: '0.9rem',
                        marginBottom: '1.5rem',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem'
                    }}>
                        <ShieldAlert size={18} />
                        <span>{error}</span>
                    </div>
                )}

                <form onSubmit={handleSubmit}>
                    {/* Role Selection Tabs (User, Owner, Agent only) */}
                    <div className="form-group">
                        <label className="form-label">I want to register as:</label>
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(3, 1fr)',
                            gap: '0.5rem',
                            marginTop: '0.25rem'
                        }}>
                            {[
                                { id: 'user', label: '👤 Buyer / User', desc: 'Find & rent' },
                                { id: 'owner', label: '🏡 Property Owner', desc: 'List my home' },
                                { id: 'agent', label: '🏢 Real Estate Agent', desc: 'Manage listings' }
                            ].map((r) => (
                                <button
                                    key={r.id}
                                    type="button"
                                    onClick={() => setRole(r.id)}
                                    style={{
                                        border: role === r.id ? '2px solid var(--primary-light)' : '1px solid var(--border-light)',
                                        background: role === r.id ? 'var(--primary-surface)' : '#ffffff',
                                        color: role === r.id ? 'var(--primary)' : 'var(--text-secondary)',
                                        borderRadius: '12px',
                                        padding: '0.75rem 0.5rem',
                                        cursor: 'pointer',
                                        textAlign: 'center',
                                        transition: 'var(--transition)'
                                    }}
                                >
                                    <div style={{ fontWeight: '700', fontSize: '0.85rem' }}>{r.label}</div>
                                    <div style={{ fontSize: '0.725rem', color: '#64748b', marginTop: '0.2rem' }}>{r.desc}</div>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <User size={15} color="#2563eb" />
                            <span>Full Name</span>
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            required
                            placeholder="e.g. Vikram Reddy"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                        />
                    </div>

                    <div className="form-group">
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <Mail size={15} color="#2563eb" />
                            <span>Email Address</span>
                        </label>
                        <input
                            type="email"
                            className="form-control"
                            required
                            placeholder="e.g. vikram@example.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div className="form-group">
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <Phone size={15} color="#2563eb" />
                            <span>Phone Number</span>
                        </label>
                        <input
                            type="tel"
                            className="form-control"
                            placeholder="+91 9876543210"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                        />
                    </div>

                    <div className="form-group">
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <Lock size={15} color="#2563eb" />
                            <span>Password</span>
                        </label>
                        <input
                            type="password"
                            className="form-control"
                            required
                            placeholder="Create a strong password (min 6 chars)"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className="btn btn-primary"
                        style={{ width: '100%', padding: '0.85rem', marginTop: '0.5rem' }}
                    >
                        {loading ? 'Creating Account...' : 'Complete Registration'}
                    </button>
                </form>

                <div style={{ textAlign: 'center', marginTop: '1.75rem', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                    Already have an account?{' '}
                    <Link to="/login/user" style={{ fontWeight: '700', color: 'var(--primary-light)' }}>
                        Login here
                    </Link>
                </div>
            </div>
        </div>
    );
}

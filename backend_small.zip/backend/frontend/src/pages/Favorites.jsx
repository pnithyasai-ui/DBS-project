import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { favoriteApi } from '../services/api';
import PropertyCard from '../components/PropertyCard';
import { Heart, ArrowLeft, Loader2 } from 'lucide-react';

export default function Favorites() {
    const [favorites, setFavorites] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchFavorites = async () => {
        try {
            setLoading(true);
            const res = await favoriteApi.getAll();
            if (res.data && res.data.success) {
                setFavorites(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load favorites:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchFavorites();
    }, []);

    const handleFavoriteChange = (propId, isFav) => {
        if (!isFav) {
            setFavorites(prev => prev.filter(p => p.property_id !== propId));
        }
    };

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">Saved Properties</h1>
                <p className="page-subtitle">Your collection of shortlisted properties stored securely in your account</p>
            </div>

            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p>Loading your saved properties...</p>
                </div>
            ) : favorites.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">
                        <Heart size={48} color="#94a3b8" />
                    </div>
                    <h3 className="empty-title">No favorites saved yet</h3>
                    <p className="empty-desc">
                        Explore properties and click the heart icon on any listing to bookmark it here for easy access.
                    </p>
                    <Link to="/properties" className="btn btn-primary">
                        Browse Properties
                    </Link>
                </div>
            ) : (
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                    gap: '1.75rem'
                }}>
                    {favorites.map((prop) => (
                        <PropertyCard
                            key={prop.property_id}
                            property={prop}
                            onFavoriteChange={handleFavoriteChange}
                        />
                    ))}
                </div>
            )}
        </div>
    );
}

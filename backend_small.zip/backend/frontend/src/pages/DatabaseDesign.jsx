import React, { useState } from 'react';
import { Database, Key, Link as LinkIcon, Table, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function DatabaseDesign() {
    const [selectedTable, setSelectedTable] = useState('properties');

    const tables = [
        {
            name: 'users',
            desc: 'Central authentication and user entity with role-based access control.',
            pk: 'user_id',
            columns: [
                { name: 'user_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Unique user identifier' },
                { name: 'name', type: 'VARCHAR(100)', key: '', desc: 'Full person or company name' },
                { name: 'email', type: 'VARCHAR(120) UNIQUE', key: 'UK', desc: 'Login credential email' },
                { name: 'password', type: 'VARCHAR(255)', key: '', desc: 'Bcrypt hashed password' },
                { name: 'role', type: "ENUM('user','owner','agent','admin')", key: 'IDX', desc: 'System authorization role' },
                { name: 'phone', type: 'VARCHAR(20)', key: '', desc: 'Contact phone number' },
                { name: 'created_at', type: 'DATETIME', key: '', desc: 'Timestamp of registration' },
                { name: 'updated_at', type: 'DATETIME', key: '', desc: 'Timestamp of last update' }
            ],
            relationships: [
                { type: 'One-to-Many', target: 'properties', fk: 'properties.user_id -> users.user_id' },
                { type: 'One-to-Many', target: 'favorites', fk: 'favorites.user_id -> users.user_id' },
                { type: 'One-to-Many', target: 'enquiries', fk: 'enquiries.user_id -> users.user_id' },
                { type: 'One-to-Many', target: 'activity_logs', fk: 'activity_logs.user_id -> users.user_id' }
            ]
        },
        {
            name: 'properties',
            desc: 'Core property listing entity storing specs, pricing, and verification state.',
            pk: 'property_id',
            columns: [
                { name: 'property_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Primary property identifier' },
                { name: 'user_id', type: 'INT', key: 'FK', desc: 'References users.user_id (Owner/Agent)' },
                { name: 'title', type: 'VARCHAR(255)', key: '', desc: 'Listing title' },
                { name: 'description', type: 'TEXT', key: '', desc: 'Full description and details' },
                { name: 'location', type: 'VARCHAR(150)', key: 'IDX', desc: 'City or locality string' },
                { name: 'price', type: 'DECIMAL(15,2)', key: 'IDX', desc: 'Price in Indian Rupees' },
                { name: 'property_type', type: 'ENUM(...)', key: 'IDX', desc: 'Apartment, Villa, House, Plot, Commercial...' },
                { name: 'area', type: 'INT', key: '', desc: 'Built-up or plot area in sq.ft' },
                { name: 'bedrooms', type: 'INT NULL', key: '', desc: 'BHK count (NULL for land/commercial)' },
                { name: 'bathrooms', type: 'INT NULL', key: '', desc: 'Bathroom count' },
                { name: 'furnishing', type: "ENUM('Unfurnished','Semi-Furnished','Furnished','N/A')", key: '', desc: 'Furnishing state' },
                { name: 'parking', type: 'VARCHAR(50)', key: '', desc: 'Parking capacity' },
                { name: 'availability', type: "ENUM('Available','Sold','Rented')", key: 'IDX', desc: 'Current market availability' },
                { name: 'verified', type: 'BOOLEAN', key: '', desc: '1 if approved, 0 otherwise' },
                { name: 'verification_status', type: "ENUM('Pending','Verified','Rejected')", key: 'IDX', desc: 'Admin verification state' },
                { name: 'created_at', type: 'DATETIME', key: '', desc: 'Timestamp added' },
                { name: 'updated_at', type: 'DATETIME', key: '', desc: 'Timestamp updated' }
            ],
            relationships: [
                { type: 'Many-to-One', target: 'users', fk: 'properties.user_id -> users.user_id' },
                { type: 'One-to-Many', target: 'property_images', fk: 'property_images.property_id -> properties.property_id' },
                { type: 'Many-to-Many', target: 'amenities', fk: 'property_amenities(property_id, amenity_id)' },
                { type: 'One-to-Many', target: 'favorites', fk: 'favorites.property_id -> properties.property_id' },
                { type: 'One-to-Many', target: 'enquiries', fk: 'enquiries.property_id -> properties.property_id' }
            ]
        },
        {
            name: 'amenities',
            desc: 'Lookup table for building & community features.',
            pk: 'amenity_id',
            columns: [
                { name: 'amenity_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Primary identifier' },
                { name: 'name', type: 'VARCHAR(100) UNIQUE', key: 'UK', desc: 'Amenity title (e.g. Lift, Gym, Swimming Pool)' },
                { name: 'icon', type: 'VARCHAR(50)', key: '', desc: 'Lucide icon identifier' }
            ],
            relationships: [
                { type: 'Many-to-Many', target: 'properties', fk: 'property_amenities(amenity_id, property_id)' }
            ]
        },
        {
            name: 'property_amenities',
            desc: 'Junction table establishing Many-to-Many relation between properties and amenities.',
            pk: '(property_id, amenity_id)',
            columns: [
                { name: 'property_id', type: 'INT', key: 'PK, FK', desc: 'References properties.property_id' },
                { name: 'amenity_id', type: 'INT', key: 'PK, FK', desc: 'References amenities.amenity_id' }
            ],
            relationships: [
                { type: 'Many-to-One', target: 'properties', fk: 'property_amenities.property_id -> properties.property_id' },
                { type: 'Many-to-One', target: 'amenities', fk: 'property_amenities.amenity_id -> amenities.amenity_id' }
            ]
        },
        {
            name: 'property_images',
            desc: 'Stores multiple image URLs for each property listing.',
            pk: 'image_id',
            columns: [
                { name: 'image_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Primary image ID' },
                { name: 'property_id', type: 'INT', key: 'FK', desc: 'References properties.property_id' },
                { name: 'image_url', type: 'TEXT', key: '', desc: 'Web URL of the photo' },
                { name: 'is_primary', type: 'BOOLEAN DEFAULT 0', key: '', desc: 'Main cover flag' },
                { name: 'created_at', type: 'DATETIME', key: '', desc: 'Uploaded date' }
            ],
            relationships: [
                { type: 'Many-to-One', target: 'properties', fk: 'property_images.property_id -> properties.property_id' }
            ]
        },
        {
            name: 'favorites',
            desc: 'Tracks bookmarked properties per user with unique user-property constraint.',
            pk: 'favorite_id',
            columns: [
                { name: 'favorite_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Primary ID' },
                { name: 'user_id', type: 'INT', key: 'FK', desc: 'References users.user_id' },
                { name: 'property_id', type: 'INT', key: 'FK', desc: 'References properties.property_id' },
                { name: 'created_at', type: 'DATETIME', key: '', desc: 'Favorited timestamp' }
            ],
            relationships: [
                { type: 'Many-to-One', target: 'users', fk: 'favorites.user_id -> users.user_id' },
                { type: 'Many-to-One', target: 'properties', fk: 'favorites.property_id -> properties.property_id' }
            ]
        },
        {
            name: 'enquiries',
            desc: 'Stores buyer messages and contact details directed to listing owners/agents.',
            pk: 'enquiry_id',
            columns: [
                { name: 'enquiry_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Primary enquiry ID' },
                { name: 'user_id', type: 'INT', key: 'FK', desc: 'Inquiring buyer user_id' },
                { name: 'property_id', type: 'INT', key: 'FK', desc: 'Target property_id' },
                { name: 'name', type: 'VARCHAR(100)', key: '', desc: 'Buyer contact name' },
                { name: 'email', type: 'VARCHAR(120)', key: '', desc: 'Buyer contact email' },
                { name: 'phone', type: 'VARCHAR(20)', key: '', desc: 'Buyer contact phone' },
                { name: 'message', type: 'TEXT', key: '', desc: 'Inquiry inquiry message' },
                { name: 'status', type: "ENUM('Pending','Contacted','Closed')", key: 'IDX', desc: 'Enquiry processing status' },
                { name: 'created_at', type: 'DATETIME', key: '', desc: 'Timestamp submitted' }
            ],
            relationships: [
                { type: 'Many-to-One', target: 'users', fk: 'enquiries.user_id -> users.user_id' },
                { type: 'Many-to-One', target: 'properties', fk: 'enquiries.property_id -> properties.property_id' }
            ]
        },
        {
            name: 'activity_logs',
            desc: 'System audit and operational log recording crucial events.',
            pk: 'log_id',
            columns: [
                { name: 'log_id', type: 'INT AUTO_INCREMENT', key: 'PK', desc: 'Primary log ID' },
                { name: 'user_id', type: 'INT NULL', key: 'FK', desc: 'Actor user_id (NULL for system)' },
                { name: 'action', type: 'VARCHAR(100)', key: 'IDX', desc: 'Action name (e.g. Property Added, User Login)' },
                { name: 'description', type: 'TEXT', key: '', desc: 'Detailed log description' },
                { name: 'created_at', type: 'DATETIME', key: 'IDX', desc: 'Timestamp of event' }
            ],
            relationships: [
                { type: 'Many-to-One', target: 'users', fk: 'activity_logs.user_id -> users.user_id' }
            ]
        }
    ];

    const currentTable = tables.find(t => t.name === selectedTable) || tables[0];

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">Database Design &amp; Schema Architecture</h1>
                <p className="page-subtitle">Interactive entity relationship map matching the production MySQL 8.0 schema</p>
            </div>

            {/* Architecture Overview Banner */}
            <div style={{
                background: '#ffffff',
                padding: '1.75rem',
                borderRadius: '20px',
                border: '1px solid var(--border-light)',
                marginBottom: '2.5rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '1.5rem',
                boxShadow: 'var(--shadow-sm)'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#eff6ff', color: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Database size={26} />
                    </div>
                    <div>
                        <div style={{ fontWeight: '800', fontSize: '1.15rem', color: 'var(--primary-dark)' }}>
                            Database: <code>property_portal</code> (MySQL 8.0 Engine: InnoDB)
                        </div>
                        <div style={{ color: '#64748b', fontSize: '0.875rem' }}>
                            8 Relational Tables • Fully Normalized 3NF • Foreign Key Constraints Enabled
                        </div>
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <span style={{ padding: '0.35rem 0.75rem', background: '#f1f5f9', borderRadius: '8px', fontSize: '0.8rem', fontWeight: '700', color: '#334155' }}>
                        UTF8MB4 Unicode
                    </span>
                    <span style={{ padding: '0.35rem 0.75rem', background: '#ecfdf5', borderRadius: '8px', fontSize: '0.8rem', fontWeight: '700', color: '#047857' }}>
                        Cascading Deletes
                    </span>
                </div>
            </div>

            {/* Table Selector Pills */}
            <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', paddingBottom: '0.75rem', marginBottom: '2rem' }}>
                {tables.map(t => (
                    <button
                        key={t.name}
                        onClick={() => setSelectedTable(t.name)}
                        style={{
                            border: selectedTable === t.name ? '2px solid var(--primary-light)' : '1px solid var(--border-light)',
                            background: selectedTable === t.name ? 'var(--primary)' : '#ffffff',
                            color: selectedTable === t.name ? '#ffffff' : 'var(--text-secondary)',
                            padding: '0.65rem 1.25rem',
                            borderRadius: '12px',
                            fontWeight: '700',
                            fontSize: '0.875rem',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem',
                            boxShadow: 'var(--shadow-xs)',
                            transition: 'var(--transition)'
                        }}
                    >
                        <Table size={15} />
                        <span>{t.name}</span>
                    </button>
                ))}
            </div>

            {/* Two Column Layout: Selected Table Details & ER Relationship Map */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: '1.6fr 1fr',
                gap: '2rem',
                alignItems: 'flex-start'
            }}>
                {/* Left Column: Table Schema Table */}
                <div style={{ background: '#ffffff', borderRadius: '20px', border: '1px solid var(--border-light)', padding: '2rem', boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ marginBottom: '1.5rem', borderBottom: '1px solid var(--border-light)', paddingBottom: '1rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                            <h2 style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--primary-dark)' }}>
                                {currentTable.name}
                            </h2>
                            <span style={{ fontSize: '0.75rem', padding: '0.2rem 0.5rem', background: '#f1f5f9', borderRadius: '6px', fontWeight: '700' }}>
                                PK: {currentTable.pk}
                            </span>
                        </div>
                        <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.25rem' }}>
                            {currentTable.desc}
                        </p>
                    </div>

                    <div className="table-responsive">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Field / Column</th>
                                    <th>Data Type</th>
                                    <th>Key</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                {currentTable.columns.map((col, idx) => (
                                    <tr key={idx}>
                                        <td style={{ fontWeight: '700', fontFamily: 'monospace', color: 'var(--primary-dark)' }}>
                                            {col.name}
                                        </td>
                                        <td style={{ fontFamily: 'monospace', color: '#2563eb', fontSize: '0.825rem' }}>
                                            {col.type}
                                        </td>
                                        <td>
                                            {col.key && (
                                                <span style={{
                                                    padding: '0.2rem 0.5rem',
                                                    borderRadius: '6px',
                                                    fontSize: '0.7rem',
                                                    fontWeight: '800',
                                                    background: col.key.includes('PK') ? '#fef3c7' : '#eff6ff',
                                                    color: col.key.includes('PK') ? '#b45309' : '#1d4ed8',
                                                    border: col.key.includes('PK') ? '1px solid #fde68a' : '1px solid #bfdbfe'
                                                }}>
                                                    {col.key}
                                                </span>
                                            )}
                                        </td>
                                        <td style={{ fontSize: '0.85rem', color: '#475569' }}>
                                            {col.desc}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Right Column: Relationships & Foreign Keys */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    {/* Selected Table Direct Relations */}
                    <div style={{ background: '#ffffff', borderRadius: '20px', border: '1px solid var(--border-light)', padding: '1.75rem', boxShadow: 'var(--shadow-sm)' }}>
                        <h3 style={{ fontSize: '1.2rem', fontWeight: '800', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <LinkIcon size={18} color="#2563eb" /> Relationships for <code>{currentTable.name}</code>
                        </h3>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                            {currentTable.relationships.map((rel, idx) => (
                                <div key={idx} style={{ padding: '0.85rem 1rem', background: '#f8fafc', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.25rem' }}>
                                        <span style={{ fontSize: '0.8rem', fontWeight: '800', color: '#2563eb' }}>
                                            {rel.type}
                                        </span>
                                        <button
                                            type="button"
                                            onClick={() => setSelectedTable(rel.target)}
                                            style={{ border: 'none', background: 'none', color: '#1d4ed8', fontWeight: '600', fontSize: '0.8rem', cursor: 'pointer' }}
                                        >
                                            View {rel.target} &rarr;
                                        </button>
                                    </div>
                                    <div style={{ fontSize: '0.825rem', fontFamily: 'monospace', color: '#334155' }}>
                                        {rel.fk}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Complete Platform Entity Map */}
                    <div style={{ background: '#0f172a', color: '#ffffff', borderRadius: '20px', padding: '1.75rem', boxShadow: 'var(--shadow-md)' }}>
                        <h3 style={{ fontSize: '1.15rem', fontWeight: '800', marginBottom: '1rem', color: '#ffffff' }}>
                            Complete Schema Entity Flow
                        </h3>

                        <div style={{ fontSize: '0.825rem', fontFamily: 'monospace', color: '#cbd5e1', lineHeight: '1.8' }}>
                            <div>USERS (1) ──────&lt; (M) PROPERTIES</div>
                            <div>PROPERTIES (M) &gt;───&lt; (M) AMENITIES</div>
                            <div>PROPERTIES (1) ──&lt; (M) PROPERTY_IMAGES</div>
                            <div>USERS (1) ──────&lt; (M) FAVORITES</div>
                            <div>PROPERTIES (1) ──&lt; (M) FAVORITES</div>
                            <div>USERS (1) ──────&lt; (M) ENQUIRIES</div>
                            <div>PROPERTIES (1) ──&lt; (M) ENQUIRIES</div>
                            <div>USERS (1) ──────&lt; (M) ACTIVITY_LOGS</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

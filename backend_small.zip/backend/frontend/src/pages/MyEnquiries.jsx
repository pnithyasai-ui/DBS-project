import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { enquiryApi } from '../services/api';
import { formatIndianPrice } from '../utils/formatters';
import { MessageSquare, MapPin, Calendar, User, Phone, Mail, Loader2 } from 'lucide-react';

export default function MyEnquiries() {
    const [enquiries, setEnquiries] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchEnquiries() {
            try {
                setLoading(true);
                const res = await enquiryApi.getUserEnquiries();
                if (res.data && res.data.success) {
                    setEnquiries(res.data.data);
                }
            } catch (err) {
                console.error('Failed to load enquiries:', err);
            } finally {
                setLoading(false);
            }
        }
        fetchEnquiries();
    }, []);

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">My Sent Enquiries</h1>
                <p className="page-subtitle">Track responses and contact history with property sellers</p>
            </div>

            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p>Loading your enquiries...</p>
                </div>
            ) : enquiries.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">
                        <MessageSquare size={48} color="#94a3b8" />
                    </div>
                    <h3 className="empty-title">No enquiries sent yet</h3>
                    <p className="empty-desc">
                        When you find a property you love, submit an enquiry from the details page to connect with the owner or agent.
                    </p>
                    <Link to="/properties" className="btn btn-primary">
                        Browse Properties
                    </Link>
                </div>
            ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                    {enquiries.map((enq) => (
                        <div
                            key={enq.enquiry_id}
                            style={{
                                background: '#ffffff',
                                borderRadius: '16px',
                                border: '1px solid var(--border-light)',
                                padding: '1.5rem',
                                boxShadow: 'var(--shadow-sm)',
                                display: 'flex',
                                justifyContent: 'space-between',
                                flexWrap: 'wrap',
                                gap: '1.5rem'
                            }}
                        >
                            <div style={{ flex: '1 1 500px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                                    <span className={`status-badge ${enq.status.toLowerCase()}`}>
                                        {enq.status}
                                    </span>
                                    <span style={{ fontSize: '0.8rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                                        <Calendar size={13} /> {new Date(enq.created_at).toLocaleDateString()}
                                    </span>
                                </div>

                                <h3 style={{ fontSize: '1.2rem', fontWeight: '700', marginBottom: '0.35rem' }}>
                                    <Link to={`/properties/${enq.property_id}`} style={{ color: 'var(--primary-dark)' }}>
                                        {enq.property_title}
                                    </Link>
                                </h3>

                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontSize: '0.875rem', marginBottom: '0.85rem' }}>
                                    <MapPin size={14} color="#2563eb" />
                                    <span>{enq.property_location}</span>
                                    <span>•</span>
                                    <span style={{ fontWeight: '700', color: 'var(--primary)' }}>{formatIndianPrice(enq.price)}</span>
                                </div>

                                <div style={{ background: '#f8fafc', padding: '0.85rem 1rem', borderRadius: '10px', fontSize: '0.9rem', color: '#334155', border: '1px solid #e2e8f0' }}>
                                    <span style={{ fontWeight: '600', color: '#475569' }}>Your Message: </span>
                                    "{enq.message}"
                                </div>
                            </div>

                            {/* Seller info */}
                            <div style={{
                                minWidth: '240px',
                                background: '#f1f5f9',
                                padding: '1rem 1.25rem',
                                borderRadius: '12px',
                                alignSelf: 'flex-start',
                                fontSize: '0.85rem'
                            }}>
                                <div style={{ fontWeight: '700', color: '#1e293b', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                                    <User size={15} color="#2563eb" />
                                    <span>Contact Person: {enq.owner_name}</span>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#475569', marginBottom: '0.35rem' }}>
                                    <Phone size={14} /> {enq.owner_phone || '+91 Contact on request'}
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#475569' }}>
                                    <Mail size={14} /> {enq.owner_email}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { propertyApi, enquiryApi } from '../services/api';
import { formatIndianPrice } from '../utils/formatters';
import { Building2, PlusCircle, CheckCircle2, Clock, MessageSquare, ArrowRight, Loader2 } from 'lucide-react';

export default function OwnerDashboard() {
    const { user } = useAuth();
    const [properties, setProperties] = useState([]);
    const [enquiries, setEnquiries] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadOwnerData() {
            try {
                setLoading(true);
                const [propRes, enqRes] = await Promise.all([
                    propertyApi.getMyProperties(),
                    enquiryApi.getReceivedEnquiries()
                ]);

                if (propRes.data?.success) setProperties(propRes.data.data);
                if (enqRes.data?.success) setEnquiries(enqRes.data.data);
            } catch (err) {
                console.error('Error loading owner dashboard:', err);
            } finally {
                setLoading(false);
            }
        }
        loadOwnerData();
    }, []);

    const totalProps = properties.length;
    const availableProps = properties.filter(p => p.availability === 'Available').length;
    const soldProps = properties.filter(p => p.availability === 'Sold').length;
    const rentedProps = properties.filter(p => p.availability === 'Rented').length;
    const verifiedProps = properties.filter(p => p.verification_status === 'Verified').length;
    const pendingProps = properties.filter(p => p.verification_status === 'Pending').length;

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            {/* Header */}
            <div style={{
                background: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%)',
                color: '#ffffff',
                padding: '2.5rem',
                borderRadius: '24px',
                marginBottom: '2.5rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '1.5rem'
            }}>
                <div>
                    <span className="role-badge owner" style={{ marginBottom: '0.75rem' }}>
                        Property Owner Portal
                    </span>
                    <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#ffffff', marginBottom: '0.25rem' }}>
                        Welcome, {user?.name}!
                    </h1>
                    <p style={{ color: '#cbd5e1', fontSize: '1rem' }}>
                        Track your listings, inquiries from buyers, and listing verification status
                    </p>
                </div>
                <Link to="/add-property" className="btn btn-accent btn-lg">
                    <PlusCircle size={18} /> Add New Property
                </Link>
            </div>

            {/* KPI Cards */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                gap: '1.25rem',
                marginBottom: '3rem'
            }}>
                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ fontSize: '0.825rem', color: '#64748b', fontWeight: '600' }}>MY PROPERTIES</div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--primary-dark)', marginTop: '0.25rem' }}>{totalProps}</div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ fontSize: '0.825rem', color: '#059669', fontWeight: '600' }}>AVAILABLE</div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: '#059669', marginTop: '0.25rem' }}>{availableProps}</div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ fontSize: '0.825rem', color: '#b45309', fontWeight: '600' }}>SOLD / RENTED</div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: '#b45309', marginTop: '0.25rem' }}>{soldProps + rentedProps}</div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ fontSize: '0.825rem', color: '#2563eb', fontWeight: '600' }}>VERIFIED</div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: '#2563eb', marginTop: '0.25rem' }}>{verifiedProps}</div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ fontSize: '0.825rem', color: '#d97706', fontWeight: '600' }}>PENDING REVIEW</div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: '#d97706', marginTop: '0.25rem' }}>{pendingProps}</div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ fontSize: '0.825rem', color: '#7c3aed', fontWeight: '600' }}>TOTAL ENQUIRIES</div>
                    <div style={{ fontSize: '2rem', fontWeight: '800', color: '#7c3aed', marginTop: '0.25rem' }}>{enquiries.length}</div>
                </div>
            </div>

            {/* Two Column Section: Recent Properties & Recent Enquiries */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '2rem' }}>
                {/* Recent Properties */}
                <div style={{ background: '#ffffff', borderRadius: '20px', border: '1px solid var(--border-light)', padding: '1.75rem', boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                        <h2 style={{ fontSize: '1.25rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Building2 size={18} color="#2563eb" /> My Recent Properties
                        </h2>
                        <Link to="/my-properties" style={{ fontSize: '0.85rem', fontWeight: '600' }}>
                            View All ({totalProps})
                        </Link>
                    </div>

                    {properties.length === 0 ? (
                        <p style={{ color: '#64748b', fontSize: '0.9rem' }}>No properties listed yet.</p>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            {properties.slice(0, 4).map((p) => (
                                <div key={p.property_id} style={{ display: 'flex', alignItems: 'center', gap: '1rem', padding: '0.75rem', borderRadius: '12px', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                                    <img src={p.primary_image} alt="" style={{ width: '56px', height: '44px', objectFit: 'cover', borderRadius: '8px' }} />
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                        <div style={{ fontWeight: '700', fontSize: '0.95rem', color: 'var(--primary-dark)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                            {p.title}
                                        </div>
                                        <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                                            {formatIndianPrice(p.price)} • {p.location}
                                        </div>
                                    </div>
                                    <span className={`status-badge ${p.verification_status.toLowerCase()}`} style={{ fontSize: '0.7rem' }}>
                                        {p.verification_status}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Recent Enquiries */}
                <div style={{ background: '#ffffff', borderRadius: '20px', border: '1px solid var(--border-light)', padding: '1.75rem', boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                        <h2 style={{ fontSize: '1.25rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <MessageSquare size={18} color="#2563eb" /> Recent Enquiries Received
                        </h2>
                        <Link to="/property-enquiries" style={{ fontSize: '0.85rem', fontWeight: '600' }}>
                            View All ({enquiries.length})
                        </Link>
                    </div>

                    {enquiries.length === 0 ? (
                        <p style={{ color: '#64748b', fontSize: '0.9rem' }}>No enquiries received yet.</p>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            {enquiries.slice(0, 4).map((e) => (
                                <div key={e.enquiry_id} style={{ padding: '0.85rem 1rem', borderRadius: '12px', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.25rem' }}>
                                        <div style={{ fontWeight: '700', fontSize: '0.9rem' }}>{e.name}</div>
                                        <span className={`status-badge ${e.status.toLowerCase()}`} style={{ fontSize: '0.7rem' }}>
                                            {e.status}
                                        </span>
                                    </div>
                                    <div style={{ fontSize: '0.8rem', color: '#64748b', marginBottom: '0.35rem' }}>
                                        For: {e.property_title}
                                    </div>
                                    <div style={{ fontSize: '0.825rem', color: '#334155', fontStyle: 'italic' }}>
                                        "{e.message}"
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

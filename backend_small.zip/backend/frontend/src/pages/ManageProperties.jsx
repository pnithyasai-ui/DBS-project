import React, { useState, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { propertyApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatIndianPrice } from '../utils/formatters';
import { PlusCircle, Edit3, Trash2, CheckCircle2, Clock, AlertTriangle, Eye, Loader2, Search, Filter } from 'lucide-react';

export default function ManageProperties() {
    const { user, isOwner } = useAuth();
    const toast = useToast();
    const navigate = useNavigate();

    const [properties, setProperties] = useState([]);
    const [loading, setLoading] = useState(true);
    const [deleteModalId, setDeleteModalId] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [availFilter, setAvailFilter] = useState('All');

    const pageTitle = isOwner ? 'My Properties' : 'My Listings';

    const fetchMyProperties = async () => {
        try {
            setLoading(true);
            const res = await propertyApi.getMyProperties();
            if (res.data && res.data.success) {
                setProperties(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load my properties:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMyProperties();
    }, []);

    const handleAvailabilityChange = async (id, newAvailability) => {
        try {
            await propertyApi.updateAvailability(id, newAvailability);
            setProperties(prev => prev.map(p => p.property_id === id ? { ...p, availability: newAvailability } : p));
            toast.success(`Property #${id} marked as ${newAvailability}`);
        } catch (err) {
            console.error('Failed to update availability:', err);
            toast.error(err.response?.data?.message || 'Failed to update availability.');
        }
    };

    const handleDeleteConfirm = async () => {
        if (!deleteModalId) return;
        try {
            await propertyApi.delete(deleteModalId);
            setProperties(prev => prev.filter(p => p.property_id !== deleteModalId));
            setDeleteModalId(null);
            toast.success('Property successfully deleted.');
        } catch (err) {
            console.error('Failed to delete property:', err);
            toast.error(err.response?.data?.message || 'Failed to delete property.');
        }
    };

    const filteredProperties = useMemo(() => {
        return properties.filter((prop) => {
            const matchesSearch = !searchQuery || 
                prop.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                prop.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                prop.property_type?.toLowerCase().includes(searchQuery.toLowerCase());
            
            const matchesStatus = statusFilter === 'All' || prop.verification_status === statusFilter;
            const matchesAvail = availFilter === 'All' || prop.availability === availFilter;

            return matchesSearch && matchesStatus && matchesAvail;
        });
    }, [properties, searchQuery, statusFilter, availFilter]);

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '2rem',
                flexWrap: 'wrap',
                gap: '1rem'
            }}>
                <div>
                    <h1 className="page-title">{pageTitle}</h1>
                    <p className="page-subtitle">Manage, edit, update availability, or add new real estate listings</p>
                </div>
                <Link to="/add-property" className="btn btn-primary">
                    <PlusCircle size={18} /> Add New Property
                </Link>
            </div>

            {/* Search and Filter Controls */}
            {properties.length > 0 && (
                <div style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '1rem',
                    marginBottom: '1.5rem',
                    background: '#ffffff',
                    padding: '1rem 1.25rem',
                    borderRadius: '16px',
                    border: '1px solid var(--border-light)',
                    boxShadow: 'var(--shadow-xs)',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }}>
                    <div style={{ position: 'relative', minWidth: '240px', flex: '1 1 280px' }}>
                        <Search size={16} color="#64748b" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by title, locality, or type..."
                            style={{ paddingLeft: '2.25rem' }}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>

                    <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem', color: '#64748b' }}>
                            <Filter size={15} />
                            <span>Verification:</span>
                        </div>
                        <select
                            className="form-control"
                            style={{ width: '130px', padding: '0.45rem 0.6rem', fontSize: '0.85rem' }}
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value)}
                        >
                            <option value="All">All Status</option>
                            <option value="Verified">Verified</option>
                            <option value="Pending">Pending</option>
                            <option value="Rejected">Rejected</option>
                        </select>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem', color: '#64748b', marginLeft: '0.5rem' }}>
                            <span>Availability:</span>
                        </div>
                        <select
                            className="form-control"
                            style={{ width: '130px', padding: '0.45rem 0.6rem', fontSize: '0.85rem' }}
                            value={availFilter}
                            onChange={(e) => setAvailFilter(e.target.value)}
                        >
                            <option value="All">All</option>
                            <option value="Available">Available</option>
                            <option value="Sold">Sold</option>
                            <option value="Rented">Rented</option>
                        </select>
                    </div>
                </div>
            )}

            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p>Loading your properties...</p>
                </div>
            ) : properties.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">🏡</div>
                    <h3 className="empty-title">You haven't listed any properties yet</h3>
                    <p className="empty-desc">
                        Reach thousands of verified buyers and tenants by publishing your first property listing today.
                    </p>
                    <Link to="/add-property" className="btn btn-primary">
                        <PlusCircle size={18} /> Add Your First Property
                    </Link>
                </div>
            ) : filteredProperties.length === 0 ? (
                <div className="empty-state" style={{ padding: '3rem 1.5rem' }}>
                    <h3 className="empty-title" style={{ fontSize: '1.25rem' }}>No listings match your search</h3>
                    <p className="empty-desc">Try clearing your filters or changing your search terms.</p>
                    <button
                        onClick={() => { setSearchQuery(''); setStatusFilter('All'); setAvailFilter('All'); }}
                        className="btn btn-secondary btn-sm"
                        style={{ marginTop: '1rem' }}
                    >
                        Clear Filters
                    </button>
                </div>
            ) : (
                <div className="table-responsive" style={{ background: '#ffffff', borderRadius: '16px', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Property</th>
                                <th>Type</th>
                                <th>Price</th>
                                <th>Verification</th>
                                <th>Availability</th>
                                <th>Enquiries</th>
                                <th style={{ textAlign: 'right' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredProperties.map((prop) => (
                                <tr key={prop.property_id}>
                                    <td>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                                            <img
                                                src={prop.primary_image}
                                                alt={prop.title}
                                                style={{ width: '60px', height: '48px', objectFit: 'cover', borderRadius: '8px' }}
                                            />
                                            <div>
                                                <div style={{ fontWeight: '700', color: 'var(--primary-dark)', maxWidth: '240px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                    {prop.title}
                                                </div>
                                                <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                                                    {prop.location}
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span className="role-badge agent" style={{ fontSize: '0.75rem' }}>
                                            {prop.property_type}
                                        </span>
                                    </td>
                                    <td style={{ fontWeight: '700', color: 'var(--primary)' }}>
                                        {formatIndianPrice(prop.price)}
                                    </td>
                                    <td>
                                        {prop.verification_status === 'Verified' ? (
                                            <span className="status-badge verified">
                                                <CheckCircle2 size={13} /> Verified
                                            </span>
                                        ) : prop.verification_status === 'Pending' ? (
                                            <span className="status-badge pending">
                                                <Clock size={13} /> Pending Review
                                            </span>
                                        ) : (
                                            <span className="status-badge rejected">
                                                <AlertTriangle size={13} /> Rejected
                                            </span>
                                        )}
                                    </td>
                                    <td>
                                        <select
                                            className="form-control"
                                            style={{ width: '130px', padding: '0.35rem 0.5rem', fontSize: '0.825rem' }}
                                            value={prop.availability}
                                            onChange={(e) => handleAvailabilityChange(prop.property_id, e.target.value)}
                                        >
                                            <option value="Available">Available</option>
                                            <option value="Sold">Sold</option>
                                            <option value="Rented">Rented</option>
                                        </select>
                                    </td>
                                    <td>
                                        <span style={{ fontWeight: '700', color: prop.enquiry_count > 0 ? '#2563eb' : '#94a3b8' }}>
                                            {prop.enquiry_count || 0}
                                        </span>
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                                            <Link
                                                to={`/properties/${prop.property_id}`}
                                                className="btn btn-secondary btn-icon btn-sm"
                                                title="View Public Page"
                                            >
                                                <Eye size={15} />
                                            </Link>
                                            <Link
                                                to={`/edit-property/${prop.property_id}`}
                                                className="btn btn-secondary btn-icon btn-sm"
                                                title="Edit Property"
                                            >
                                                <Edit3 size={15} color="#2563eb" />
                                            </Link>
                                            <button
                                                onClick={() => setDeleteModalId(prop.property_id)}
                                                className="btn btn-secondary btn-icon btn-sm"
                                                title="Delete Property"
                                                style={{ color: '#dc2626' }}
                                            >
                                                <Trash2 size={15} />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* Delete Confirmation Modal */}
            {deleteModalId && (
                <div className="modal-backdrop" onClick={() => setDeleteModalId(null)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '440px' }}>
                        <div className="modal-header">
                            <h3 className="modal-title" style={{ color: '#dc2626' }}>Confirm Deletion</h3>
                            <button onClick={() => setDeleteModalId(null)} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}>&times;</button>
                        </div>
                        <div className="modal-body">
                            <p style={{ color: '#475569', fontSize: '0.95rem', lineHeight: '1.6' }}>
                                Are you sure you want to delete this property listing? This action cannot be undone and will remove all associated images, favorites, and enquiries.
                            </p>
                        </div>
                        <div className="modal-footer">
                            <button onClick={() => setDeleteModalId(null)} className="btn btn-secondary">
                                Cancel
                            </button>
                            <button onClick={handleDeleteConfirm} className="btn btn-danger">
                                Yes, Delete Listing
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

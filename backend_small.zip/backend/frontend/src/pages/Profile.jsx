import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { authApi } from '../services/api';
import { User, Mail, Phone, Lock, Calendar, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Profile() {
    const { user, updateUser } = useAuth();
    const toast = useToast();

    // Profile Edit State
    const [name, setName] = useState(user?.name || '');
    const [phone, setPhone] = useState(user?.phone || '');
    const [profileLoading, setProfileLoading] = useState(false);
    const [profileMsg, setProfileMsg] = useState(null);
    const [profileErr, setProfileErr] = useState(null);

    // Password State
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passLoading, setPassLoading] = useState(false);
    const [passMsg, setPassMsg] = useState(null);
    const [passErr, setPassErr] = useState(null);

    const handleProfileUpdate = async (e) => {
        e.preventDefault();
        setProfileMsg(null);
        setProfileErr(null);
        setProfileLoading(true);

        try {
            const res = await authApi.updateProfile({ name, phone });
            if (res.data && res.data.success) {
                updateUser(res.data.data.user);
                setProfileMsg('Profile information successfully updated!');
                toast.success('Profile updated successfully!');
            }
        } catch (err) {
            const msg = err.response?.data?.message || 'Failed to update profile.';
            setProfileErr(msg);
            toast.error(msg);
        } finally {
            setProfileLoading(false);
        }
    };

    const handlePasswordChange = async (e) => {
        e.preventDefault();
        setPassMsg(null);
        setPassErr(null);

        if (newPassword !== confirmPassword) {
            setPassErr('New passwords do not match.');
            toast.warning('New passwords do not match.');
            return;
        }

        if (newPassword.length < 6) {
            setPassErr('New password must be at least 6 characters.');
            toast.warning('Password must be at least 6 characters.');
            return;
        }

        setPassLoading(true);
        try {
            const res = await authApi.changePassword({ currentPassword, newPassword });
            if (res.data && res.data.success) {
                setPassMsg('Password successfully changed!');
                toast.success('Password changed successfully!');
                setCurrentPassword('');
                setNewPassword('');
                setConfirmPassword('');
            }
        } catch (err) {
            const msg = err.response?.data?.message || 'Failed to change password. Verify your current password.';
            setPassErr(msg);
            toast.error(msg);
        } finally {
            setPassLoading(false);
        }
    };

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">Account Profile</h1>
                <p className="page-subtitle">Manage your personal details, credentials, and contact preferences</p>
            </div>

            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))',
                gap: '2rem'
            }}>
                {/* Profile Overview & Details Card */}
                <div style={{
                    background: '#ffffff',
                    borderRadius: '20px',
                    border: '1px solid var(--border-light)',
                    padding: '2rem',
                    boxShadow: 'var(--shadow-sm)'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', marginBottom: '2rem' }}>
                        <div style={{
                            width: '64px',
                            height: '64px',
                            borderRadius: '50%',
                            background: '#eff6ff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#2563eb'
                        }}>
                            <User size={32} />
                        </div>
                        <div>
                            <h2 style={{ fontSize: '1.35rem', fontWeight: '800' }}>{user?.name}</h2>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.25rem' }}>
                                <span className={`role-badge ${user?.role}`}>{user?.role}</span>
                                <span style={{ color: '#64748b', fontSize: '0.85rem' }}>User ID: #{user?.user_id}</span>
                            </div>
                        </div>
                    </div>

                    {profileMsg && (
                        <div style={{ padding: '0.75rem 1rem', background: '#ecfdf5', color: '#047857', borderRadius: '8px', marginBottom: '1.25rem', border: '1px solid #a7f3d0' }}>
                            {profileMsg}
                        </div>
                    )}

                    {profileErr && (
                        <div style={{ padding: '0.75rem 1rem', background: '#fef2f2', color: '#b91c1c', borderRadius: '8px', marginBottom: '1.25rem', border: '1px solid #fecaca' }}>
                            {profileErr}
                        </div>
                    )}

                    <form onSubmit={handleProfileUpdate}>
                        <div className="form-group">
                            <label className="form-label">Email Address (Read-only)</label>
                            <div style={{
                                padding: '0.7rem 0.95rem',
                                background: '#f8fafc',
                                borderRadius: '10px',
                                border: '1px solid #e2e8f0',
                                color: '#64748b',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem'
                            }}>
                                <Mail size={16} />
                                <span>{user?.email}</span>
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="form-label">Full Name</label>
                            <input
                                type="text"
                                className="form-control"
                                required
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Phone Number</label>
                            <input
                                type="tel"
                                className="form-control"
                                placeholder="+91 9876543210"
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                            />
                        </div>

                        <div style={{ marginTop: '1.5rem' }}>
                            <button
                                type="submit"
                                disabled={profileLoading}
                                className="btn btn-primary"
                            >
                                {profileLoading ? 'Saving...' : 'Save Profile Changes'}
                            </button>
                        </div>
                    </form>
                </div>

                {/* Change Password Card */}
                <div style={{
                    background: '#ffffff',
                    borderRadius: '20px',
                    border: '1px solid var(--border-light)',
                    padding: '2rem',
                    boxShadow: 'var(--shadow-sm)'
                }}>
                    <h2 style={{ fontSize: '1.35rem', fontWeight: '800', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Lock size={20} color="#2563eb" />
                        <span>Change Password</span>
                    </h2>
                    <p style={{ color: '#64748b', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
                        Keep your account safe by updating your password periodically
                    </p>

                    {passMsg && (
                        <div style={{ padding: '0.75rem 1rem', background: '#ecfdf5', color: '#047857', borderRadius: '8px', marginBottom: '1.25rem', border: '1px solid #a7f3d0' }}>
                            {passMsg}
                        </div>
                    )}

                    {passErr && (
                        <div style={{ padding: '0.75rem 1rem', background: '#fef2f2', color: '#b91c1c', borderRadius: '8px', marginBottom: '1.25rem', border: '1px solid #fecaca' }}>
                            {passErr}
                        </div>
                    )}

                    <form onSubmit={handlePasswordChange}>
                        <div className="form-group">
                            <label className="form-label">Current Password</label>
                            <input
                                type="password"
                                className="form-control"
                                required
                                value={currentPassword}
                                onChange={(e) => setCurrentPassword(e.target.value)}
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">New Password</label>
                            <input
                                type="password"
                                className="form-control"
                                required
                                placeholder="At least 6 characters"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Confirm New Password</label>
                            <input
                                type="password"
                                className="form-control"
                                required
                                placeholder="Re-enter new password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                            />
                        </div>

                        <div style={{ marginTop: '1.5rem' }}>
                            <button
                                type="submit"
                                disabled={passLoading}
                                className="btn btn-secondary"
                            >
                                {passLoading ? 'Updating Password...' : 'Update Password'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

import React, { useState, useEffect, useMemo } from 'react';
import { enquiryApi } from '../services/api';
import { useToast } from '../context/ToastContext';
import { formatIndianPrice } from '../utils/formatters';
import { MessageSquare, Calendar, User, Phone, Mail, CheckCircle, Loader2, Search, Filter } from 'lucide-react';

export default function PropertyEnquiries() {
    const [enquiries, setEnquiries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const toast = useToast();

    const fetchReceived = async () => {
        try {
            setLoading(true);
            const res = await enquiryApi.getReceivedEnquiries();
            if (res.data && res.data.success) {
                setEnquiries(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load enquiries:', err);
            toast.error('Failed to load enquiries received.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchReceived();
    }, []);

    const handleStatusChange = async (enquiryId, newStatus) => {
        try {
            await enquiryApi.updateStatus(enquiryId, newStatus);
            setEnquiries(prev => prev.map(e => e.enquiry_id === enquiryId ? { ...e, status: newStatus } : e));
            toast.success(`Enquiry #${enquiryId} updated to ${newStatus}`);
        } catch (err) {
            console.error('Failed to update enquiry status:', err);
            toast.error(err.response?.data?.message || 'Failed to update enquiry status.');
        }
    };

    const filteredEnquiries = useMemo(() => {
        return enquiries.filter((e) => {
            const matchesSearch = !searchQuery ||
                e.property_title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                e.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                e.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                e.phone?.includes(searchQuery) ||
                e.message?.toLowerCase().includes(searchQuery.toLowerCase());

            const matchesStatus = statusFilter === 'All' || e.status === statusFilter;
            return matchesSearch && matchesStatus;
        });
    }, [enquiries, searchQuery, statusFilter]);

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">Listing Enquiries</h1>
                <p className="page-subtitle">Prospective buyers and tenants who reached out for your properties</p>
            </div>

            {/* Search & Filter Toolbar */}
            {enquiries.length > 0 && (
                <div style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '1rem',
                    marginBottom: '1.5rem',
                    background: '#ffffff',
                    padding: '1rem 1.25rem',
                    borderRadius: '16px',
                    border: '1px solid var(--border-light)',
                    boxShadow: 'var(--shadow-xs)',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }}>
                    <div style={{ position: 'relative', minWidth: '240px', flex: '1 1 280px' }}>
                        <Search size={16} color="#64748b" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by property, inquirer name, email, or message..."
                            style={{ paddingLeft: '2.25rem' }}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                        <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: '600' }}>Status:</span>
                        <div style={{ display: 'flex', gap: '0.35rem' }}>
                            {['All', 'Pending', 'Contacted', 'Closed'].map((s) => (
                                <button
                                    key={s}
                                    type="button"
                                    onClick={() => setStatusFilter(s)}
                                    style={{
                                        border: 'none',
                                        padding: '0.4rem 0.75rem',
                                        borderRadius: '8px',
                                        fontSize: '0.8rem',
                                        fontWeight: '700',
                                        cursor: 'pointer',
                                        background: statusFilter === s ? 'var(--primary)' : '#f1f5f9',
                                        color: statusFilter === s ? '#ffffff' : '#64748b',
                                        transition: 'all 0.2s'
                                    }}
                                >
                                    {s}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p>Loading enquiries received...</p>
                </div>
            ) : enquiries.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">
                        <MessageSquare size={48} color="#94a3b8" />
                    </div>
                    <h3 className="empty-title">No enquiries received yet</h3>
                    <p className="empty-desc">
                        As buyers discover your listings, their messages and direct contact numbers will appear here.
                    </p>
                </div>
            ) : filteredEnquiries.length === 0 ? (
                <div className="empty-state" style={{ padding: '3rem 1.5rem' }}>
                    <h3 className="empty-title" style={{ fontSize: '1.25rem' }}>No enquiries match your search</h3>
                    <p className="empty-desc">Try clearing your search query or switching status filters.</p>
                    <button
                        onClick={() => { setSearchQuery(''); setStatusFilter('All'); }}
                        className="btn btn-secondary btn-sm"
                        style={{ marginTop: '1rem' }}
                    >
                        Clear Filters
                    </button>
                </div>
            ) : (
                <div className="table-responsive" style={{ background: '#ffffff', borderRadius: '16px', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Property</th>
                                <th>Inquirer</th>
                                <th>Contact</th>
                                <th>Message</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredEnquiries.map((enq) => (
                                <tr key={enq.enquiry_id}>
                                    <td>
                                        <div style={{ fontWeight: '700', color: 'var(--primary-dark)' }}>{enq.property_title}</div>
                                        <div style={{ fontSize: '0.8rem', color: '#64748b' }}>{enq.property_location}</div>
                                    </td>
                                    <td>
                                        <div style={{ fontWeight: '700' }}>{enq.name}</div>
                                        <div style={{ fontSize: '0.8rem', color: '#64748b' }}>User ID: #{enq.user_id}</div>
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.875rem' }}>
                                            <Phone size={13} color="#2563eb" />
                                            <span>{enq.phone}</span>
                                        </div>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.825rem', color: '#64748b' }}>
                                            <Mail size={13} />
                                            <span>{enq.email}</span>
                                        </div>
                                    </td>
                                    <td style={{ maxWidth: '280px' }}>
                                        <div style={{ fontSize: '0.875rem', color: '#334155', fontStyle: 'italic' }}>
                                            "{enq.message}"
                                        </div>
                                    </td>
                                    <td style={{ fontSize: '0.85rem', color: '#64748b' }}>
                                        {new Date(enq.created_at).toLocaleDateString()}
                                    </td>
                                    <td>
                                        <select
                                            className="form-control"
                                            style={{ width: '130px', padding: '0.35rem 0.5rem', fontSize: '0.825rem' }}
                                            value={enq.status}
                                            onChange={(e) => handleStatusChange(enq.enquiry_id, e.target.value)}
                                        >
                                            <option value="Pending">Pending</option>
                                            <option value="Contacted">Contacted</option>
                                            <option value="Closed">Closed</option>
                                        </select>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { adminApi } from '../../services/api';
import { useToast } from '../../context/ToastContext';
import { Users, Shield, UserCheck, Calendar, Phone, Mail, Loader2, Search, Filter, AlertTriangle } from 'lucide-react';

export default function UserManagement() {
    const toast = useToast();
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [roleFilter, setRoleFilter] = useState('All');

    // Role change confirmation modal state
    const [confirmModal, setConfirmModal] = useState({
        open: false,
        user: null,
        targetRole: ''
    });

    const fetchUsers = async () => {
        try {
            setLoading(true);
            const res = await adminApi.getUsers();
            if (res.data && res.data.success) {
                setUsers(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load users:', err);
            toast.error('Failed to retrieve user accounts.', 'Error');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const promptRoleChange = (userObj, newRole) => {
        if (userObj.role === newRole) return;
        setConfirmModal({
            open: true,
            user: userObj,
            targetRole: newRole
        });
    };

    const confirmRoleChange = async () => {
        const { user: userObj, targetRole } = confirmModal;
        if (!userObj || !targetRole) return;

        try {
            await adminApi.updateUserRole(userObj.user_id, targetRole);
            setUsers(prev => prev.map(u => u.user_id === userObj.user_id ? { ...u, role: targetRole } : u));
            toast.success(`Role for ${userObj.name} updated to ${targetRole}.`, 'Role Updated');
        } catch (err) {
            console.error('Failed to update user role:', err);
            toast.error('Failed to update role. Please try again.', 'Update Failed');
        } finally {
            setConfirmModal({ open: false, user: null, targetRole: '' });
        }
    };

    const filteredUsers = users.filter(u => {
        const matchesRole = roleFilter === 'All' || u.role === roleFilter;
        const matchesQuery = !searchQuery.trim() ||
            u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
            (u.phone && u.phone.includes(searchQuery));
        return matchesRole && matchesQuery;
    });

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">User Accounts &amp; Permissions</h1>
                <p className="page-subtitle">Manage registered buyers, owners, agents, and administrators with role-based access control</p>
            </div>

            {/* Search & Filter Bar */}
            <div style={{
                display: 'flex',
                gap: '1rem',
                marginBottom: '1.75rem',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                background: '#ffffff',
                padding: '1.25rem',
                borderRadius: '16px',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-xs)'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: 1, minWidth: '240px' }}>
                    <Search size={18} color="#64748b" />
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Search users by name, email, or phone..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        style={{ border: 'none', background: 'transparent', padding: '0.25rem 0' }}
                    />
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <Filter size={16} color="#64748b" />
                    <span style={{ fontSize: '0.85rem', fontWeight: '600', color: '#475569' }}>Filter Role:</span>
                    <select
                        className="form-control"
                        style={{ width: 'auto', minWidth: '130px' }}
                        value={roleFilter}
                        onChange={(e) => setRoleFilter(e.target.value)}
                    >
                        <option value="All">All Roles</option>
                        <option value="user">User (Buyer)</option>
                        <option value="owner">Owner</option>
                        <option value="agent">Agent</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
            </div>

            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p style={{ color: '#64748b' }}>Loading user directory...</p>
                </div>
            ) : filteredUsers.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">👥</div>
                    <h3 className="empty-title">No matching users found</h3>
                    <p className="empty-desc">No accounts found matching your search and filter criteria.</p>
                </div>
            ) : (
                <div className="table-responsive" style={{ background: '#ffffff', borderRadius: '16px', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Current Role</th>
                                <th>Properties</th>
                                <th>Enquiries</th>
                                <th>Joined</th>
                                <th>Assign Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsers.map((u) => (
                                <tr key={u.user_id}>
                                    <td>
                                        <div style={{ fontWeight: '700', color: 'var(--primary-dark)' }}>{u.name}</div>
                                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>ID: #{u.user_id}</div>
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.875rem' }}>
                                            <Mail size={13} color="#2563eb" />
                                            <span>{u.email}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.85rem' }}>
                                            <Phone size={13} />
                                            <span>{u.phone || '—'}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span className={`role-badge ${u.role}`}>
                                            {u.role}
                                        </span>
                                    </td>
                                    <td style={{ fontWeight: '600' }}>{u.properties_count || 0}</td>
                                    <td style={{ fontWeight: '600' }}>{u.enquiries_count || 0}</td>
                                    <td style={{ fontSize: '0.825rem', color: '#64748b' }}>
                                        {new Date(u.created_at).toLocaleDateString()}
                                    </td>
                                    <td>
                                        <select
                                            className="form-control"
                                            style={{ width: '120px', padding: '0.35rem 0.5rem', fontSize: '0.825rem' }}
                                            value={u.role}
                                            onChange={(e) => promptRoleChange(u, e.target.value)}
                                        >
                                            <option value="user">User</option>
                                            <option value="owner">Owner</option>
                                            <option value="agent">Agent</option>
                                            <option value="admin">Admin</option>
                                        </select>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* Role Change Confirmation Modal */}
            {confirmModal.open && (
                <div className="modal-backdrop" onClick={() => setConfirmModal({ open: false, user: null, targetRole: '' })}>
                    <div className="modal-content" style={{ maxWidth: '440px' }} onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3 className="modal-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#d97706' }}>
                                <AlertTriangle size={20} /> Confirm Role Change
                            </h3>
                            <button
                                onClick={() => setConfirmModal({ open: false, user: null, targetRole: '' })}
                                style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#64748b' }}
                            >
                                &times;
                            </button>
                        </div>
                        <div className="modal-body">
                            <p style={{ color: '#334155', lineHeight: '1.6' }}>
                                Are you sure you want to change the role of <strong>{confirmModal.user?.name}</strong> from{' '}
                                <span className={`role-badge ${confirmModal.user?.role}`}>{confirmModal.user?.role}</span> to{' '}
                                <span className={`role-badge ${confirmModal.targetRole}`}>{confirmModal.targetRole}</span>?
                            </p>
                            <p style={{ fontSize: '0.85rem', color: '#64748b', marginTop: '0.5rem' }}>
                                This action will immediately adjust their dashboard access, listing permissions, and portal capabilities.
                            </p>
                        </div>
                        <div className="modal-footer">
                            <button
                                onClick={() => setConfirmModal({ open: false, user: null, targetRole: '' })}
                                className="btn btn-secondary"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={confirmRoleChange}
                                className="btn btn-primary"
                            >
                                Confirm Role Change
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

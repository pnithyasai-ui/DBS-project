import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { adminApi, propertyApi } from '../../services/api';
import { useToast } from '../../context/ToastContext';
import { formatIndianPrice } from '../../utils/formatters';
import {
    CheckCircle, XCircle, Eye, Clock, Check, X, Loader2,
    AlertCircle, MapPin, Maximize2, Bed, Bath, User, Phone, Mail, Shield
} from 'lucide-react';

export default function PropertyVerification() {
    const toast = useToast();
    const [properties, setProperties] = useState([]);
    const [filterStatus, setFilterStatus] = useState('Pending');
    const [loading, setLoading] = useState(true);

    // Inspection Modal State
    const [inspectingProperty, setInspectingProperty] = useState(null);
    const [loadingInspect, setLoadingInspect] = useState(false);

    const fetchProperties = async () => {
        try {
            setLoading(true);
            const res = await adminApi.getProperties();
            if (res.data && res.data.success) {
                setProperties(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load admin properties:', err);
            toast.error('Failed to load properties for verification.', 'Error');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProperties();
    }, []);

    const handleInspect = async (propertyId) => {
        try {
            setLoadingInspect(true);
            const res = await propertyApi.getById(propertyId);
            if (res.data?.success) {
                setInspectingProperty(res.data.data);
            }
        } catch (err) {
            toast.error('Failed to retrieve full property details.', 'Error');
        } finally {
            setLoadingInspect(false);
        }
    };

    const handleApprove = async (id) => {
        try {
            await adminApi.approveProperty(id);
            setProperties(prev => prev.map(p => p.property_id === id ? { ...p, verification_status: 'Verified', verified: 1 } : p));
            if (inspectingProperty?.property_id === id) {
                setInspectingProperty(prev => ({ ...prev, verification_status: 'Verified', verified: 1 }));
            }
            toast.success(`Property #${id} has been Approved and published!`, 'Listing Verified');
        } catch (err) {
            console.error('Approve failed:', err);
            toast.error('Failed to approve property.', 'Error');
        }
    };

    const handleReject = async (id) => {
        try {
            await adminApi.rejectProperty(id);
            setProperties(prev => prev.map(p => p.property_id === id ? { ...p, verification_status: 'Rejected', verified: 0 } : p));
            if (inspectingProperty?.property_id === id) {
                setInspectingProperty(prev => ({ ...prev, verification_status: 'Rejected', verified: 0 }));
            }
            toast.info(`Property #${id} has been Rejected.`, 'Listing Rejected');
        } catch (err) {
            console.error('Reject failed:', err);
            toast.error('Failed to reject property.', 'Error');
        }
    };

    const filtered = properties.filter(p => {
        if (filterStatus === 'All') return true;
        return p.verification_status === filterStatus;
    });

    const pendingCount = properties.filter(p => p.verification_status === 'Pending').length;

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">Property Listing Verification Queue</h1>
                <p className="page-subtitle">Review submitted properties before publishing them to the public marketplace</p>
            </div>

            {/* Filter Tabs */}
            <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
                {['Pending', 'Verified', 'Rejected', 'All'].map((status) => (
                    <button
                        key={status}
                        onClick={() => setFilterStatus(status)}
                        style={{
                            border: 'none',
                            padding: '0.6rem 1.25rem',
                            borderRadius: '12px',
                            fontWeight: '700',
                            fontSize: '0.9rem',
                            cursor: 'pointer',
                            transition: 'var(--transition)',
                            background: filterStatus === status ? '#1e3a8a' : '#ffffff',
                            color: filterStatus === status ? '#ffffff' : '#64748b',
                            boxShadow: 'var(--shadow-xs)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.4rem'
                        }}
                    >
                        <span>{status}</span>
                        {status === 'Pending' && pendingCount > 0 && (
                            <span style={{ background: '#f59e0b', color: '#ffffff', padding: '0.1rem 0.45rem', borderRadius: '9999px', fontSize: '0.75rem' }}>
                                {pendingCount}
                            </span>
                        )}
                    </button>
                ))}
            </div>

            {/* Verification Table */}
            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p>Loading properties for review...</p>
                </div>
            ) : filtered.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">✓</div>
                    <h3 className="empty-title">No {filterStatus.toLowerCase()} properties</h3>
                    <p className="empty-desc">
                        {filterStatus === 'Pending' ? 'All submitted properties have been reviewed!' : 'No properties in this status category.'}
                    </p>
                </div>
            ) : (
                <div className="table-responsive" style={{ background: '#ffffff', borderRadius: '16px', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Property Title</th>
                                <th>Owner / Agent</th>
                                <th>Location</th>
                                <th>Price</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th style={{ textAlign: 'right' }}>Review Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filtered.map((prop) => (
                                <tr key={prop.property_id}>
                                    <td style={{ fontWeight: '700', color: '#64748b' }}>
                                        #{prop.property_id}
                                    </td>
                                    <td>
                                        <div style={{ fontWeight: '700', color: 'var(--primary-dark)', maxWidth: '240px' }}>
                                            {prop.title}
                                        </div>
                                    </td>
                                    <td>
                                        <div style={{ fontWeight: '600' }}>{prop.owner_name}</div>
                                        <span className={`role-badge ${prop.owner_role}`} style={{ fontSize: '0.7rem' }}>
                                            {prop.owner_role}
                                        </span>
                                    </td>
                                    <td>{prop.location}</td>
                                    <td style={{ fontWeight: '800', color: 'var(--primary)', fontFamily: 'Outfit' }}>
                                        {formatIndianPrice(prop.price)}
                                    </td>
                                    <td>
                                        <span className="role-badge agent" style={{ fontSize: '0.75rem' }}>
                                            {prop.property_type}
                                        </span>
                                    </td>
                                    <td>
                                        <span className={`status-badge ${prop.verification_status.toLowerCase()}`}>
                                            {prop.verification_status}
                                        </span>
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end', alignItems: 'center' }}>
                                            {/* Quick Inspect Modal Button */}
                                            <button
                                                onClick={() => handleInspect(prop.property_id)}
                                                className="btn btn-secondary btn-sm"
                                                title="Inspect Property Details"
                                                style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}
                                            >
                                                <Eye size={14} /> Inspect
                                            </button>

                                            {prop.verification_status !== 'Verified' && (
                                                <button
                                                    onClick={() => handleApprove(prop.property_id)}
                                                    className="btn btn-success btn-sm"
                                                    title="Approve & Publish"
                                                >
                                                    <Check size={14} /> Approve
                                                </button>
                                            )}

                                            {prop.verification_status !== 'Rejected' && (
                                                <button
                                                    onClick={() => handleReject(prop.property_id)}
                                                    className="btn btn-danger btn-sm"
                                                    title="Reject Property"
                                                >
                                                    <X size={14} /> Reject
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* Inline Property Inspection Modal */}
            {inspectingProperty && (
                <div className="modal-backdrop" onClick={() => setInspectingProperty(null)}>
                    <div className="modal-content" style={{ maxWidth: '800px', maxHeight: '90vh', overflowY: 'auto' }} onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <div>
                                <span className={`status-badge ${inspectingProperty.verification_status.toLowerCase()}`} style={{ marginRight: '0.5rem' }}>
                                    {inspectingProperty.verification_status}
                                </span>
                                <h3 className="modal-title" style={{ display: 'inline' }}>
                                    Inspect Property #{inspectingProperty.property_id}
                                </h3>
                            </div>
                            <button
                                onClick={() => setInspectingProperty(null)}
                                style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#64748b' }}
                            >
                                &times;
                            </button>
                        </div>

                        <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                            {/* Primary Image */}
                            <div style={{ width: '100%', height: '260px', borderRadius: '14px', overflow: 'hidden', backgroundColor: '#0f172a' }}>
                                <img
                                    src={inspectingProperty.primary_image}
                                    alt={inspectingProperty.title}
                                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                />
                            </div>

                            {/* Details Header */}
                            <div>
                                <h2 style={{ fontSize: '1.4rem', fontWeight: '800', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                                    {inspectingProperty.title}
                                </h2>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#64748b' }}>
                                    <MapPin size={15} color="#2563eb" />
                                    <span>{inspectingProperty.location}</span>
                                </div>
                            </div>

                            {/* Specs Grid */}
                            <div style={{
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
                                gap: '1rem',
                                background: '#f8fafc',
                                padding: '1rem',
                                borderRadius: '12px',
                                border: '1px solid #e2e8f0'
                            }}>
                                <div>
                                    <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Price</div>
                                    <div style={{ fontWeight: '800', color: 'var(--primary)', fontSize: '1.1rem' }}>
                                        {formatIndianPrice(inspectingProperty.price)}
                                    </div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Type</div>
                                    <div style={{ fontWeight: '700' }}>{inspectingProperty.property_type}</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Area</div>
                                    <div style={{ fontWeight: '700' }}>{inspectingProperty.area} sq.ft</div>
                                </div>
                                {inspectingProperty.bedrooms && (
                                    <div>
                                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Bedrooms</div>
                                        <div style={{ fontWeight: '700' }}>{inspectingProperty.bedrooms} BHK</div>
                                    </div>
                                )}
                                <div>
                                    <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Furnishing</div>
                                    <div style={{ fontWeight: '700' }}>{inspectingProperty.furnishing || 'N/A'}</div>
                                </div>
                            </div>

                            {/* Description */}
                            <div>
                                <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '0.5rem' }}>Description</h4>
                                <p style={{ color: '#475569', fontSize: '0.9rem', lineHeight: '1.6' }}>
                                    {inspectingProperty.description || 'No description provided.'}
                                </p>
                            </div>

                            {/* Amenities */}
                            {inspectingProperty.amenities?.length > 0 && (
                                <div>
                                    <h4 style={{ fontSize: '0.95rem', fontWeight: '700', marginBottom: '0.5rem' }}>Amenities</h4>
                                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                                        {inspectingProperty.amenities.map(a => (
                                            <span key={a.amenity_id} style={{ padding: '0.25rem 0.6rem', background: '#eff6ff', color: '#1d4ed8', borderRadius: '6px', fontSize: '0.8rem', fontWeight: '600' }}>
                                                ✓ {a.name}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Submitter Info */}
                            <div style={{ padding: '1rem', background: '#f1f5f9', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                                <div style={{ fontSize: '0.8rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase', marginBottom: '0.4rem' }}>
                                    Listing Submitter Details
                                </div>
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.5rem', fontSize: '0.875rem' }}>
                                    <div><strong>Name:</strong> {inspectingProperty.owner_name} ({inspectingProperty.owner_role})</div>
                                    <div><strong>Phone:</strong> {inspectingProperty.owner_phone || '—'}</div>
                                    <div><strong>Email:</strong> {inspectingProperty.owner_email}</div>
                                </div>
                            </div>
                        </div>

                        <div className="modal-footer" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Link to={`/properties/${inspectingProperty.property_id}`} target="_blank" className="btn btn-secondary btn-sm">
                                Open Public Page ↗
                            </Link>

                            <div style={{ display: 'flex', gap: '0.75rem' }}>
                                {inspectingProperty.verification_status !== 'Rejected' && (
                                    <button
                                        onClick={() => handleReject(inspectingProperty.property_id)}
                                        className="btn btn-danger btn-sm"
                                    >
                                        <X size={14} /> Reject Property
                                    </button>
                                )}
                                {inspectingProperty.verification_status !== 'Verified' && (
                                    <button
                                        onClick={() => handleApprove(inspectingProperty.property_id)}
                                        className="btn btn-success btn-sm"
                                    >
                                        <Check size={14} /> Approve &amp; Publish
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

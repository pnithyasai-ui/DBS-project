import React, { useState, useEffect } from 'react';
import { adminApi } from '../../services/api';
import {
    BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, AreaChart, Area, CartesianGrid, Legend
} from 'recharts';
import { BarChart3, TrendingUp, MapPin, Building, PieChart as PieIcon, Calendar, Loader2 } from 'lucide-react';

const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#ec4899'];

export default function AdminAnalytics() {
    const [analytics, setAnalytics] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchAnalytics() {
            try {
                setLoading(true);
                const res = await adminApi.getAnalytics();
                if (res.data && res.data.success) {
                    setAnalytics(res.data.data);
                }
            } catch (err) {
                console.error('Failed to load analytics:', err);
            } finally {
                setLoading(false);
            }
        }
        fetchAnalytics();
    }, []);

    if (loading) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                <p>Generating interactive analytics charts from MySQL data...</p>
            </div>
        );
    }

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem' }}>
                <h1 className="page-title">Platform Analytics &amp; Visual Intelligence</h1>
                <p className="page-subtitle">Real-time aggregate data visualization computed directly from the MySQL database</p>
            </div>

            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(460px, 1fr))',
                gap: '2rem'
            }}>
                {/* 1. Properties by Type */}
                <div style={{ background: '#ffffff', borderRadius: '20px', padding: '1.75rem', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '800', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <Building size={18} color="#2563eb" /> Properties by Category &amp; Type
                    </h3>
                    <div style={{ width: '100%', height: '300px' }}>
                        <ResponsiveContainer>
                            <BarChart data={analytics?.by_type || []} margin={{ top: 10, right: 20, left: 0, bottom: 25 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="name" angle={-25} textAnchor="end" tick={{ fontSize: 11 }} interval={0} />
                                <YAxis allowDecimals={false} />
                                <Tooltip
                                    formatter={(val) => [`${val} Properties`, 'Count']}
                                    contentStyle={{ borderRadius: '8px', border: '1px solid #cbd5e1' }}
                                />
                                <Bar dataKey="count" fill="#2563eb" radius={[6, 6, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* 2. Properties by Budget Range */}
                <div style={{ background: '#ffffff', borderRadius: '20px', padding: '1.75rem', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '800', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <TrendingUp size={18} color="#10b981" /> Distribution Across Budget Brackets
                    </h3>
                    <div style={{ width: '100%', height: '300px' }}>
                        <ResponsiveContainer>
                            <BarChart data={analytics?.by_budget || []} margin={{ top: 10, right: 20, left: 0, bottom: 25 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="name" angle={-25} textAnchor="end" tick={{ fontSize: 11 }} interval={0} />
                                <YAxis allowDecimals={false} />
                                <Tooltip
                                    formatter={(val) => [`${val} Properties`, 'Count']}
                                    contentStyle={{ borderRadius: '8px', border: '1px solid #cbd5e1' }}
                                />
                                <Bar dataKey="count" fill="#10b981" radius={[6, 6, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* 3. Top Locations */}
                <div style={{ background: '#ffffff', borderRadius: '20px', padding: '1.75rem', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '800', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <MapPin size={18} color="#f59e0b" /> Top Locations by Listing Volume
                    </h3>
                    <div style={{ width: '100%', height: '300px' }}>
                        <ResponsiveContainer>
                            <BarChart data={analytics?.by_location || []} layout="vertical" margin={{ top: 10, right: 20, left: 40, bottom: 10 }}>
                                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                                <XAxis type="number" allowDecimals={false} />
                                <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} />
                                <Tooltip
                                    formatter={(val) => [`${val} Properties`, 'Count']}
                                    contentStyle={{ borderRadius: '8px', border: '1px solid #cbd5e1' }}
                                />
                                <Bar dataKey="count" fill="#f59e0b" radius={[0, 6, 6, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* 4. Availability Breakdown & Users by Role Pie Charts */}
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '1rem',
                    background: '#ffffff',
                    borderRadius: '20px',
                    padding: '1.75rem',
                    border: '1px solid var(--border-light)',
                    boxShadow: 'var(--shadow-sm)'
                }}>
                    <div>
                        <h4 style={{ fontSize: '1rem', fontWeight: '700', textAlign: 'center', marginBottom: '0.5rem' }}>
                            Availability Status
                        </h4>
                        <div style={{ width: '100%', height: '230px' }}>
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie
                                        data={analytics?.by_availability || []}
                                        dataKey="value"
                                        nameKey="name"
                                        cx="50%"
                                        cy="50%"
                                        outerRadius={75}
                                        innerRadius={45}
                                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                    >
                                        {(analytics?.by_availability || []).map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div>
                        <h4 style={{ fontSize: '1rem', fontWeight: '700', textAlign: 'center', marginBottom: '0.5rem' }}>
                            Users by Role
                        </h4>
                        <div style={{ width: '100%', height: '230px' }}>
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie
                                        data={analytics?.by_role || []}
                                        dataKey="value"
                                        nameKey="name"
                                        cx="50%"
                                        cy="50%"
                                        outerRadius={75}
                                        innerRadius={45}
                                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                    >
                                        {(analytics?.by_role || []).map((entry, index) => (
                                            <Cell key={`cell-role-${index}`} fill={COLORS[(index + 3) % COLORS.length]} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { adminApi } from '../../services/api';
import { formatIndianPrice } from '../../utils/formatters';
import {
    ShieldCheck, Users, Building2, CheckCircle2, Clock,
    AlertTriangle, MessageSquare, IndianRupee, Activity, BarChart3,
    Database, ArrowRight, Loader2
} from 'lucide-react';

export default function AdminDashboard() {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchAdminStats() {
            try {
                setLoading(true);
                const res = await adminApi.getDashboardStats();
                if (res.data && res.data.success) {
                    setStats(res.data.data);
                }
            } catch (err) {
                console.error('Failed to load admin stats:', err);
            } finally {
                setLoading(false);
            }
        }
        fetchAdminStats();
    }, []);

    if (loading) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                <p>Loading Admin Dashboard metrics...</p>
            </div>
        );
    }

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            {/* Top Admin Banner */}
            <div style={{
                background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
                color: '#ffffff',
                padding: '2.5rem',
                borderRadius: '24px',
                marginBottom: '2.5rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '1.5rem',
                border: '1px solid #334155'
            }}>
                <div>
                    <span className="role-badge admin" style={{ marginBottom: '0.75rem', background: '#450a0a', color: '#f87171', border: '1px solid #7f1d1d' }}>
                        System Administration Console
                    </span>
                    <h1 style={{ fontSize: '2.25rem', fontWeight: '800', color: '#ffffff', marginBottom: '0.35rem' }}>
                        PropertyPortal Master Control
                    </h1>
                    <p style={{ color: '#94a3b8', fontSize: '1.05rem' }}>
                        Monitor platform health, verify pending listings, manage users, and review activity logs
                    </p>
                </div>

                <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                    <Link to="/admin/verification" className="btn btn-accent">
                        <Clock size={16} /> Verification Queue ({stats?.pending_properties || 0})
                    </Link>
                    <Link to="/admin/analytics" className="btn btn-secondary">
                        <BarChart3 size={16} /> Analytics
                    </Link>
                </div>
            </div>

            {/* Quick Alert if Pending Properties exist */}
            {stats?.pending_properties > 0 && (
                <div style={{
                    padding: '1.25rem 1.5rem',
                    background: '#fffbeb',
                    border: '1.5px solid #fde68a',
                    borderRadius: '16px',
                    marginBottom: '2.5rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: '1rem'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d97706' }}>
                            <Clock size={20} />
                        </div>
                        <div>
                            <div style={{ fontWeight: '700', color: '#92400e', fontSize: '1.05rem' }}>
                                {stats.pending_properties} Property Listing(s) Awaiting Review
                            </div>
                            <div style={{ color: '#b45309', fontSize: '0.875rem' }}>
                                Owner and agent submissions need verification before appearing in public searches.
                            </div>
                        </div>
                    </div>
                    <Link to="/admin/verification" className="btn btn-accent btn-sm">
                        Review Now <ArrowRight size={14} />
                    </Link>
                </div>
            )}

            {/* Platform Primary Metrics Grid */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                gap: '1.25rem',
                marginBottom: '2.5rem'
            }}>
                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#64748b' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '700' }}>TOTAL USERS</span>
                        <Users size={18} color="#2563eb" />
                    </div>
                    <div style={{ fontSize: '2.1rem', fontWeight: '800', color: 'var(--primary-dark)', marginTop: '0.35rem' }}>
                        {stats?.total_users}
                    </div>
                    <div style={{ fontSize: '0.775rem', color: '#64748b', marginTop: '0.35rem' }}>
                        {stats?.total_owners} Owners • {stats?.total_agents} Agents • {stats?.total_buyers} Buyers
                    </div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#64748b' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '700' }}>TOTAL PROPERTIES</span>
                        <Building2 size={18} color="#2563eb" />
                    </div>
                    <div style={{ fontSize: '2.1rem', fontWeight: '800', color: 'var(--primary-dark)', marginTop: '0.35rem' }}>
                        {stats?.total_properties}
                    </div>
                    <div style={{ fontSize: '0.775rem', color: '#64748b', marginTop: '0.35rem' }}>
                        {stats?.verified_properties} Verified • {stats?.pending_properties} Pending
                    </div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#64748b' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '700' }}>ACTIVE / AVAILABLE</span>
                        <CheckCircle2 size={18} color="#10b981" />
                    </div>
                    <div style={{ fontSize: '2.1rem', fontWeight: '800', color: '#059669', marginTop: '0.35rem' }}>
                        {stats?.available_properties}
                    </div>
                    <div style={{ fontSize: '0.775rem', color: '#64748b', marginTop: '0.35rem' }}>
                        {stats?.sold_properties} Sold • {stats?.rented_properties} Rented
                    </div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#64748b' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '700' }}>AVERAGE PRICE</span>
                        <IndianRupee size={18} color="#d97706" />
                    </div>
                    <div style={{ fontSize: '1.85rem', fontWeight: '800', color: '#d97706', marginTop: '0.35rem' }}>
                        {formatIndianPrice(stats?.avg_price)}
                    </div>
                    <div style={{ fontSize: '0.775rem', color: '#64748b', marginTop: '0.35rem' }}>
                        Platform-wide listing average
                    </div>
                </div>

                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#64748b' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '700' }}>TOTAL ENQUIRIES</span>
                        <MessageSquare size={18} color="#7c3aed" />
                    </div>
                    <div style={{ fontSize: '2.1rem', fontWeight: '800', color: '#7c3aed', marginTop: '0.35rem' }}>
                        {stats?.total_enquiries}
                    </div>
                    <div style={{ fontSize: '0.775rem', color: '#64748b', marginTop: '0.35rem' }}>
                        Direct buyer-seller interactions
                    </div>
                </div>
            </div>

            {/* Quick Navigation Admin Cards */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
                gap: '1.5rem',
                marginBottom: '3rem'
            }}>
                <Link to="/admin/verification" className="card card-hover" style={{ padding: '1.75rem', textDecoration: 'none' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#fef3c7', color: '#d97706', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                        <Clock size={24} />
                    </div>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                        Property Verification
                    </h3>
                    <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
                        Approve or reject newly submitted listings from owners and agents.
                    </p>
                </Link>

                <Link to="/admin/users" className="card card-hover" style={{ padding: '1.75rem', textDecoration: 'none' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#eff6ff', color: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                        <Users size={24} />
                    </div>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                        User Management
                    </h3>
                    <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
                        View registered users and assign or update account permissions.
                    </p>
                </Link>

                <Link to="/admin/activity" className="card card-hover" style={{ padding: '1.75rem', textDecoration: 'none' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#ecfdf5', color: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                        <Activity size={24} />
                    </div>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                        Activity Monitoring
                    </h3>
                    <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
                        Complete audit log of user registrations, logins, and property events.
                    </p>
                </Link>

                <Link to="/admin/analytics" className="card card-hover" style={{ padding: '1.75rem', textDecoration: 'none' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#f5f3ff', color: '#7c3aed', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                        <BarChart3 size={24} />
                    </div>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                        Visual Analytics
                    </h3>
                    <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
                        Interactive charts for property types, locations, and budget brackets.
                    </p>
                </Link>

                <Link to="/database-design" className="card card-hover" style={{ padding: '1.75rem', textDecoration: 'none' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#f8fafc', border: '1px solid #cbd5e1', color: '#0f172a', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                        <Database size={24} />
                    </div>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                        Database Schema
                    </h3>
                    <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
                        Visual ER diagram displaying all 8 tables, PK/FK relationships.
                    </p>
                </Link>
            </div>

            {/* Recent Activity Audit Preview */}
            <div style={{ background: '#ffffff', borderRadius: '20px', border: '1px solid var(--border-light)', padding: '2rem', boxShadow: 'var(--shadow-sm)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                    <h2 style={{ fontSize: '1.35rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Activity size={20} color="#2563eb" /> Recent System Activities
                    </h2>
                    <Link to="/admin/activity" style={{ fontWeight: '600', fontSize: '0.9rem' }}>
                        View Full Activity Log <ArrowRight size={14} />
                    </Link>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                    {stats?.recent_activities?.map((act) => (
                        <div key={act.log_id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.85rem 1rem', background: '#f8fafc', borderRadius: '10px', border: '1px solid #e2e8f0', flexWrap: 'wrap', gap: '0.5rem' }}>
                            <div>
                                <span style={{ fontWeight: '700', color: 'var(--primary-dark)' }}>{act.action}: </span>
                                <span style={{ color: '#475569', fontSize: '0.9rem' }}>{act.description}</span>
                            </div>
                            <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                                {new Date(act.created_at).toLocaleString()}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

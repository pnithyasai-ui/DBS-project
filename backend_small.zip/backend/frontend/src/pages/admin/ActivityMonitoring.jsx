import React, { useState, useEffect } from 'react';
import { adminApi } from '../../services/api';
import { Activity, Clock, User, Filter, Loader2, Search, RotateCcw } from 'lucide-react';

export default function ActivityMonitoring() {
    const [logs, setLogs] = useState([]);
    const [filterAction, setFilterAction] = useState('All');
    const [searchQuery, setSearchQuery] = useState('');
    const [loading, setLoading] = useState(true);

    const fetchLogs = async () => {
        try {
            setLoading(true);
            const res = await adminApi.getActivityLogs();
            if (res.data && res.data.success) {
                setLogs(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load activity logs:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLogs();
    }, []);

    const actionTypes = [
        'All',
        'User Registered',
        'User Login',
        'Property Added',
        'Property Updated',
        'Property Deleted',
        'Property Verified',
        'Property Rejected',
        'Enquiry Created',
        'Role Changed'
    ];

    const filteredLogs = logs.filter(log => {
        const matchesAction = filterAction === 'All' || log.action === filterAction;
        const matchesQuery = !searchQuery.trim() ||
            (log.description && log.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (log.user_name && log.user_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (log.user_email && log.user_email.toLowerCase().includes(searchQuery.toLowerCase())) ||
            log.action.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesAction && matchesQuery;
    });

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
                <div>
                    <h1 className="page-title">Activity Monitoring &amp; Audit Trail</h1>
                    <p className="page-subtitle">Real-time chronological log of authentication, listing approvals, and permission updates from MySQL</p>
                </div>
                <button onClick={fetchLogs} className="btn btn-secondary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <RotateCcw size={14} /> Refresh Logs
                </button>
            </div>

            {/* Filter & Search Bar */}
            <div style={{
                display: 'flex',
                gap: '1rem',
                marginBottom: '1.75rem',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                background: '#ffffff',
                padding: '1.25rem',
                borderRadius: '16px',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-xs)'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: 1, minWidth: '240px' }}>
                    <Search size={18} color="#64748b" />
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Search audit trail by actor, keyword, or listing..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        style={{ border: 'none', background: 'transparent', padding: '0.25rem 0' }}
                    />
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <Filter size={16} color="#64748b" />
                    <span style={{ fontSize: '0.85rem', fontWeight: '600', color: '#475569' }}>Filter Action:</span>
                    <select
                        className="form-control"
                        style={{ width: 'auto', minWidth: '180px' }}
                        value={filterAction}
                        onChange={(e) => setFilterAction(e.target.value)}
                    >
                        {actionTypes.map(a => (
                            <option key={a} value={a}>{a}</option>
                        ))}
                    </select>
                </div>
            </div>

            <div style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '1rem' }}>
                Showing <strong>{filteredLogs.length}</strong> of {logs.length} logged event(s)
            </div>

            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p style={{ color: '#64748b' }}>Loading audit logs...</p>
                </div>
            ) : filteredLogs.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">📋</div>
                    <h3 className="empty-title">No matching audit logs found</h3>
                    <p className="empty-desc">No events found matching your search or action filter.</p>
                </div>
            ) : (
                <div className="table-responsive" style={{ background: '#ffffff', borderRadius: '16px', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Log ID</th>
                                <th>Action</th>
                                <th>User / Actor</th>
                                <th>Description</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredLogs.map((log) => (
                                <tr key={log.log_id}>
                                    <td style={{ fontWeight: '700', color: '#94a3b8' }}>#{log.log_id}</td>
                                    <td>
                                        <span style={{
                                            padding: '0.3rem 0.65rem',
                                            borderRadius: '8px',
                                            fontSize: '0.8rem',
                                            fontWeight: '700',
                                            background: log.action.includes('Verified') ? '#ecfdf5' : log.action.includes('Rejected') ? '#fef2f2' : log.action.includes('Login') ? '#eff6ff' : '#f1f5f9',
                                            color: log.action.includes('Verified') ? '#059669' : log.action.includes('Rejected') ? '#dc2626' : log.action.includes('Login') ? '#2563eb' : '#1e293b'
                                        }}>
                                            {log.action}
                                        </span>
                                    </td>
                                    <td>
                                        <div style={{ fontWeight: '700' }}>{log.user_name || 'System / Guest'}</div>
                                        {log.user_role && (
                                            <span className={`role-badge ${log.user_role}`} style={{ fontSize: '0.7rem' }}>
                                                {log.user_role}
                                            </span>
                                        )}
                                    </td>
                                    <td style={{ color: '#334155', maxWidth: '440px', lineHeight: '1.5' }}>
                                        {log.description}
                                    </td>
                                    <td style={{ fontSize: '0.85rem', color: '#64748b', whiteSpace: 'nowrap' }}>
                                        {new Date(log.created_at).toLocaleString()}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Building2, Lock, Mail, ShieldAlert, CheckCircle2, User, KeyRound } from 'lucide-react';

export default function Login() {
    const { role } = useParams(); // 'user' | 'owner' | 'agent' | 'admin' from /login/:role
    const navigate = useNavigate();
    const { login, isAuthenticated, user } = useAuth();

    const activePortal = role || 'user';

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Redirect if already authenticated
    useEffect(() => {
        if (isAuthenticated && user) {
            redirectBasedOnRole(user.role);
        }
    }, [isAuthenticated, user]);

    const redirectBasedOnRole = (userRole) => {
        if (userRole === 'admin') navigate('/admin/dashboard');
        else if (userRole === 'owner') navigate('/owner-dashboard');
        else if (userRole === 'agent') navigate('/agent-dashboard');
        else navigate('/dashboard');
    };

    // Portal titles and descriptions
    const portalConfig = {
        user: {
            title: 'User Login',
            subtitle: 'Find your perfect property',
            badge: 'Buyer & Renter Portal',
            badgeClass: 'user'
        },
        owner: {
            title: 'Owner Login',
            subtitle: 'Manage your properties',
            badge: 'Property Owner Portal',
            badgeClass: 'owner'
        },
        agent: {
            title: 'Agent Login',
            subtitle: 'Manage your listings',
            badge: 'Real Estate Agent Portal',
            badgeClass: 'agent'
        },
        admin: {
            title: 'Admin Login',
            subtitle: 'Manage PropertyPortal',
            badge: 'System Administrator Portal',
            badgeClass: 'admin'
        }
    };

    const currentConfig = portalConfig[activePortal] || portalConfig.user;

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setLoading(true);

        try {
            const loggedInUser = await login(email, password, activePortal);
            redirectBasedOnRole(loggedInUser.role);
        } catch (err) {
            setError(err.response?.data?.message || err.message || 'Login failed. Please verify credentials.');
        } finally {
            setLoading(false);
        }
    };

    // Quick autofill helper for seamless evaluation
    const fillTestAccount = (testEmail, testPass) => {
        setEmail(testEmail);
        setPassword(testPass);
        setError(null);
    };

    return (
        <div className="container" style={{ padding: '4rem 1.5rem 6rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{
                maxWidth: '480px',
                width: '100%',
                background: '#ffffff',
                borderRadius: '24px',
                padding: '2.5rem',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-lg)'
            }}>
                {/* Portal Switcher Tabs */}
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(4, 1fr)',
                    background: '#f1f5f9',
                    padding: '4px',
                    borderRadius: '12px',
                    marginBottom: '2rem'
                }}>
                    {['user', 'owner', 'agent', 'admin'].map((p) => (
                        <button
                            key={p}
                            type="button"
                            onClick={() => {
                                setError(null);
                                navigate(`/login/${p}`);
                            }}
                            style={{
                                border: 'none',
                                padding: '0.5rem 0',
                                borderRadius: '8px',
                                fontSize: '0.825rem',
                                fontWeight: '700',
                                textTransform: 'capitalize',
                                cursor: 'pointer',
                                transition: 'var(--transition)',
                                background: activePortal === p ? '#ffffff' : 'transparent',
                                color: activePortal === p ? 'var(--primary)' : 'var(--text-muted)',
                                boxShadow: activePortal === p ? 'var(--shadow-xs)' : 'none'
                            }}
                        >
                            {p}
                        </button>
                    ))}
                </div>

                {/* Portal Identity Header */}
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <span className={`role-badge ${currentConfig.badgeClass}`} style={{ marginBottom: '0.75rem' }}>
                        {currentConfig.badge}
                    </span>
                    <h1 style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--primary-dark)', marginBottom: '0.25rem' }}>
                        {currentConfig.title}
                    </h1>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
                        {currentConfig.subtitle}
                    </p>
                </div>

                {/* Error Box */}
                {error && (
                    <div style={{
                        padding: '0.85rem 1rem',
                        background: '#fef2f2',
                        border: '1px solid #fecaca',
                        borderRadius: '10px',
                        color: '#b91c1c',
                        fontSize: '0.9rem',
                        marginBottom: '1.5rem',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem'
                    }}>
                        <ShieldAlert size={18} />
                        <span>{error}</span>
                    </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <Mail size={15} color="#2563eb" />
                            <span>Email Address</span>
                        </label>
                        <input
                            type="email"
                            className="form-control"
                            required
                            placeholder="name@example.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div className="form-group">
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <Lock size={15} color="#2563eb" />
                            <span>Password</span>
                        </label>
                        <input
                            type="password"
                            className="form-control"
                            required
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className="btn btn-primary"
                        style={{ width: '100%', padding: '0.85rem', marginTop: '0.5rem' }}
                    >
                        {loading ? 'Authenticating...' : `Sign in to ${currentConfig.title}`}
                    </button>
                </form>

                {/* Register Link */}
                <div style={{ textAlign: 'center', marginTop: '1.75rem', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                    Don't have an account?{' '}
                    <Link to="/register" style={{ fontWeight: '700', color: 'var(--primary-light)' }}>
                        Register here
                    </Link>
                </div>
            </div>

            {/* Quick Test Accounts Box */}
            <div style={{
                maxWidth: '480px',
                width: '100%',
                marginTop: '2rem',
                background: '#f8fafc',
                border: '1.5px dashed #cbd5e1',
                borderRadius: '16px',
                padding: '1.25rem'
            }}>
                <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#475569', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <KeyRound size={15} color="#2563eb" />
                    <span>Quick Autofill Test Accounts:</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                    <button
                        type="button"
                        onClick={() => {
                            navigate('/login/admin');
                            fillTestAccount('admin@propertyportal.com', 'admin123');
                        }}
                        style={{
                            padding: '0.5rem',
                            fontSize: '0.775rem',
                            borderRadius: '8px',
                            border: '1px solid #e2e8f0',
                            background: '#ffffff',
                            cursor: 'pointer',
                            textAlign: 'left'
                        }}
                    >
                        <div style={{ fontWeight: '700', color: '#dc2626' }}>👑 Admin</div>
                        <div style={{ color: '#64748b' }}>admin@propertyportal.com</div>
                    </button>

                    <button
                        type="button"
                        onClick={() => {
                            navigate('/login/owner');
                            fillTestAccount('owner@propertyportal.com', 'owner123');
                        }}
                        style={{
                            padding: '0.5rem',
                            fontSize: '0.775rem',
                            borderRadius: '8px',
                            border: '1px solid #e2e8f0',
                            background: '#ffffff',
                            cursor: 'pointer',
                            textAlign: 'left'
                        }}
                    >
                        <div style={{ fontWeight: '700', color: '#b45309' }}>🏡 Owner</div>
                        <div style={{ color: '#64748b' }}>owner@propertyportal.com</div>
                    </button>

                    <button
                        type="button"
                        onClick={() => {
                            navigate('/login/agent');
                            fillTestAccount('agent@propertyportal.com', 'agent123');
                        }}
                        style={{
                            padding: '0.5rem',
                            fontSize: '0.775rem',
                            borderRadius: '8px',
                            border: '1px solid #e2e8f0',
                            background: '#ffffff',
                            cursor: 'pointer',
                            textAlign: 'left'
                        }}
                    >
                        <div style={{ fontWeight: '700', color: '#1d4ed8' }}>🏢 Agent</div>
                        <div style={{ color: '#64748b' }}>agent@propertyportal.com</div>
                    </button>

                    <button
                        type="button"
                        onClick={() => {
                            navigate('/login/user');
                            fillTestAccount('user@propertyportal.com', 'user123');
                        }}
                        style={{
                            padding: '0.5rem',
                            fontSize: '0.775rem',
                            borderRadius: '8px',
                            border: '1px solid #e2e8f0',
                            background: '#ffffff',
                            cursor: 'pointer',
                            textAlign: 'left'
                        }}
                    >
                        <div style={{ fontWeight: '700', color: '#047857' }}>👤 Buyer/User</div>
                        <div style={{ color: '#64748b' }}>user@propertyportal.com</div>
                    </button>
                </div>
            </div>
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { propertyApi, enquiryApi, favoriteApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useCompare } from '../context/CompareContext';
import PropertyCard from '../components/PropertyCard';
import EmiCalculator from '../components/EmiCalculator';
import {
    MapPin, Maximize2, Bed, Bath, Heart, Send, CheckCircle,
    User, Phone, Mail, Shield, ArrowLeft, Check, AlertCircle,
    Scale, ZoomIn, X, ChevronLeft, ChevronRight, Share2
} from 'lucide-react';

export default function PropertyDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { user, isAuthenticated } = useAuth();
    const toast = useToast();
    const { addToCompare, isInCompare } = useCompare();

    const [property, setProperty] = useState(null);
    const [selectedImage, setSelectedImage] = useState(null);
    const [lightboxOpen, setLightboxOpen] = useState(false);
    const [lightboxIndex, setLightboxIndex] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Similar Properties
    const [similarProperties, setSimilarProperties] = useState([]);
    const [loadingSimilar, setLoadingSimilar] = useState(false);

    // Favorite state
    const [isFav, setIsFav] = useState(false);
    const [favLoading, setFavLoading] = useState(false);

    // Enquiry Modal State
    const [showEnquiryModal, setShowEnquiryModal] = useState(false);
    const [enquiryForm, setEnquiryForm] = useState({
        name: user?.name || '',
        email: user?.email || '',
        phone: user?.phone || '',
        message: 'Hello, I am interested in this property. Please contact me with more information.'
    });
    const [enquirySubmitting, setEnquirySubmitting] = useState(false);
    const [enquirySuccess, setEnquirySuccess] = useState(null);
    const [enquiryError, setEnquiryError] = useState(null);

    useEffect(() => {
        async function fetchDetails() {
            try {
                setLoading(true);
                setError(null);
                const res = await propertyApi.getById(id);
                if (res.data && res.data.success) {
                    const prop = res.data.data;
                    setProperty(prop);
                    setSelectedImage(prop.primary_image || (prop.images && prop.images[0]));
                    setIsFav(prop.is_favorite || false);

                    // Track recently viewed in localStorage
                    try {
                        const viewedRaw = localStorage.getItem('property_portal_recently_viewed');
                        let viewed = viewedRaw ? JSON.parse(viewedRaw) : [];
                        viewed = [prop, ...viewed.filter(p => p.property_id !== prop.property_id)].slice(0, 8);
                        localStorage.setItem('property_portal_recently_viewed', JSON.stringify(viewed));
                    } catch (e) {
                        console.error('Failed to save recently viewed:', e);
                    }
                } else {
                    setError('Property not found.');
                }
            } catch (err) {
                console.error('Error fetching property details:', err);
                setError('Failed to load property details.');
            } finally {
                setLoading(false);
            }
        }

        async function fetchSimilar() {
            try {
                setLoadingSimilar(true);
                const res = await propertyApi.getSimilar(id);
                if (res.data && res.data.success) {
                    setSimilarProperties(res.data.data);
                }
            } catch (err) {
                console.error('Error fetching similar properties:', err);
            } finally {
                setLoadingSimilar(false);
            }
        }

        fetchDetails();
        fetchSimilar();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, [id]);

    const isCompared = property ? isInCompare(property.property_id) : false;

    const handleFavoriteToggle = async () => {
        if (!isAuthenticated) {
            toast.info('Please log in to save properties to your favorites.', 'Login Required');
            navigate('/login/user');
            return;
        }

        try {
            setFavLoading(true);
            if (isFav) {
                await favoriteApi.remove(id);
                setIsFav(false);
                toast.info('Removed from your saved favorites.', 'Favorite Removed');
            } else {
                await favoriteApi.add(id);
                setIsFav(true);
                toast.success('Saved to your favorites!', 'Favorite Added');
            }
        } catch (err) {
            console.error('Favorite error:', err);
            toast.error('Could not update favorite status.', 'Error');
        } finally {
            setFavLoading(false);
        }
    };

    const handleCompareClick = () => {
        if (!property) return;
        addToCompare(property);
    };

    const handleShare = () => {
        if (navigator.share) {
            navigator.share({
                title: property?.title,
                text: `Check out this listing on PropertyPortal: ${property?.title}`,
                url: window.location.href
            }).catch(() => {});
        } else {
            navigator.clipboard.writeText(window.location.href);
            toast.success('Property link copied to clipboard!', 'Link Copied');
        }
    };

    const handleEnquirySubmit = async (e) => {
        e.preventDefault();
        if (!isAuthenticated) {
            toast.info('Please log in to submit property enquiries.', 'Login Required');
            navigate('/login/user');
            return;
        }

        try {
            setEnquirySubmitting(true);
            setEnquiryError(null);
            const payload = {
                property_id: property.property_id,
                name: enquiryForm.name,
                email: enquiryForm.email,
                phone: enquiryForm.phone,
                message: enquiryForm.message
            };
            const res = await enquiryApi.send(payload);
            if (res.data && res.data.success) {
                setEnquirySuccess('Your enquiry has been successfully submitted! The owner/agent has been notified.');
                toast.success('Enquiry sent successfully! The seller will contact you soon.', 'Enquiry Submitted');
                setTimeout(() => {
                    setShowEnquiryModal(false);
                    setEnquirySuccess(null);
                }, 2000);
            }
        } catch (err) {
            const msg = err.response?.data?.message || 'Failed to submit enquiry. Please try again.';
            setEnquiryError(msg);
            toast.error(msg, 'Submission Failed');
        } finally {
            setEnquirySubmitting(false);
        }
    };

    const openLightbox = (index) => {
        setLightboxIndex(index);
        setLightboxOpen(true);
    };

    const nextLightboxImage = () => {
        if (!property?.images?.length) return;
        setLightboxIndex((prev) => (prev + 1) % property.images.length);
    };

    const prevLightboxImage = () => {
        if (!property?.images?.length) return;
        setLightboxIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
    };

    if (loading) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                <div className="spinner" style={{ margin: '0 auto 1.5rem' }}></div>
                <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Loading property details...</p>
            </div>
        );
    }

    if (error || !property) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                <h2 style={{ color: '#dc2626', marginBottom: '1rem', fontSize: '1.75rem' }}>{error || 'Property Not Found'}</h2>
                <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem' }}>
                    The property listing you requested may have been removed or is unavailable.
                </p>
                <Link to="/properties" className="btn btn-primary">
                    <ArrowLeft size={16} /> Back to Properties
                </Link>
            </div>
        );
    }

    const isLand = ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(property.property_type);
    const imagesList = property.images && property.images.length > 0 ? property.images : [property.primary_image];

    return (
        <div className="property-details-page container" style={{ padding: '2.5rem 1.5rem 6rem' }}>
            {/* Back link & breadcrumbs */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '0.75rem' }}>
                <Link to="/properties" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontWeight: '600', fontSize: '0.925rem' }}>
                    <ArrowLeft size={16} /> Back to All Properties
                </Link>
                <button
                    onClick={handleShare}
                    className="btn btn-secondary btn-sm"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                    <Share2 size={15} /> Share Listing
                </button>
            </div>

            {/* Header: Title, Price, Location, Actions */}
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                flexWrap: 'wrap',
                gap: '1.5rem',
                marginBottom: '2rem'
            }}>
                <div style={{ maxWidth: '800px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                        <span className={`status-badge ${property.availability?.toLowerCase()}`}>
                            {property.availability}
                        </span>
                        {property.verification_status === 'Verified' && (
                            <span className="status-badge verified">
                                <CheckCircle size={13} /> Verified Listing
                            </span>
                        )}
                        <span className="role-badge agent">
                            {property.property_type}
                        </span>
                    </div>

                    <h1 style={{ fontSize: '2.25rem', fontWeight: '800', color: 'var(--primary-dark)', marginBottom: '0.5rem' }}>
                        {property.title}
                    </h1>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-muted)', fontSize: '1.05rem' }}>
                        <MapPin size={18} color="#2563eb" />
                        <span>{property.location}</span>
                    </div>
                </div>

                <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '2.4rem', fontWeight: '900', color: 'var(--primary)', fontFamily: 'Outfit', lineHeight: 1.1 }}>
                        {property.formatted_price}
                    </div>
                    {property.area && property.price && (
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
                            ≈ ₹{Math.round(property.price / property.area).toLocaleString('en-IN')} / sq.ft
                        </div>
                    )}
                    <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem', justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                        {/* Compare Button */}
                        <button
                            onClick={handleCompareClick}
                            className={`btn ${isCompared ? 'btn-primary' : 'btn-secondary'}`}
                            title={isCompared ? 'Remove from comparison' : 'Add to side-by-side comparison'}
                        >
                            <Scale size={16} />
                            <span>{isCompared ? 'Compared' : 'Compare'}</span>
                        </button>

                        {/* Favorite Button */}
                        <button
                            onClick={handleFavoriteToggle}
                            disabled={favLoading}
                            className="btn btn-secondary"
                            style={{ color: isFav ? '#ef4444' : 'inherit' }}
                        >
                            <Heart size={18} fill={isFav ? '#ef4444' : 'none'} color={isFav ? '#ef4444' : '#64748b'} />
                            <span>{isFav ? 'Favorited' : 'Save Favorite'}</span>
                        </button>

                        {/* Send Enquiry */}
                        <button
                            onClick={() => setShowEnquiryModal(true)}
                            className="btn btn-primary"
                        >
                            <Send size={16} />
                            <span>Send Enquiry</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* High-Resolution Image Gallery with Lightbox trigger */}
            <div style={{ marginBottom: '2.5rem' }}>
                <div
                    onClick={() => openLightbox(imagesList.indexOf(selectedImage) >= 0 ? imagesList.indexOf(selectedImage) : 0)}
                    style={{
                        position: 'relative',
                        width: '100%',
                        height: '500px',
                        borderRadius: '24px',
                        overflow: 'hidden',
                        backgroundColor: '#0f172a',
                        boxShadow: 'var(--shadow-lg)',
                        cursor: 'pointer',
                        marginBottom: '1rem'
                    }}
                >
                    <img
                        src={selectedImage}
                        alt={property.title}
                        style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.4s ease' }}
                    />
                    <div style={{
                        position: 'absolute',
                        bottom: '16px',
                        right: '16px',
                        background: 'rgba(15, 23, 42, 0.75)',
                        backdropFilter: 'blur(8px)',
                        color: '#ffffff',
                        padding: '0.4rem 0.85rem',
                        borderRadius: '10px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.4rem',
                        fontSize: '0.85rem',
                        fontWeight: '600'
                    }}>
                        <ZoomIn size={16} /> Click to View Fullscreen ({imagesList.length} Photos)
                    </div>
                </div>

                {/* Thumbnails */}
                {imagesList.length > 1 && (
                    <div style={{ display: 'flex', gap: '1rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
                        {imagesList.map((img, idx) => (
                            <img
                                key={idx}
                                src={img}
                                alt={`Thumbnail ${idx + 1}`}
                                onClick={() => setSelectedImage(img)}
                                style={{
                                    width: '110px',
                                    height: '75px',
                                    borderRadius: '12px',
                                    objectFit: 'cover',
                                    cursor: 'pointer',
                                    border: selectedImage === img ? '3px solid #2563eb' : '2px solid transparent',
                                    opacity: selectedImage === img ? 1 : 0.65,
                                    transition: 'var(--transition)'
                                }}
                            />
                        ))}
                    </div>
                )}
            </div>

            {/* Lightbox Modal */}
            {lightboxOpen && (
                <div
                    className="modal-backdrop"
                    onClick={() => setLightboxOpen(false)}
                    style={{ zIndex: 9999, background: 'rgba(0, 0, 0, 0.92)' }}
                >
                    <div style={{ position: 'relative', maxWidth: '1100px', width: '90%', maxHeight: '90vh', display: 'flex', flexDirection: 'column', alignItems: 'center' }} onClick={(e) => e.stopPropagation()}>
                        <button
                            onClick={() => setLightboxOpen(false)}
                            style={{
                                position: 'absolute',
                                top: '-45px',
                                right: '0',
                                background: 'transparent',
                                border: 'none',
                                color: '#ffffff',
                                cursor: 'pointer'
                            }}
                        >
                            <X size={32} />
                        </button>
                        <img
                            src={imagesList[lightboxIndex]}
                            alt=""
                            style={{ maxWidth: '100%', maxHeight: '80vh', borderRadius: '16px', objectFit: 'contain' }}
                        />
                        {imagesList.length > 1 && (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', marginTop: '1rem', color: '#ffffff' }}>
                                <button onClick={prevLightboxImage} className="btn btn-secondary btn-icon">
                                    <ChevronLeft size={20} />
                                </button>
                                <span>{lightboxIndex + 1} of {imagesList.length}</span>
                                <button onClick={nextLightboxImage} className="btn btn-secondary btn-icon">
                                    <ChevronRight size={20} />
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Two Column Layout: Specifications / Description / Amenities vs Contact Card */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                gap: '2.5rem',
                alignItems: 'flex-start'
            }}>
                {/* Left Column */}
                <div style={{ gridColumn: 'span 2' }}>
                    {/* Key Specifications Grid */}
                    <div style={{
                        background: '#ffffff',
                        padding: '1.75rem',
                        borderRadius: '20px',
                        border: '1px solid var(--border-light)',
                        marginBottom: '2rem',
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
                        gap: '1.5rem',
                        boxShadow: 'var(--shadow-sm)'
                    }}>
                        <div>
                            <div style={{ color: '#64748b', fontSize: '0.85rem', marginBottom: '0.25rem' }}>Area</div>
                            <div style={{ fontSize: '1.15rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--primary-dark)' }}>
                                <Maximize2 size={16} color="#2563eb" />
                                {property.area?.toLocaleString('en-IN')} sq.ft
                            </div>
                        </div>

                        {!isLand && property.bedrooms && (
                            <div>
                                <div style={{ color: '#64748b', fontSize: '0.85rem', marginBottom: '0.25rem' }}>Bedrooms</div>
                                <div style={{ fontSize: '1.15rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--primary-dark)' }}>
                                    <Bed size={16} color="#2563eb" />
                                    {property.bedrooms} BHK
                                </div>
                            </div>
                        )}

                        {!isLand && property.bathrooms && (
                            <div>
                                <div style={{ color: '#64748b', fontSize: '0.85rem', marginBottom: '0.25rem' }}>Bathrooms</div>
                                <div style={{ fontSize: '1.15rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--primary-dark)' }}>
                                    <Bath size={16} color="#2563eb" />
                                    {property.bathrooms} Baths
                                </div>
                            </div>
                        )}

                        <div>
                            <div style={{ color: '#64748b', fontSize: '0.85rem', marginBottom: '0.25rem' }}>Furnishing</div>
                            <div style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--primary-dark)' }}>
                                {property.furnishing || 'N/A'}
                            </div>
                        </div>

                        <div>
                            <div style={{ color: '#64748b', fontSize: '0.85rem', marginBottom: '0.25rem' }}>Parking</div>
                            <div style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--primary-dark)' }}>
                                {property.parking || 'N/A'}
                            </div>
                        </div>
                    </div>

                    {/* Description */}
                    <div style={{ background: '#ffffff', padding: '2rem', borderRadius: '20px', border: '1px solid var(--border-light)', marginBottom: '2rem', boxShadow: 'var(--shadow-sm)' }}>
                        <h2 style={{ fontSize: '1.35rem', fontWeight: '800', marginBottom: '1rem', color: 'var(--primary-dark)' }}>Property Overview &amp; Description</h2>
                        <p style={{ color: '#475569', lineHeight: '1.75', fontSize: '1rem', whiteSpace: 'pre-line' }}>
                            {property.description || 'No specific description provided for this listing.'}
                        </p>
                    </div>

                    {/* Amenities & Features */}
                    {property.amenities && property.amenities.length > 0 && (
                        <div style={{ background: '#ffffff', padding: '2rem', borderRadius: '20px', border: '1px solid var(--border-light)', marginBottom: '2rem', boxShadow: 'var(--shadow-sm)' }}>
                            <h2 style={{ fontSize: '1.35rem', fontWeight: '800', marginBottom: '1.25rem', color: 'var(--primary-dark)' }}>
                                Verified Amenities &amp; Facilities
                            </h2>
                            <div style={{
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                                gap: '1rem'
                            }}>
                                {property.amenities.map((amenity) => (
                                    <div
                                        key={amenity.amenity_id}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '0.65rem',
                                            padding: '0.85rem 1rem',
                                            background: '#f8fafc',
                                            borderRadius: '12px',
                                            border: '1px solid #e2e8f0',
                                            fontWeight: '700',
                                            fontSize: '0.9rem',
                                            color: '#1e293b'
                                        }}
                                    >
                                        <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#1d4ed8' }}>
                                            <Check size={14} />
                                        </div>
                                        <span>{amenity.name}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Indian Real Estate EMI Calculator */}
                    <EmiCalculator defaultPropertyPrice={property.price} />
                </div>

                {/* Right Column: Contact Seller & Owner Profile */}
                <div style={{
                    background: '#ffffff',
                    padding: '2rem',
                    borderRadius: '24px',
                    border: '1.5px solid var(--border-light)',
                    boxShadow: 'var(--shadow-md)',
                    position: 'sticky',
                    top: '90px'
                }}>
                    <h3 style={{ fontSize: '1.2rem', fontWeight: '800', marginBottom: '1.25rem', color: 'var(--primary-dark)' }}>
                        Listed By {property.owner_role === 'agent' ? 'Real Estate Agent' : 'Property Owner'}
                    </h3>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                        <div style={{
                            width: '56px',
                            height: '56px',
                            borderRadius: '50%',
                            background: '#eff6ff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#2563eb'
                        }}>
                            <User size={28} />
                        </div>
                        <div>
                            <div style={{ fontWeight: '800', fontSize: '1.1rem', color: 'var(--text-primary)' }}>
                                {property.owner_name}
                            </div>
                            <span className={`role-badge ${property.owner_role}`} style={{ fontSize: '0.725rem' }}>
                                {property.owner_role}
                            </span>
                        </div>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', marginBottom: '1.75rem', fontSize: '0.925rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', color: '#475569' }}>
                            <Phone size={16} color="#2563eb" />
                            <span>{property.owner_phone || '+91 Contact Verified'}</span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', color: '#475569' }}>
                            <Mail size={16} color="#2563eb" />
                            <span>{property.owner_email}</span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', color: '#059669', fontSize: '0.85rem', fontWeight: '700' }}>
                            <Shield size={16} /> Verified Contact Information
                        </div>
                    </div>

                    <button
                        onClick={() => setShowEnquiryModal(true)}
                        className="btn btn-primary"
                        style={{ width: '100%', height: '48px', fontSize: '1rem', fontWeight: '700' }}
                    >
                        <Send size={16} /> Send Enquiry
                    </button>
                </div>
            </div>

            {/* Similar Properties Section */}
            {similarProperties.length > 0 && (
                <section style={{ marginTop: '5rem', paddingTop: '3rem', borderTop: '1px solid var(--border-light)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
                        <div>
                            <h2 className="section-title" style={{ fontSize: '1.85rem' }}>Similar Verified Properties</h2>
                            <p className="section-subtitle">
                                Other active listings in {property.location} and matching {property.property_type} category
                            </p>
                        </div>
                        <Link to={`/properties?propertyType=${encodeURIComponent(property.property_type)}`} className="btn btn-secondary">
                            View More {property.property_type}s
                        </Link>
                    </div>

                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                        gap: '1.75rem'
                    }}>
                        {similarProperties.map((p) => (
                            <PropertyCard key={p.property_id} property={p} />
                        ))}
                    </div>
                </section>
            )}

            {/* Enquiry Modal */}
            {showEnquiryModal && (
                <div className="modal-backdrop" onClick={() => setShowEnquiryModal(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3 className="modal-title">Send Enquiry</h3>
                            <button
                                onClick={() => setShowEnquiryModal(false)}
                                style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#64748b' }}
                            >
                                &times;
                            </button>
                        </div>

                        <form onSubmit={handleEnquirySubmit}>
                            <div className="modal-body">
                                <div style={{ background: '#f8fafc', padding: '0.85rem 1rem', borderRadius: '10px', marginBottom: '1.25rem', border: '1px solid #e2e8f0' }}>
                                    <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Enquiring about:</div>
                                    <div style={{ fontWeight: '800', color: 'var(--primary)' }}>{property.title}</div>
                                    <div style={{ fontSize: '0.85rem', color: '#475569' }}>{property.location} • {property.formatted_price}</div>
                                </div>

                                {enquirySuccess && (
                                    <div style={{ padding: '0.75rem 1rem', background: '#ecfdf5', color: '#047857', borderRadius: '8px', marginBottom: '1rem', border: '1px solid #a7f3d0' }}>
                                        {enquirySuccess}
                                    </div>
                                )}

                                {enquiryError && (
                                    <div style={{ padding: '0.75rem 1rem', background: '#fef2f2', color: '#b91c1c', borderRadius: '8px', marginBottom: '1rem', border: '1px solid #fecaca' }}>
                                        {enquiryError}
                                    </div>
                                )}

                                <div className="form-group">
                                    <label className="form-label">Full Name</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        required
                                        value={enquiryForm.name}
                                        onChange={(e) => setEnquiryForm({ ...enquiryForm, name: e.target.value })}
                                    />
                                </div>

                                <div className="form-group">
                                    <label className="form-label">Email Address</label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        required
                                        value={enquiryForm.email}
                                        onChange={(e) => setEnquiryForm({ ...enquiryForm, email: e.target.value })}
                                    />
                                </div>

                                <div className="form-group">
                                    <label className="form-label">Contact Phone Number</label>
                                    <input
                                        type="tel"
                                        className="form-control"
                                        required
                                        placeholder="+91 9876543210"
                                        value={enquiryForm.phone}
                                        onChange={(e) => setEnquiryForm({ ...enquiryForm, phone: e.target.value })}
                                    />
                                </div>

                                <div className="form-group">
                                    <label className="form-label">Message</label>
                                    <textarea
                                        className="form-control"
                                        rows={4}
                                        required
                                        value={enquiryForm.message}
                                        onChange={(e) => setEnquiryForm({ ...enquiryForm, message: e.target.value })}
                                    ></textarea>
                                </div>
                            </div>

                            <div className="modal-footer">
                                <button
                                    type="button"
                                    onClick={() => setShowEnquiryModal(false)}
                                    className="btn btn-secondary"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={enquirySubmitting}
                                    className="btn btn-primary"
                                >
                                    {enquirySubmitting ? 'Sending...' : 'Submit Enquiry'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

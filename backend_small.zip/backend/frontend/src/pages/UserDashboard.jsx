import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { favoriteApi, enquiryApi, propertyApi } from '../services/api';
import PropertyCard from '../components/PropertyCard';
import { Heart, MessageSquare, Clock, Compass, ArrowRight, User } from 'lucide-react';

export default function UserDashboard() {
    const { user } = useAuth();
    const [favorites, setFavorites] = useState([]);
    const [enquiries, setEnquiries] = useState([]);
    const [recommended, setRecommended] = useState([]);
    const [recentlyViewed, setRecentlyViewed] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadDashboardData() {
            try {
                setLoading(true);
                const [favRes, enqRes, featRes] = await Promise.all([
                    favoriteApi.getAll(),
                    enquiryApi.getUserEnquiries(),
                    propertyApi.getFeatured()
                ]);

                if (favRes.data?.success) setFavorites(favRes.data.data);
                if (enqRes.data?.success) setEnquiries(enqRes.data.data);
                if (featRes.data?.success) setRecommended(featRes.data.data.slice(0, 3));

                // Load recently viewed from localStorage
                try {
                    const viewed = localStorage.getItem('property_portal_recently_viewed');
                    if (viewed) setRecentlyViewed(JSON.parse(viewed).slice(0, 3));
                } catch (e) {
                    console.error('Failed to parse recently viewed:', e);
                }
            } catch (err) {
                console.error('Error loading buyer dashboard:', err);
            } finally {
                setLoading(false);
            }
        }
        loadDashboardData();
    }, []);

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            {/* Header Banner */}
            <div style={{
                background: 'linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%)',
                color: '#ffffff',
                padding: '2.5rem',
                borderRadius: '24px',
                marginBottom: '2.5rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '1.5rem'
            }}>
                <div>
                    <span className="role-badge user" style={{ marginBottom: '0.75rem' }}>
                        Buyer / Tenant Portal
                    </span>
                    <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#ffffff', marginBottom: '0.25rem' }}>
                        Welcome back, {user?.name}!
                    </h1>
                    <p style={{ color: '#bfdbfe', fontSize: '1rem' }}>
                        Track your shortlisted properties, active enquiries, and personalized recommendations.
                    </p>
                </div>
                <Link to="/properties" className="btn btn-accent btn-lg">
                    <Compass size={18} /> Browse Properties
                </Link>
            </div>

            {/* Quick Metrics */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                gap: '1.5rem',
                marginBottom: '3rem'
            }}>
                <div className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ width: '50px', height: '50px', borderRadius: '12px', background: '#fef2f2', color: '#ef4444', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Heart size={26} />
                    </div>
                    <div>
                        <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--primary-dark)' }}>{favorites.length}</div>
                        <div style={{ color: '#64748b', fontSize: '0.875rem' }}>Saved Properties</div>
                    </div>
                </div>

                <div className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ width: '50px', height: '50px', borderRadius: '12px', background: '#eff6ff', color: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <MessageSquare size={26} />
                    </div>
                    <div>
                        <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--primary-dark)' }}>{enquiries.length}</div>
                        <div style={{ color: '#64748b', fontSize: '0.875rem' }}>Sent Enquiries</div>
                    </div>
                </div>

                <div className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ width: '50px', height: '50px', borderRadius: '12px', background: '#ecfdf5', color: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Clock size={26} />
                    </div>
                    <div>
                        <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--primary-dark)' }}>{recentlyViewed.length}</div>
                        <div style={{ color: '#64748b', fontSize: '0.875rem' }}>Recently Viewed</div>
                    </div>
                </div>
            </div>

            {/* Recently Viewed */}
            {recentlyViewed.length > 0 && (
                <div style={{ marginBottom: '3rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                        <h2 style={{ fontSize: '1.4rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Clock size={20} color="#2563eb" /> Recently Viewed Properties
                        </h2>
                    </div>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                        gap: '1.5rem'
                    }}>
                        {recentlyViewed.map((prop) => (
                            <PropertyCard key={prop.property_id} property={prop} />
                        ))}
                    </div>
                </div>
            )}

            {/* Recommended Properties */}
            {recommended.length > 0 && (
                <div style={{ marginBottom: '3rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                        <h2 style={{ fontSize: '1.4rem', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <Compass size={20} color="#2563eb" /> Recommended For You
                        </h2>
                        <Link to="/properties" style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: '600' }}>
                            View More <ArrowRight size={15} />
                        </Link>
                    </div>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                        gap: '1.5rem'
                    }}>
                        {recommended.map((prop) => (
                            <PropertyCard key={prop.property_id} property={prop} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { propertyApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PROPERTY_TYPES } from '../utils/formatters';
import { PlusCircle, Image, Plus, Trash2, CheckCircle2, ArrowLeft, Loader2, AlertCircle } from 'lucide-react';

export default function AddEditProperty() {
    const { id } = useParams(); // If id exists -> Edit mode
    const isEditMode = Boolean(id);
    const navigate = useNavigate();
    const { user, isOwner } = useAuth();
    const toast = useToast();

    const [form, setForm] = useState({
        title: '',
        description: '',
        location: '',
        price: '',
        property_type: 'Apartment',
        area: '',
        bedrooms: '2',
        bathrooms: '2',
        furnishing: 'Semi-Furnished',
        parking: '1 Covered Car',
        availability: 'Available',
        images: ['https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80'],
        amenity_ids: []
    });

    const [availableAmenities, setAvailableAmenities] = useState([]);
    const [loading, setLoading] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState(null);
    const [newImageUrl, setNewImageUrl] = useState('');

    const isLand = ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(form.property_type);
    const isCommercial = ['Office', 'Shop', 'Warehouse'].includes(form.property_type);

    useEffect(() => {
        async function loadInitData() {
            try {
                setLoading(true);
                // Load amenities
                const amenRes = await propertyApi.getAmenities();
                if (amenRes.data?.success) {
                    setAvailableAmenities(amenRes.data.data);
                }

                // If editing, load property details
                if (isEditMode) {
                    const propRes = await propertyApi.getById(id);
                    if (propRes.data?.success) {
                        const p = propRes.data.data;
                        // Verify ownership if not admin
                        if (p.user_id !== user.user_id && user.role !== 'admin') {
                            setError('Access Denied: You cannot edit a property you do not own.');
                            return;
                        }

                        setForm({
                            title: p.title || '',
                            description: p.description || '',
                            location: p.location || '',
                            price: p.price || '',
                            property_type: p.property_type || 'Apartment',
                            area: p.area || '',
                            bedrooms: p.bedrooms?.toString() || '2',
                            bathrooms: p.bathrooms?.toString() || '2',
                            furnishing: p.furnishing || 'N/A',
                            parking: p.parking || 'N/A',
                            availability: p.availability || 'Available',
                            images: p.images && p.images.length > 0 ? p.images : ['https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80'],
                            amenity_ids: p.amenities ? p.amenities.map(a => a.amenity_id) : []
                        });
                    }
                }
            } catch (err) {
                console.error('Failed to load init data:', err);
                setError('Failed to load form details.');
            } finally {
                setLoading(false);
            }
        }
        loadInitData();
    }, [id, isEditMode, user]);

    const handleAmenityToggle = (amenityId) => {
        setForm(prev => {
            const exists = prev.amenity_ids.includes(amenityId);
            return {
                ...prev,
                amenity_ids: exists
                    ? prev.amenity_ids.filter(a => a !== amenityId)
                    : [...prev.amenity_ids, amenityId]
            };
        });
    };

    const handleAddImage = () => {
        if (newImageUrl.trim()) {
            setForm(prev => ({
                ...prev,
                images: [...prev.images, newImageUrl.trim()]
            }));
            setNewImageUrl('');
        }
    };

    const handleRemoveImage = (index) => {
        setForm(prev => ({
            ...prev,
            images: prev.images.filter((_, idx) => idx !== index)
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setSubmitting(true);

        try {
            const payload = {
                title: form.title,
                description: form.description,
                location: form.location,
                price: parseFloat(form.price),
                property_type: form.property_type,
                area: parseInt(form.area),
                bedrooms: isLand || isCommercial ? null : parseInt(form.bedrooms),
                bathrooms: isLand ? null : parseInt(form.bathrooms),
                furnishing: isLand ? 'N/A' : form.furnishing,
                parking: form.parking,
                availability: form.availability,
                images: form.images.length > 0 ? form.images : ['https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80'],
                amenity_ids: form.amenity_ids
            };

            if (isEditMode) {
                await propertyApi.update(id, payload);
                toast.success('Property details updated successfully!');
            } else {
                await propertyApi.create(payload);
                if (user?.role === 'admin') {
                    toast.success('Property listing published and verified immediately!');
                } else {
                    toast.success('Property listing submitted! Pending admin review.');
                }
            }

            navigate('/my-properties');
        } catch (err) {
            console.error('Error saving property:', err);
            const errDetail = err.response?.data?.message || 'Failed to save property listing.';
            setError(errDetail);
            toast.error(errDetail);
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return (
            <div className="container" style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
                <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                <p>Loading property form...</p>
            </div>
        );
    }

    return (
        <div className="container" style={{ padding: '3rem 1.5rem 6rem' }}>
            <div style={{ marginBottom: '1.5rem' }}>
                <Link to="/my-properties" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontWeight: '600' }}>
                    <ArrowLeft size={16} /> Back to My Listings
                </Link>
            </div>

            <div style={{
                maxWidth: '860px',
                margin: '0 auto',
                background: '#ffffff',
                borderRadius: '24px',
                padding: '2.5rem',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-md)'
            }}>
                <div style={{ marginBottom: '2rem', borderBottom: '1px solid var(--border-light)', paddingBottom: '1.25rem' }}>
                    <h1 style={{ fontSize: '1.85rem', fontWeight: '800', color: 'var(--primary-dark)' }}>
                        {isEditMode ? 'Edit Property Listing' : 'Add New Property Listing'}
                    </h1>
                    <p style={{ color: '#64748b', fontSize: '0.95rem', marginTop: '0.25rem' }}>
                        {user.role === 'admin' 
                            ? 'Admin submissions are automatically verified and published immediately.' 
                            : 'New listings submitted by owners & agents are sent to admin for verification.'}
                    </p>
                </div>

                {error && (
                    <div style={{ padding: '0.85rem 1rem', background: '#fef2f2', color: '#b91c1c', borderRadius: '10px', marginBottom: '1.5rem', border: '1px solid #fecaca', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <AlertCircle size={18} />
                        <span>{error}</span>
                    </div>
                )}

                <form onSubmit={handleSubmit}>
                    {/* Basic Information */}
                    <div className="form-group">
                        <label className="form-label">Property Title *</label>
                        <input
                            type="text"
                            className="form-control"
                            required
                            placeholder="e.g. Spacious 3 BHK Luxury Flat in Bachupally"
                            value={form.title}
                            onChange={(e) => setForm({ ...form, title: e.target.value })}
                        />
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem' }}>
                        <div className="form-group">
                            <label className="form-label">Property Category / Type *</label>
                            <select
                                className="form-control"
                                value={form.property_type}
                                onChange={(e) => setForm({ ...form, property_type: e.target.value })}
                            >
                                {PROPERTY_TYPES.filter(t => t !== 'All Types').map(t => (
                                    <option key={t} value={t}>{t}</option>
                                ))}
                            </select>
                        </div>

                        <div className="form-group">
                            <label className="form-label">Location (City / Area) *</label>
                            <input
                                type="text"
                                className="form-control"
                                required
                                placeholder="e.g. Gachibowli, Hyderabad"
                                value={form.location}
                                onChange={(e) => setForm({ ...form, location: e.target.value })}
                            />
                        </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem' }}>
                        <div className="form-group">
                            <label className="form-label">Price (in ₹ INR) *</label>
                            <input
                                type="number"
                                className="form-control"
                                required
                                min="100000"
                                step="10000"
                                placeholder="e.g. 6500000 for ₹65 Lakhs"
                                value={form.price}
                                onChange={(e) => setForm({ ...form, price: e.target.value })}
                            />
                            <div style={{ fontSize: '0.8rem', color: '#2563eb', marginTop: '0.25rem' }}>
                                Format: Enter exact numeric rupees (e.g. 6500000 = ₹65 Lakhs)
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="form-label">Area (in sq.ft) *</label>
                            <input
                                type="number"
                                className="form-control"
                                required
                                min="100"
                                placeholder="e.g. 1450"
                                value={form.area}
                                onChange={(e) => setForm({ ...form, area: e.target.value })}
                            />
                        </div>
                    </div>

                    {/* Adaptive fields: Bedrooms / Bathrooms only for residential */}
                    {!isLand && (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem' }}>
                            {!isCommercial && (
                                <div className="form-group">
                                    <label className="form-label">Bedrooms (BHK)</label>
                                    <select
                                        className="form-control"
                                        value={form.bedrooms}
                                        onChange={(e) => setForm({ ...form, bedrooms: e.target.value })}
                                    >
                                        <option value="1">1 BHK</option>
                                        <option value="2">2 BHK</option>
                                        <option value="3">3 BHK</option>
                                        <option value="4">4 BHK</option>
                                        <option value="5">5+ BHK</option>
                                    </select>
                                </div>
                            )}

                            <div className="form-group">
                                <label className="form-label">Bathrooms</label>
                                <select
                                    className="form-control"
                                    value={form.bathrooms}
                                    onChange={(e) => setForm({ ...form, bathrooms: e.target.value })}
                                >
                                    <option value="1">1 Bathroom</option>
                                    <option value="2">2 Bathrooms</option>
                                    <option value="3">3 Bathrooms</option>
                                    <option value="4">4 Bathrooms</option>
                                    <option value="5">5+ Bathrooms</option>
                                </select>
                            </div>

                            <div className="form-group">
                                <label className="form-label">Furnishing</label>
                                <select
                                    className="form-control"
                                    value={form.furnishing}
                                    onChange={(e) => setForm({ ...form, furnishing: e.target.value })}
                                >
                                    <option value="Furnished">Furnished</option>
                                    <option value="Semi-Furnished">Semi-Furnished</option>
                                    <option value="Unfurnished">Unfurnished</option>
                                    <option value="N/A">N/A</option>
                                </select>
                            </div>
                        </div>
                    )}

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem' }}>
                        <div className="form-group">
                            <label className="form-label">Parking Details</label>
                            <input
                                type="text"
                                className="form-control"
                                placeholder="e.g. 1 Covered Car, 2 Bikes"
                                value={form.parking}
                                onChange={(e) => setForm({ ...form, parking: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Availability Status</label>
                            <select
                                className="form-control"
                                value={form.availability}
                                onChange={(e) => setForm({ ...form, availability: e.target.value })}
                            >
                                <option value="Available">Available</option>
                                <option value="Sold">Sold</option>
                                <option value="Rented">Rented</option>
                            </select>
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Full Description</label>
                        <textarea
                            className="form-control"
                            rows={4}
                            placeholder="Detail property specifications, layout, neighbourhood highlights, and special features..."
                            value={form.description}
                            onChange={(e) => setForm({ ...form, description: e.target.value })}
                        ></textarea>
                    </div>

                    {/* Image URLs Manager */}
                    <div style={{ marginBottom: '2rem', padding: '1.5rem', background: '#f8fafc', borderRadius: '16px', border: '1px solid var(--border-light)' }}>
                        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.75rem' }}>
                            <Image size={18} color="#2563eb" />
                            <span>Property Images (URLs)</span>
                        </label>

                        {/* Existing image previews */}
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
                            {form.images.map((imgUrl, idx) => (
                                <div key={idx} style={{ position: 'relative', width: '130px', height: '90px', borderRadius: '10px', overflow: 'hidden', border: '1px solid #cbd5e1' }}>
                                    <img src={imgUrl} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                    <button
                                        type="button"
                                        onClick={() => handleRemoveImage(idx)}
                                        style={{
                                            position: 'absolute',
                                            top: '4px',
                                            right: '4px',
                                            background: 'rgba(239, 68, 68, 0.9)',
                                            color: '#fff',
                                            border: 'none',
                                            borderRadius: '50%',
                                            width: '24px',
                                            height: '24px',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}
                                        title="Remove Image"
                                    >
                                        &times;
                                    </button>
                                </div>
                            ))}
                        </div>

                        {/* Add image input */}
                        <div style={{ display: 'flex', gap: '0.75rem' }}>
                            <input
                                type="url"
                                className="form-control"
                                placeholder="Paste image URL (e.g. Unsplash or direct photo link)"
                                value={newImageUrl}
                                onChange={(e) => setNewImageUrl(e.target.value)}
                            />
                            <button
                                type="button"
                                onClick={handleAddImage}
                                className="btn btn-secondary"
                            >
                                <Plus size={16} /> Add Image
                            </button>
                        </div>
                    </div>

                    {/* Amenities Checklist */}
                    <div style={{ marginBottom: '2.5rem' }}>
                        <label className="form-label" style={{ marginBottom: '0.85rem', display: 'block' }}>
                            Select Amenities &amp; Key Features
                        </label>
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
                            gap: '0.75rem'
                        }}>
                            {availableAmenities.map((amenity) => {
                                const checked = form.amenity_ids.includes(amenity.amenity_id);
                                return (
                                    <label
                                        key={amenity.amenity_id}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '0.6rem',
                                            padding: '0.75rem 1rem',
                                            borderRadius: '10px',
                                            border: checked ? '1.5px solid var(--primary-light)' : '1px solid var(--border-light)',
                                            background: checked ? 'var(--primary-surface)' : '#ffffff',
                                            cursor: 'pointer',
                                            fontWeight: '600',
                                            fontSize: '0.875rem'
                                        }}
                                    >
                                        <input
                                            type="checkbox"
                                            checked={checked}
                                            onChange={() => handleAmenityToggle(amenity.amenity_id)}
                                        />
                                        <span>{amenity.name}</span>
                                    </label>
                                );
                            })}
                        </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem', borderTop: '1px solid var(--border-light)', paddingTop: '1.5rem' }}>
                        <Link to="/my-properties" className="btn btn-secondary">
                            Cancel
                        </Link>
                        <button
                            type="submit"
                            disabled={submitting}
                            className="btn btn-primary btn-lg"
                        >
                            {submitting ? 'Saving Property...' : (isEditMode ? 'Update Property' : 'Submit Property for Listing')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

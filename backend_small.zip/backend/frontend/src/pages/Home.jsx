import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { propertyApi } from '../services/api';
import PropertyCard from '../components/PropertyCard';
import { CATEGORY_CARDS, BUDGET_OPTIONS, POPULAR_LOCATIONS, PROPERTY_TYPES } from '../utils/formatters';
import {
    Search, MapPin, Building, IndianRupee, Bed, ShieldCheck,
    CheckCircle2, TrendingUp, Users, ArrowRight, Sparkles, Clock, PlusCircle
} from 'lucide-react';

export default function Home() {
    const navigate = useNavigate();

    // Search Panel State
    const [searchLocation, setSearchLocation] = useState('');
    const [searchType, setSearchType] = useState('');
    const [searchBudget, setSearchBudget] = useState('');
    const [searchBedrooms, setSearchBedrooms] = useState('Any');

    // Featured Properties State
    const [featured, setFeatured] = useState([]);
    const [loadingFeatured, setLoadingFeatured] = useState(true);

    // Recently Viewed State
    const [recentlyViewed, setRecentlyViewed] = useState([]);

    useEffect(() => {
        async function fetchFeatured() {
            try {
                const res = await propertyApi.getFeatured();
                if (res.data && res.data.success) {
                    setFeatured(res.data.data);
                }
            } catch (err) {
                console.error('Failed to load featured properties:', err);
            } finally {
                setLoadingFeatured(false);
            }
        }

        // Load recently viewed
        try {
            const viewedRaw = localStorage.getItem('property_portal_recently_viewed');
            if (viewedRaw) {
                setRecentlyViewed(JSON.parse(viewedRaw));
            }
        } catch (e) {
            console.error('Error loading recently viewed:', e);
        }

        fetchFeatured();
    }, []);

    // Handle Search submit
    const handleSearchSubmit = (e) => {
        e.preventDefault();
        const params = new URLSearchParams();
        if (searchLocation) params.set('location', searchLocation);
        if (searchType && searchType !== 'All Types') params.set('propertyType', searchType);
        if (searchBudget) params.set('budget', searchBudget);
        if (searchBedrooms && searchBedrooms !== 'Any') params.set('bedrooms', searchBedrooms);

        navigate(`/properties?${params.toString()}`);
    };

    // Category click handler
    const handleCategoryClick = (categoryType) => {
        navigate(`/properties?propertyType=${encodeURIComponent(categoryType)}`);
    };

    // Budget click handler
    const handleBudgetClick = (budgetId) => {
        navigate(`/properties?budget=${encodeURIComponent(budgetId)}`);
    };

    // Location click handler
    const handleLocationClick = (loc) => {
        navigate(`/properties?location=${encodeURIComponent(loc)}`);
    };

    return (
        <div className="home-page">
            {/* 1. HERO SECTION */}
            <section className="hero-section">
                <div className="hero-pattern"></div>
                <div className="container hero-content">
                    <div style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        padding: '0.4rem 1rem',
                        background: 'rgba(255, 255, 255, 0.15)',
                        backdropFilter: 'blur(8px)',
                        borderRadius: '999px',
                        color: '#f8fafc',
                        fontSize: '0.85rem',
                        fontWeight: '700',
                        marginBottom: '1.25rem',
                        border: '1px solid rgba(255, 255, 255, 0.25)'
                    }}>
                        <Sparkles size={15} color="#f59e0b" /> Verified Real Estate Portal
                    </div>

                    <h1 className="hero-heading">
                        Find Your Perfect Property
                    </h1>
                    <p className="hero-subtitle">
                        Discover verified apartments, villas, independent houses, open plots, and commercial spaces across India's fastest-growing localities.
                    </p>

                    {/* 2. UNIFIED SEARCH PANEL */}
                    <div className="search-panel">
                        <form onSubmit={handleSearchSubmit}>
                            <div className="search-grid">
                                {/* Location */}
                                <div className="form-group" style={{ marginBottom: 0, textAlign: 'left' }}>
                                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                        <MapPin size={15} color="#2563eb" />
                                        <span>Location</span>
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="City or area (e.g. Hyderabad, Bachupally)"
                                        value={searchLocation}
                                        onChange={(e) => setSearchLocation(e.target.value)}
                                    />
                                </div>

                                {/* Property Type */}
                                <div className="form-group" style={{ marginBottom: 0, textAlign: 'left' }}>
                                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                        <Building size={15} color="#2563eb" />
                                        <span>Property Type</span>
                                    </label>
                                    <select
                                        className="form-control"
                                        value={searchType}
                                        onChange={(e) => setSearchType(e.target.value)}
                                    >
                                        {PROPERTY_TYPES.map((t) => (
                                            <option key={t} value={t === 'All Types' ? '' : t}>{t}</option>
                                        ))}
                                    </select>
                                </div>

                                {/* Budget Range */}
                                <div className="form-group" style={{ marginBottom: 0, textAlign: 'left' }}>
                                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                        <IndianRupee size={15} color="#2563eb" />
                                        <span>Budget</span>
                                    </label>
                                    <select
                                        className="form-control"
                                        value={searchBudget}
                                        onChange={(e) => setSearchBudget(e.target.value)}
                                    >
                                        {BUDGET_OPTIONS.map((b) => (
                                            <option key={b.id} value={b.id}>{b.label}</option>
                                        ))}
                                    </select>
                                </div>

                                {/* Bedrooms */}
                                <div className="form-group" style={{ marginBottom: 0, textAlign: 'left' }}>
                                    <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                                        <Bed size={15} color="#2563eb" />
                                        <span>Bedrooms</span>
                                    </label>
                                    <select
                                        className="form-control"
                                        value={searchBedrooms}
                                        onChange={(e) => setSearchBedrooms(e.target.value)}
                                    >
                                        <option value="Any">Any BHK</option>
                                        <option value="1">1 BHK</option>
                                        <option value="2">2 BHK</option>
                                        <option value="3">3 BHK</option>
                                        <option value="4">4 BHK</option>
                                        <option value="5+">5+ BHK</option>
                                    </select>
                                </div>

                                {/* Search Button */}
                                <button type="submit" className="btn btn-primary btn-lg" style={{ height: '48px', fontWeight: '700' }}>
                                    <Search size={18} />
                                    <span>Search</span>
                                </button>
                            </div>
                        </form>
                    </div>

                    {/* Quick Stats Banner under Search */}
                    <div style={{
                        display: 'flex',
                        justifyContent: 'center',
                        gap: '2.5rem',
                        marginTop: '2.5rem',
                        flexWrap: 'wrap',
                        color: 'rgba(255, 255, 255, 0.9)'
                    }}>
                        <div style={{ textAlign: 'center' }}>
                            <div style={{ fontSize: '1.6rem', fontWeight: '800', fontFamily: 'Outfit' }}>100%</div>
                            <div style={{ fontSize: '0.8rem', opacity: 0.8 }}>Admin Verified</div>
                        </div>
                        <div style={{ textAlign: 'center' }}>
                            <div style={{ fontSize: '1.6rem', fontWeight: '800', fontFamily: 'Outfit' }}>₹0</div>
                            <div style={{ fontSize: '0.8rem', opacity: 0.8 }}>Buyer Brokerage</div>
                        </div>
                        <div style={{ textAlign: 'center' }}>
                            <div style={{ fontSize: '1.6rem', fontWeight: '800', fontFamily: 'Outfit' }}>10+</div>
                            <div style={{ fontSize: '0.8rem', opacity: 0.8 }}>Prime Localities</div>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3. PROPERTY CATEGORIES SECTION */}
            <section style={{ padding: '5rem 0 3rem' }}>
                <div className="container">
                    <div className="section-title-wrap">
                        <h2 className="section-title">Explore Property Categories</h2>
                        <p className="section-subtitle">
                            Browse curated categories tailored to your residential comfort or commercial investment goals
                        </p>
                    </div>

                    <div className="category-grid">
                        {CATEGORY_CARDS.map((cat) => (
                            <div
                                key={cat.title}
                                className="category-card"
                                onClick={() => handleCategoryClick(cat.type)}
                                role="button"
                                tabIndex={0}
                            >
                                <div className="category-icon">{cat.icon}</div>
                                <div className="category-name">{cat.title}</div>
                                <div className="category-desc">{cat.desc}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* 4. BUDGET CATEGORIES SECTION */}
            <section style={{ padding: '3rem 0 5rem', background: '#f8fafc' }}>
                <div className="container">
                    <div className="section-title-wrap">
                        <h2 className="section-title">Find Properties by Budget</h2>
                        <p className="section-subtitle">
                            Discover listings mapped precisely to your budget range in Indian currency
                        </p>
                    </div>

                    <div className="budget-grid">
                        {BUDGET_OPTIONS.filter(b => b.id !== '').map((b) => (
                            <button
                                key={b.id}
                                className="budget-chip"
                                onClick={() => handleBudgetClick(b.id)}
                            >
                                {b.label}
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            {/* 5. FEATURED PROPERTIES SECTION */}
            <section style={{ padding: '4rem 0 5rem' }}>
                <div className="container">
                    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: '2.5rem', flexWrap: 'wrap', gap: '1rem' }}>
                        <div>
                            <h2 className="section-title">Featured Properties</h2>
                            <p className="section-subtitle">Handpicked, verified premium properties ready for occupancy</p>
                        </div>
                        <button onClick={() => navigate('/properties')} className="btn btn-secondary">
                            <span>View All Properties</span>
                            <ArrowRight size={16} />
                        </button>
                    </div>

                    {loadingFeatured ? (
                        <div style={{ textAlign: 'center', padding: '3rem' }}>
                            <div className="spinner" style={{ margin: '0 auto 1rem' }}></div>
                            <p style={{ color: 'var(--text-muted)' }}>Loading featured properties...</p>
                        </div>
                    ) : featured.length === 0 ? (
                        <div className="empty-state">
                            <p className="empty-desc">No featured properties available at this moment.</p>
                        </div>
                    ) : (
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                            gap: '1.75rem'
                        }}>
                            {featured.map((prop) => (
                                <PropertyCard key={prop.property_id} property={prop} />
                            ))}
                        </div>
                    )}
                </div>
            </section>

            {/* 6. RECENTLY VIEWED PROPERTIES (If available) */}
            {recentlyViewed.length > 0 && (
                <section style={{ padding: '3rem 0 5rem', background: '#f8fafc', borderTop: '1px solid var(--border-light)' }}>
                    <div className="container">
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2rem' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                                <Clock size={22} color="var(--primary)" />
                                <div>
                                    <h2 className="section-title" style={{ fontSize: '1.6rem', margin: 0 }}>Recently Viewed Properties</h2>
                                    <p className="section-subtitle" style={{ margin: 0 }}>Pick up where you left off</p>
                                </div>
                            </div>
                        </div>

                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                            gap: '1.5rem'
                        }}>
                            {recentlyViewed.slice(0, 4).map((p) => (
                                <PropertyCard key={p.property_id} property={p} />
                            ))}
                        </div>
                    </div>
                </section>
            )}

            {/* 7. POPULAR LOCATIONS SECTION */}
            <section style={{ padding: '4rem 0', background: '#ffffff', borderTop: '1px solid var(--border-light)', borderBottom: '1px solid var(--border-light)' }}>
                <div className="container">
                    <div className="section-title-wrap">
                        <h2 className="section-title">Popular Locations</h2>
                        <p className="section-subtitle">Explore high-growth hotspots and emerging neighborhoods</p>
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.85rem', justifyContent: 'center' }}>
                        {POPULAR_LOCATIONS.map((loc) => (
                            <button
                                key={loc}
                                onClick={() => handleLocationClick(loc)}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '0.5rem',
                                    background: '#f1f5f9',
                                    border: '1px solid #e2e8f0',
                                    borderRadius: '9999px',
                                    padding: '0.6rem 1.25rem',
                                    fontSize: '0.925rem',
                                    fontWeight: '600',
                                    color: '#1e293b',
                                    cursor: 'pointer',
                                    transition: 'var(--transition)'
                                }}
                            >
                                <MapPin size={15} color="#3b82f6" />
                                <span>{loc}</span>
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            {/* 8. WHY CHOOSE PROPERTYPORTAL */}
            <section style={{ padding: '5rem 0' }}>
                <div className="container">
                    <div className="section-title-wrap">
                        <h2 className="section-title">Why Choose PropertyPortal</h2>
                        <p className="section-subtitle">Empowering property buyers, owners, and agents with security, transparency, and live data</p>
                    </div>

                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
                        gap: '2rem'
                    }}>
                        <div style={{ background: '#ffffff', padding: '2rem', borderRadius: '20px', border: '1px solid var(--border-light)', textAlign: 'center', boxShadow: 'var(--shadow-sm)' }}>
                            <div style={{ width: '56px', height: '56px', background: '#ecfdf5', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.25rem', color: '#10b981' }}>
                                <ShieldCheck size={32} />
                            </div>
                            <h3 style={{ fontSize: '1.2rem', marginBottom: '0.5rem', color: 'var(--primary-dark)' }}>100% Verified Listings</h3>
                            <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: '1.6' }}>Every listing is verified by administrators before being made publicly visible.</p>
                        </div>

                        <div style={{ background: '#ffffff', padding: '2rem', borderRadius: '20px', border: '1px solid var(--border-light)', textAlign: 'center', boxShadow: 'var(--shadow-sm)' }}>
                            <div style={{ width: '56px', height: '56px', background: '#eff6ff', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.25rem', color: '#2563eb' }}>
                                <TrendingUp size={32} />
                            </div>
                            <h3 style={{ fontSize: '1.2rem', marginBottom: '0.5rem', color: 'var(--primary-dark)' }}>Predefined INR Budgets</h3>
                            <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: '1.6' }}>Curated Lakhs &amp; Crores budget bands with zero hidden charges or inflated quotes.</p>
                        </div>

                        <div style={{ background: '#ffffff', padding: '2rem', borderRadius: '20px', border: '1px solid var(--border-light)', textAlign: 'center', boxShadow: 'var(--shadow-sm)' }}>
                            <div style={{ width: '56px', height: '56px', background: '#fef3c7', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.25rem', color: '#d97706' }}>
                                <Users size={32} />
                            </div>
                            <h3 style={{ fontSize: '1.2rem', marginBottom: '0.5rem', color: 'var(--primary-dark)' }}>Direct Contact</h3>
                            <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: '1.6' }}>Send enquiries directly to listing owners and agents with live status updates.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 9. CALL TO ACTION FOR OWNERS & AGENTS */}
            <section style={{ padding: '0 0 5rem' }}>
                <div className="container">
                    <div style={{
                        background: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%)',
                        color: '#ffffff',
                        padding: '3.5rem 2.5rem',
                        borderRadius: '28px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        gap: '2rem',
                        boxShadow: 'var(--shadow-xl)'
                    }}>
                        <div style={{ maxWidth: '640px' }}>
                            <span className="role-badge owner" style={{ marginBottom: '1rem', background: '#451a03', color: '#fcd34d', border: '1px solid #78350f' }}>
                                Property Owners &amp; Agents
                            </span>
                            <h2 style={{ fontSize: '2.2rem', fontWeight: '800', color: '#ffffff', marginBottom: '0.75rem', lineHeight: '1.2' }}>
                                Are you an Owner or Real Estate Agent?
                            </h2>
                            <p style={{ color: '#cbd5e1', fontSize: '1.05rem', lineHeight: '1.6' }}>
                                Reach thousands of verified home seekers and investors. List your apartments, villas, plots, or commercial buildings with seamless enquiry tracking.
                            </p>
                        </div>

                        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                            <Link to="/add-property" className="btn btn-accent btn-lg">
                                <PlusCircle size={18} /> Post a Property
                            </Link>
                            <Link to="/login/owner" className="btn btn-secondary btn-lg" style={{ background: 'rgba(255, 255, 255, 0.15)', color: '#ffffff', border: '1px solid rgba(255, 255, 255, 0.3)' }}>
                                Owner Portal
                            </Link>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}

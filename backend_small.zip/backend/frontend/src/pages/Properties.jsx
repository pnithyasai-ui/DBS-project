import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { propertyApi } from '../services/api';
import PropertyCard from '../components/PropertyCard';
import PropertyFilterBar from '../components/PropertyFilterBar';
import Pagination from '../components/Pagination';
import { Home, FilterX, Loader2 } from 'lucide-react';

export default function Properties() {
    const [searchParams, setSearchParams] = useSearchParams();

    // Initialize filters from URL parameters
    const [filters, setFilters] = useState({
        location: searchParams.get('location') || '',
        propertyType: searchParams.get('propertyType') || '',
        budget: searchParams.get('budget') || '',
        bedrooms: searchParams.get('bedrooms') || 'Any',
        bathrooms: searchParams.get('bathrooms') || 'Any',
        minArea: searchParams.get('minArea') || '',
        maxArea: searchParams.get('maxArea') || '',
        availability: searchParams.get('availability') || 'All',
        furnishing: searchParams.get('furnishing') || 'All',
        amenities: searchParams.get('amenities') || '',
        sort: searchParams.get('sort') || 'newest',
        page: parseInt(searchParams.get('page')) || 1
    });

    const [properties, setProperties] = useState([]);
    const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 12, totalPages: 1 });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Sync URL when filters change
    const updateUrlParams = (newFilters) => {
        const params = new URLSearchParams();
        if (newFilters.location) params.set('location', newFilters.location);
        if (newFilters.propertyType) params.set('propertyType', newFilters.propertyType);
        if (newFilters.budget) params.set('budget', newFilters.budget);
        if (newFilters.bedrooms && newFilters.bedrooms !== 'Any') params.set('bedrooms', newFilters.bedrooms);
        if (newFilters.bathrooms && newFilters.bathrooms !== 'Any') params.set('bathrooms', newFilters.bathrooms);
        if (newFilters.minArea) params.set('minArea', newFilters.minArea);
        if (newFilters.maxArea) params.set('maxArea', newFilters.maxArea);
        if (newFilters.availability && newFilters.availability !== 'All') params.set('availability', newFilters.availability);
        if (newFilters.furnishing && newFilters.furnishing !== 'All') params.set('furnishing', newFilters.furnishing);
        if (newFilters.amenities) params.set('amenities', newFilters.amenities);
        if (newFilters.sort && newFilters.sort !== 'newest') params.set('sort', newFilters.sort);
        if (newFilters.page && newFilters.page > 1) params.set('page', newFilters.page.toString());

        setSearchParams(params, { replace: true });
    };

    const fetchProperties = async (currentFilters) => {
        try {
            setLoading(true);
            setError(null);
            const params = {
                location: currentFilters.location || undefined,
                propertyType: currentFilters.propertyType || undefined,
                budget: currentFilters.budget || undefined,
                bedrooms: currentFilters.bedrooms !== 'Any' ? currentFilters.bedrooms : undefined,
                bathrooms: currentFilters.bathrooms !== 'Any' ? currentFilters.bathrooms : undefined,
                minArea: currentFilters.minArea || undefined,
                maxArea: currentFilters.maxArea || undefined,
                availability: currentFilters.availability !== 'All' ? currentFilters.availability : undefined,
                furnishing: currentFilters.furnishing !== 'All' ? currentFilters.furnishing : undefined,
                amenities: currentFilters.amenities || undefined,
                sort: currentFilters.sort || 'newest',
                page: currentFilters.page || 1,
                limit: 12
            };

            const res = await propertyApi.getAll(params);
            if (res.data && res.data.success) {
                setProperties(res.data.data.properties);
                setPagination(res.data.data.pagination);
            }
        } catch (err) {
            console.error('Error fetching properties:', err);
            setError('Unable to load properties. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const nextFilters = {
            location: searchParams.get('location') || '',
            propertyType: searchParams.get('propertyType') || '',
            budget: searchParams.get('budget') || '',
            bedrooms: searchParams.get('bedrooms') || 'Any',
            bathrooms: searchParams.get('bathrooms') || 'Any',
            minArea: searchParams.get('minArea') || '',
            maxArea: searchParams.get('maxArea') || '',
            availability: searchParams.get('availability') || 'All',
            furnishing: searchParams.get('furnishing') || 'All',
            amenities: searchParams.get('amenities') || '',
            sort: searchParams.get('sort') || 'newest',
            page: parseInt(searchParams.get('page')) || 1
        };
        setFilters(nextFilters);
        fetchProperties(nextFilters);
    }, [searchParams]);

    const handleFilterChange = (newFilters) => {
        setFilters(newFilters);
        updateUrlParams(newFilters);
    };

    const handleClearFilters = () => {
        const resetFilters = {
            location: '',
            propertyType: '',
            budget: '',
            bedrooms: 'Any',
            bathrooms: 'Any',
            minArea: '',
            maxArea: '',
            availability: 'All',
            furnishing: 'All',
            amenities: '',
            sort: 'newest',
            page: 1
        };
        setFilters(resetFilters);
        updateUrlParams(resetFilters);
    };

    const handlePageChange = (newPage) => {
        const updated = { ...filters, page: newPage };
        setFilters(updated);
        updateUrlParams(updated);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (
        <div className="properties-page container" style={{ padding: '2.5rem 1.5rem 5rem' }}>
            {/* Page Header */}
            <div style={{ marginBottom: '1.75rem' }}>
                <h1 className="page-title">Explore Properties</h1>
                <p className="page-subtitle">
                    Showing {pagination.total} verified real estate listings matching your criteria
                </p>
            </div>

            {/* Smart Filter Bar */}
            <PropertyFilterBar
                filters={filters}
                onFilterChange={handleFilterChange}
                onClearFilters={handleClearFilters}
                onSearch={() => fetchProperties(filters)}
            />

            {/* Content States */}
            {loading ? (
                <div style={{ textAlign: 'center', padding: '5rem 1.5rem' }}>
                    <Loader2 size={36} className="animate-spin" color="#2563eb" style={{ margin: '0 auto 1rem' }} />
                    <p style={{ color: '#64748b', fontSize: '1.05rem', fontWeight: '500' }}>
                        Loading properties...
                    </p>
                </div>
            ) : error ? (
                <div className="empty-state">
                    <p style={{ color: '#dc2626', fontWeight: '600' }}>{error}</p>
                    <button onClick={() => fetchProperties(filters)} className="btn btn-secondary" style={{ marginTop: '1rem' }}>
                        Retry
                    </button>
                </div>
            ) : properties.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-icon">
                        <FilterX size={48} color="#94a3b8" />
                    </div>
                    <h3 className="empty-title">No properties found</h3>
                    <p className="empty-desc">
                        No properties found for your selected filters. Try broadening your location, budget, or bedroom criteria.
                    </p>
                    <button onClick={handleClearFilters} className="btn btn-primary" style={{ marginTop: '1rem' }}>
                        Reset All Filters
                    </button>
                </div>
            ) : (
                <>
                    {/* Properties Grid */}
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                        gap: '1.75rem',
                        marginBottom: '3rem'
                    }}>
                        {properties.map((property) => (
                            <PropertyCard key={property.property_id} property={property} />
                        ))}
                    </div>

                    {/* Pagination */}
                    {pagination.totalPages > 1 && (
                        <Pagination
                            currentPage={pagination.page}
                            totalPages={pagination.totalPages}
                            onPageChange={handlePageChange}
                        />
                    )}
                </>
            )}
        </div>
    );
}

import React, { createContext, useContext, useState, useEffect } from 'react';
import { authApi } from '../services/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [user, setUser] = useState(() => {
        const saved = localStorage.getItem('property_portal_user');
        try {
            return saved ? JSON.parse(saved) : null;
        } catch {
            return null;
        }
    });
    const [token, setToken] = useState(() => localStorage.getItem('property_portal_token') || null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadUser() {
            const savedToken = localStorage.getItem('property_portal_token');
            if (savedToken) {
                try {
                    const res = await authApi.getMe();
                    if (res.data && res.data.data) {
                        setUser(res.data.data.user);
                        localStorage.setItem('property_portal_user', JSON.stringify(res.data.data.user));
                    }
                } catch (err) {
                    console.error('Session expired or invalid:', err);
                    logout();
                }
            }
            setLoading(false);
        }
        loadUser();
    }, []);

    const login = async (email, password, portal) => {
        const res = await authApi.login({ email, password, portal });
        if (res.data && res.data.success) {
            const { user: loggedInUser, token: authToken } = res.data.data;
            setUser(loggedInUser);
            setToken(authToken);
            localStorage.setItem('property_portal_token', authToken);
            localStorage.setItem('property_portal_user', JSON.stringify(loggedInUser));
            return loggedInUser;
        } else {
            throw new Error(res.data.message || 'Login failed');
        }
    };

    const register = async (userData) => {
        const res = await authApi.register(userData);
        if (res.data && res.data.success) {
            const { user: registeredUser, token: authToken } = res.data.data;
            setUser(registeredUser);
            setToken(authToken);
            localStorage.setItem('property_portal_token', authToken);
            localStorage.setItem('property_portal_user', JSON.stringify(registeredUser));
            return registeredUser;
        } else {
            throw new Error(res.data.message || 'Registration failed');
        }
    };

    const logout = () => {
        setUser(null);
        setToken(null);
        localStorage.removeItem('property_portal_token');
        localStorage.removeItem('property_portal_user');
    };

    const updateUser = (updatedUser) => {
        setUser(updatedUser);
        localStorage.setItem('property_portal_user', JSON.stringify(updatedUser));
    };

    const value = {
        user,
        token,
        loading,
        login,
        register,
        logout,
        updateUser,
        isAuthenticated: !!user,
        isUser: user?.role === 'user',
        isOwner: user?.role === 'owner',
        isAgent: user?.role === 'agent',
        isAdmin: user?.role === 'admin',
        canManageListings: ['owner', 'agent', 'admin'].includes(user?.role)
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}

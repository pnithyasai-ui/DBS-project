import React, { createContext, useContext, useState, useCallback } from 'react';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
    const [toasts, setToasts] = useState([]);

    const removeToast = useCallback((id) => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
    }, []);

    const addToast = useCallback((type, message, title = '') => {
        const id = Date.now() + Math.random().toString(36).substr(2, 4);
        const newToast = { id, type, message, title };
        setToasts((prev) => [...prev, newToast]);

        setTimeout(() => {
            removeToast(id);
        }, 4000);
    }, [removeToast]);

    const success = useCallback((msg, title) => addToast('success', msg, title), [addToast]);
    const error = useCallback((msg, title) => addToast('error', msg, title), [addToast]);
    const info = useCallback((msg, title) => addToast('info', msg, title), [addToast]);
    const warning = useCallback((msg, title) => addToast('warning', msg, title), [addToast]);

    return (
        <ToastContext.Provider value={{ success, error, info, warning }}>
            {children}
            <div className="toast-container" aria-live="polite">
                {toasts.map((toast) => (
                    <div key={toast.id} className={`toast toast-${toast.type} animate-slide-in`}>
                        <div className="toast-icon">
                            {toast.type === 'success' && <CheckCircle2 size={20} color="#10b981" />}
                            {toast.type === 'error' && <AlertCircle size={20} color="#ef4444" />}
                            {toast.type === 'warning' && <AlertTriangle size={20} color="#f59e0b" />}
                            {toast.type === 'info' && <Info size={20} color="#3b82f6" />}
                        </div>
                        <div className="toast-content">
                            {toast.title && <div className="toast-title">{toast.title}</div>}
                            <div className="toast-message">{toast.message}</div>
                        </div>
                        <button
                            onClick={() => removeToast(toast.id)}
                            className="toast-close-btn"
                            aria-label="Close notification"
                        >
                            <X size={15} />
                        </button>
                    </div>
                ))}
            </div>
        </ToastContext.Provider>
    );
}

export function useToast() {
    const context = useContext(ToastContext);
    if (!context) {
        throw new Error('useToast must be used within a ToastProvider');
    }
    return context;
}

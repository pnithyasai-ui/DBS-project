import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from './ToastContext';

const CompareContext = createContext(null);

export function CompareProvider({ children }) {
    const toast = useToast();
    const [compareList, setCompareList] = useState(() => {
        try {
            const saved = localStorage.getItem('property_portal_compare');
            return saved ? JSON.parse(saved) : [];
        } catch {
            return [];
        }
    });

    useEffect(() => {
        try {
            localStorage.setItem('property_portal_compare', JSON.stringify(compareList));
        } catch (e) {
            console.error('Failed to save compare items:', e);
        }
    }, [compareList]);

    const addToCompare = (property) => {
        if (!property) return;
        if (compareList.some(p => p.property_id === property.property_id)) {
            removeFromCompare(property.property_id);
            return;
        }

        if (compareList.length >= 4) {
            toast.warning('You can compare a maximum of 4 properties simultaneously.', 'Comparison Limit Reached');
            return;
        }

        setCompareList(prev => [...prev, property]);
        toast.success(`"${property.title}" added to comparison.`, 'Added to Compare');
    };

    const removeFromCompare = (propertyId) => {
        setCompareList(prev => prev.filter(p => p.property_id !== propertyId));
        toast.info('Property removed from comparison.', 'Comparison Updated');
    };

    const isInCompare = (propertyId) => {
        return compareList.some(p => p.property_id === propertyId);
    };

    const clearCompare = () => {
        setCompareList([]);
        toast.info('Comparison cleared.', 'Comparison Reset');
    };

    return (
        <CompareContext.Provider value={{ compareList, addToCompare, removeFromCompare, isInCompare, clearCompare }}>
            {children}
        </CompareContext.Provider>
    );
}

export function useCompare() {
    const context = useContext(CompareContext);
    if (!context) {
        throw new Error('useCompare must be used within a CompareProvider');
    }
    return context;
}

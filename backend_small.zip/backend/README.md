# PropertyPortal – Property Listing Management & Analytics Portal

PropertyPortal is a production-grade full-stack real-estate marketplace and management platform connecting property buyers, owners, licensed brokers, and system administrators.

---

## 1. Technology Stack

- **Frontend**: React 18, React Router v6, Axios, Recharts, Lucide React, Modern CSS3 Design Tokens
- **Backend**: Node.js v24, Express.js, `mysql2/promise` (Connection Pooling), `bcryptjs`, `jsonwebtoken`
- **Database**: MySQL 8.0 (`property_portal` database with InnoDB engine, Foreign Keys, UTF8MB4)

---

## 2. Four User Roles & Permission Matrix

| Role | Browse & Search | Add Listing | Edit/Delete Own | Favorites & Enquiries | Verification Queue | User Mgmt | Analytics |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **USER (Buyer)** | ✅ | ❌ | ❌ | ✅ | ❌ (403) | ❌ (403) | ❌ (403) |
| **OWNER** | ✅ | ✅ (Pending) | ✅ (Own Only) | ✅ | ❌ (403) | ❌ (403) | ❌ (403) |
| **AGENT** | ✅ | ✅ (Pending) | ✅ (Own Only) | ✅ | ❌ (403) | ❌ (403) | ❌ (403) |
| **ADMIN** | ✅ | ✅ (Verified) | ✅ (All) | ✅ | ✅ | ✅ | ✅ |

---

## 3. Standard Test Accounts (Pre-Seeded)

| Role | Email | Password | Portal Login URL |
|:---|:---|:---|:---|
| **ADMIN** | `admin@propertyportal.com` | `admin123` | `http://localhost:5173/login/admin` |
| **OWNER** | `owner@propertyportal.com` | `owner123` | `http://localhost:5173/login/owner` |
| **AGENT** | `agent@propertyportal.com` | `agent123` | `http://localhost:5173/login/agent` |
| **USER** | `user@propertyportal.com` | `user123` | `http://localhost:5173/login/user` |

> 💡 All passwords are encrypted using `bcrypt` (10 rounds). The frontend login page also features 1-click test buttons to autofill credentials for testing.

---

## 4. How to Setup & Run

### A. Database Initialization
Make sure local MySQL 8.0 server is running (e.g. `MySQL80` service on port 3306).
```powershell
cd backend
# Runs schema creation and seeds 22 properties across all budget brackets and roles
node database/initDb.js
```

### B. Start the Backend API Server
```powershell
cd backend
npm install
npm run dev # or npm start
# Backend runs on http://localhost:5000
```

### C. Start the Frontend Application
```powershell
cd frontend
npm install --legacy-peer-deps
npm run dev
# Frontend runs on http://localhost:5173
```

---

## 5. Key Features Implemented

1. **Smart Search & Indian Currency Formatting**:
   - Location partial matching (e.g., typing `Bach` matches `Bachupally`, `Hyd` matches `Hyderabad`).
   - Adaptive property filters (residential displays BHK/Bathrooms/Furnishing; land/commercial hides bedroom fields).
   - Predefined realistic Indian budget ranges:
     - Under ₹25 Lakhs (0 - 25,00,000)
     - ₹25 Lakhs – ₹50 Lakhs
     - ₹50 Lakhs – ₹75 Lakhs
     - ₹75 Lakhs – ₹1 Crore
     - ₹1 Crore – ₹2 Crore
     - ₹2 Crore – ₹5 Crore
     - ₹5 Crore+
   - Sort by Newest, Oldest, Price Low/High, Area Small/Large.
   - Clear Filters button to reset all criteria.

2. **Property Details & Interactive Gallery**:
   - Multi-image showcase with thumbnail switching.
   - Amenities badges, location tags, and seller contact card.
   - Enquiry modal sending records directly to MySQL.
   - Favorite bookmarking with duplicate prevention.

3. **Ownership Security & Access Control**:
   - Owner A can never edit or delete Owner B's listings (verified on backend).
   - Public registration strictly rejects any attempt to register with `role = "admin"`.
   - Admin routes (`/admin/*`) and Admin APIs are protected by `requireAdmin` middleware, returning 403 Forbidden with clear messages.

4. **Admin Console & Visual Analytics**:
   - KPI metrics computed live from MySQL (total users, properties, available/sold/rented, average price).
   - Interactive charts via Recharts (Properties by Type, Budget Distribution, Location Volume, Availability, User Roles).
   - Property Verification queue with Approve / Reject workflows.
   - User Management table with live role updates.
   - Activity audit trail logging registrations, logins, listing actions, and role alterations.

5. **Visual Database Design**:
   - Dedicated page (`/database-design`) featuring interactive diagrams for all 8 tables, foreign key constraints, primary keys, and data types matching the actual MySQL schema.

---

## 6. REST API Reference

### Authentication
- `POST /api/auth/register`: Register User, Owner, or Agent
- `POST /api/auth/login`: Login with portal role verification
- `GET /api/auth/me`: Current user session
- `PUT /api/auth/profile`: Update profile info
- `PUT /api/auth/change-password`: Change password

### Properties
- `GET /api/properties`: Parameterized search with dynamic filters & pagination
- `GET /api/properties/featured`: Top verified featured listings
- `GET /api/properties/locations`: Popular locations and listing volumes
- `GET /api/properties/:id`: Single property with images and amenities
- `POST /api/properties`: Add listing (Owner, Agent, Admin)
- `PUT /api/properties/:id`: Edit listing (Ownership validated)
- `DELETE /api/properties/:id`: Delete listing (Ownership validated)
- `PATCH /api/properties/:id/availability`: Toggle Available / Sold / Rented
- `GET /api/properties/my-properties`: Logged-in user's properties

### Favorites & Enquiries
- `GET /api/favorites`: User's bookmarked properties
- `POST /api/favorites/:propertyId`: Add favorite
- `DELETE /api/favorites/:propertyId`: Remove favorite
- `POST /api/enquiries`: Submit property enquiry
- `GET /api/enquiries`: User's sent enquiries
- `GET /api/enquiries/received`: Owner/Agent received enquiries
- `PATCH /api/enquiries/:id/status`: Update status (Pending, Contacted, Closed)

### Admin Operations
- `GET /api/admin/dashboard`: Platform counts & live statistics
- `GET /api/admin/analytics`: Aggregate data for Recharts
- `GET /api/admin/users`: User list
- `PATCH /api/admin/users/:id/role`: Update user permissions
- `GET /api/admin/properties`: Listing review queue
- `PUT /api/admin/properties/:id/approve`: Verify listing
- `PUT /api/admin/properties/:id/reject`: Reject listing
- `GET /api/admin/activity`: System audit events

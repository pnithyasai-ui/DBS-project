// Currency and Budget Range Formatting Utilities

export const BUDGET_RANGES = {
    'under_25_lakhs': { label: 'Under ₹25 Lakhs', min: 0, max: 2500000 },
    '25_50_lakhs': { label: '₹25 Lakhs – ₹50 Lakhs', min: 2500000, max: 5000000 },
    '50_75_lakhs': { label: '₹50 Lakhs – ₹75 Lakhs', min: 5000000, max: 7500000 },
    '75_lakhs_1_crore': { label: '₹75 Lakhs – ₹1 Crore', min: 7500000, max: 10000000 },
    '1_2_crore': { label: '₹1 Crore – ₹2 Crore', min: 10000000, max: 20000000 },
    '2_5_crore': { label: '₹2 Crore – ₹5 Crore', min: 20000000, max: 50000000 },
    '5_crore_plus': { label: '₹5 Crore+', min: 50000000, max: null }
};

export function parseBudgetParam(budgetKey) {
    if (!budgetKey) return null;
    // Direct match
    if (BUDGET_RANGES[budgetKey]) {
        return BUDGET_RANGES[budgetKey];
    }
    // Match by label or loose string
    const normalized = budgetKey.toLowerCase().replace(/[^a-z0-9]/g, '_');
    for (const key of Object.keys(BUDGET_RANGES)) {
        if (normalized.includes(key) || key.includes(normalized)) {
            return BUDGET_RANGES[key];
        }
    }
    return null;
}

export function formatIndianPrice(amount) {
    if (amount === null || amount === undefined || isNaN(amount)) return '₹0';
    const num = Number(amount);
    if (num >= 10000000) {
        const cr = (num / 10000000).toFixed(2).replace(/\.00$/, '');
        return `₹${cr} Crore`;
    } else if (num >= 100000) {
        const lk = (num / 100000).toFixed(2).replace(/\.00$/, '');
        return `₹${lk} Lakhs`;
    } else {
        return `₹${num.toLocaleString('en-IN')}`;
    }
}

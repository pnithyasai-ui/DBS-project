import pool from '../config/db.js';

export async function logActivity(userId, action, description) {
    try {
        await pool.query(
            'INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)',
            [userId || null, action, description]
        );
    } catch (error) {
        console.error('Failed to write activity log:', error.message);
    }
}

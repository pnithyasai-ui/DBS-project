-- PropertyPortal Standalone Seed Script Reference
-- Run via: mysql -u root -p property_portal < seed.sql
USE property_portal;

-- Standard Test Accounts:
-- Passwords below are bcrypt hashes for: admin123, owner123, agent123, user123
INSERT INTO users (name, email, password, role, phone) VALUES
('System Administrator', 'admin@propertyportal.com', '$2a$10$tZ922h9N63vjU7HekEuhQer4OtdkH9O3rZ.qZp0p3z46J7.i90E2u', 'admin', '+91 9876543210'),
('Rajesh Kumar (Owner)', 'owner@propertyportal.com', '$2a$10$tZ922h9N63vjU7HekEuhQer4OtdkH9O3rZ.qZp0p3z46J7.i90E2u', 'owner', '+91 9848012345'),
('Priya Sharma (Agent)', 'agent@propertyportal.com', '$2a$10$tZ922h9N63vjU7HekEuhQer4OtdkH9O3rZ.qZp0p3z46J7.i90E2u', 'agent', '+91 9700123456'),
('Vikram Reddy (Buyer)', 'user@propertyportal.com', '$2a$10$tZ922h9N63vjU7HekEuhQer4OtdkH9O3rZ.qZp0p3z46J7.i90E2u', 'user', '+91 9988776655');

-- Standard Amenities
INSERT IGNORE INTO amenities (name, icon) VALUES
('Parking', 'car'),
('Lift', 'arrow-up'),
('Security', 'shield'),
('Garden', 'trees'),
('Swimming Pool', 'waves'),
('Gym', 'dumbbell'),
('Power Backup', 'zap'),
('CCTV', 'camera'),
('Club House', 'home');

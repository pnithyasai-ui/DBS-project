import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '../.env') });

const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_PORT = process.env.DB_PORT || 3306;
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || 'root';
const DB_NAME = process.env.DB_NAME || 'property_portal';

async function initializeDatabase() {
    console.log(`Connecting to MySQL server at ${DB_HOST}:${DB_PORT} as ${DB_USER}...`);
    
    // Connect without selecting database first
    const rootConnection = await mysql.createConnection({
        host: DB_HOST,
        port: DB_PORT,
        user: DB_USER,
        password: DB_PASSWORD,
        multipleStatements: true
    });

    console.log('Creating database if not exists...');
    await rootConnection.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
    await rootConnection.end();

    // Now connect to the database
    const connection = await mysql.createConnection({
        host: DB_HOST,
        port: DB_PORT,
        user: DB_USER,
        password: DB_PASSWORD,
        database: DB_NAME,
        multipleStatements: true
    });

    console.log(`Connected to database '${DB_NAME}'. Creating tables...`);

    // Create Tables
    const schemaSql = `
    CREATE TABLE IF NOT EXISTS users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(120) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('user', 'owner', 'agent', 'admin') NOT NULL DEFAULT 'user',
        phone VARCHAR(20) DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_role (role),
        INDEX idx_user_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS properties (
        property_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        location VARCHAR(150) NOT NULL,
        price DECIMAL(15, 2) NOT NULL,
        property_type ENUM(
            'Apartment',
            'Villa',
            'House',
            'Residential Plot',
            'Agricultural Land',
            'Commercial Plot',
            'Office',
            'Shop',
            'Warehouse'
        ) NOT NULL,
        area INT NOT NULL,
        bedrooms INT DEFAULT NULL,
        bathrooms INT DEFAULT NULL,
        furnishing ENUM('Unfurnished', 'Semi-Furnished', 'Furnished', 'N/A') DEFAULT 'N/A',
        parking VARCHAR(50) DEFAULT 'N/A',
        availability ENUM('Available', 'Sold', 'Rented') NOT NULL DEFAULT 'Available',
        verified BOOLEAN NOT NULL DEFAULT 0,
        verification_status ENUM('Pending', 'Verified', 'Rejected') NOT NULL DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        INDEX idx_property_location (location),
        INDEX idx_property_type (property_type),
        INDEX idx_property_price (price),
        INDEX idx_property_verification (verification_status),
        INDEX idx_property_availability (availability)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS amenities (
        amenity_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        icon VARCHAR(50) DEFAULT 'check'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS property_amenities (
        property_id INT NOT NULL,
        amenity_id INT NOT NULL,
        PRIMARY KEY (property_id, amenity_id),
        FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
        FOREIGN KEY (amenity_id) REFERENCES amenities(amenity_id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS property_images (
        image_id INT AUTO_INCREMENT PRIMARY KEY,
        property_id INT NOT NULL,
        image_url TEXT NOT NULL,
        is_primary BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
        INDEX idx_prop_images (property_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS favorites (
        favorite_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        property_id INT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
        UNIQUE KEY uk_user_property (user_id, property_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS enquiries (
        enquiry_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        property_id INT NOT NULL,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(120) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('Pending', 'Contacted', 'Closed') NOT NULL DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
        INDEX idx_enquiry_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS activity_logs (
        log_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT DEFAULT NULL,
        action VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
        INDEX idx_activity_action (action),
        INDEX idx_activity_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    console.log('Resetting tables to ensure clean schema and seed data...');
    await connection.query('SET FOREIGN_KEY_CHECKS = 0;');
    await connection.query('DROP TABLE IF EXISTS activity_logs, enquiries, favorites, property_images, property_amenities, amenities, properties, users;');
    await connection.query('SET FOREIGN_KEY_CHECKS = 1;');
    
    await connection.query(schemaSql);
    console.log('Tables created successfully.');

    console.log('Seeding initial data...');

    // 1. Seed Users
    const salt = await bcrypt.genSalt(10);
    const adminPass = await bcrypt.hash('admin123', salt);
    const ownerPass = await bcrypt.hash('owner123', salt);
    const agentPass = await bcrypt.hash('agent123', salt);
    const userPass = await bcrypt.hash('user123', salt);

    await connection.query(`
        INSERT INTO users (name, email, password, role, phone) VALUES
        ('System Administrator', 'admin@propertyportal.com', ?, 'admin', '+91 9876543210'),
        ('Rajesh Kumar (Owner)', 'owner@propertyportal.com', ?, 'owner', '+91 9848012345'),
        ('Priya Sharma (Agent)', 'agent@propertyportal.com', ?, 'agent', '+91 9700123456'),
        ('Vikram Reddy (Buyer)', 'user@propertyportal.com', ?, 'user', '+91 9988776655'),
        ('Sunita Rao (Owner)', 'sunita.owner@propertyportal.com', ?, 'owner', '+91 9123456789'),
        ('Apex Realty (Agent)', 'apex.agent@propertyportal.com', ?, 'agent', '+91 9234567890');
    `, [adminPass, ownerPass, agentPass, userPass, ownerPass, agentPass]);

    console.log('Users seeded.');

    // 2. Seed Amenities
    const amenities = [
        ['Parking', 'car'],
        ['Lift', 'arrow-up'],
        ['Security', 'shield'],
        ['Garden', 'trees'],
        ['Swimming Pool', 'waves'],
        ['Gym', 'dumbbell'],
        ['Power Backup', 'zap'],
        ['CCTV', 'camera'],
        ['Club House', 'home']
    ];
    for (const [name, icon] of amenities) {
        await connection.query('INSERT IGNORE INTO amenities (name, icon) VALUES (?, ?)', [name, icon]);
    }
    console.log('Amenities seeded.');

    // Fetch user IDs for references
    const [users] = await connection.query('SELECT user_id, email, role FROM users');
    const userMap = {};
    users.forEach(u => userMap[u.role + '_' + u.email.split('@')[0]] = u.user_id);
    const ownerId = users.find(u => u.email === 'owner@propertyportal.com').user_id;
    const agentId = users.find(u => u.email === 'agent@propertyportal.com').user_id;
    const owner2Id = users.find(u => u.email === 'sunita.owner@propertyportal.com').user_id;
    const agent2Id = users.find(u => u.email === 'apex.agent@propertyportal.com').user_id;
    const buyerId = users.find(u => u.email === 'user@propertyportal.com').user_id;
    const adminId = users.find(u => u.email === 'admin@propertyportal.com').user_id;

    // 3. Seed 22 Comprehensive Properties across all budgets & categories
    const propertiesData = [
        // Budget 1: Under ₹25 Lakhs (0 - 25,00,000)
        {
            user_id: ownerId,
            title: 'Fertile Agricultural Land near Outer Ring Road',
            description: 'Prime agricultural land with direct road access, borewell water facility, and rich soil suitable for farming or future farmhouse investment.',
            location: 'Hyderabad outskirts',
            price: 2000000.00, // 20 Lakhs
            property_type: 'Agricultural Land',
            area: 43560, // 1 acre (in sq.ft)
            bedrooms: null,
            bathrooms: null,
            furnishing: 'N/A',
            parking: 'Open Parking',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Security'],
            images: [
                'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: agentId,
            title: 'Affordable Studio Flat in Bachupally',
            description: 'Compact 1 RK studio apartment ideal for bachelors or investment. Situated in a peaceful gated community near educational institutions.',
            location: 'Bachupally',
            price: 2200000.00, // 22 Lakhs
            property_type: 'Apartment',
            area: 550,
            bedrooms: 1,
            bathrooms: 1,
            furnishing: 'Semi-Furnished',
            parking: 'Bike Parking',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Security', 'Lift', 'Power Backup'],
            images: [
                'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Budget 2: ₹25 Lakhs – ₹50 Lakhs (25,00,000 - 50,00,000)
        {
            user_id: ownerId,
            title: 'HMDA Approved Residential Plot in Nizampet',
            description: 'Ready-to-build East facing residential plot in prime gated layout with underground drainage, electricity, and blacktop roads.',
            location: 'Nizampet',
            price: 3500000.00, // 35 Lakhs
            property_type: 'Residential Plot',
            area: 1800,
            bedrooms: null,
            bathrooms: null,
            furnishing: 'N/A',
            parking: 'N/A',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Security', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1524813686514-a57563d77d61?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: agentId,
            title: 'Modern 2 BHK Gated Community Apartment in Miyapur',
            description: 'Well-ventilated 2 BHK apartment close to Miyapur Metro Station. Features modular kitchen, wooden wardrobes, and kids play area.',
            location: 'Miyapur',
            price: 4500000.00, // 45 Lakhs
            property_type: 'Apartment',
            area: 1100,
            bedrooms: 2,
            bathrooms: 2,
            furnishing: 'Semi-Furnished',
            parking: '1 Covered Car',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Power Backup', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: owner2Id,
            title: 'Commercial Retail Shop in Kukatpally Market',
            description: 'High footfall ground floor commercial retail space suitable for pharmacy, boutique, or grocery store with prominent frontage.',
            location: 'Kukatpally',
            price: 4800000.00, // 48 Lakhs
            property_type: 'Shop',
            area: 450,
            bedrooms: null,
            bathrooms: 1,
            furnishing: 'Unfurnished',
            parking: 'Visitor Parking',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Power Backup', 'Security', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1580795478844-5ed694336c90?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Budget 3: ₹50 Lakhs – ₹75 Lakhs (50,00,000 - 75,00,000)
        {
            user_id: ownerId,
            title: 'Spacious 2 BHK Premium Flat in Hyderabad Center',
            description: 'Vastu compliant 2 BHK flat with scenic balcony view, ambient lighting, Italian tile flooring, and close proximity to IT hubs.',
            location: 'Hyderabad',
            price: 6500000.00, // 65 Lakhs
            property_type: 'Apartment',
            area: 1250,
            bedrooms: 2,
            bathrooms: 2,
            furnishing: 'Furnished',
            parking: '1 Covered Car',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Gym', 'Power Backup', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: agentId,
            title: 'Elegant 3 BHK Apartment in Kukatpally Housing Board',
            description: 'Generously proportioned 3 BHK flat near Forum Sujana Mall and JNTU. Equipped with clubhouse amenities and covered parking.',
            location: 'Kukatpally',
            price: 5500000.00, // 55 Lakhs
            property_type: 'Apartment',
            area: 1450,
            bedrooms: 3,
            bathrooms: 3,
            furnishing: 'Semi-Furnished',
            parking: '1 Covered Car',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Power Backup', 'Club House'],
            images: [
                'https://images.unsplash.com/photo-1502005229762-ee152da92e06?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: owner2Id,
            title: 'Standalone Independent House in Miyapur',
            description: 'Independent G+1 house with separate utility area, private terrace, and spacious front courtyard. Great rental income potential.',
            location: 'Miyapur',
            price: 7500000.00, // 75 Lakhs
            property_type: 'House',
            area: 1650,
            bedrooms: 3,
            bathrooms: 3,
            furnishing: 'Unfurnished',
            parking: 'Driveway Parking',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Security', 'Garden'],
            images: [
                'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Budget 4: ₹75 Lakhs – ₹1 Crore (75,00,000 - 1,00,000,000)
        {
            user_id: agentId,
            title: 'Luxury 3 BHK Gated Villa in Bachupally',
            description: 'Triplex luxury villa in a peaceful serene enclave. Includes private landscaped garden, home theatre provision, and community clubhouse.',
            location: 'Bachupally',
            price: 9500000.00, // 95 Lakhs
            property_type: 'Villa',
            area: 2400,
            bedrooms: 3,
            bathrooms: 4,
            furnishing: 'Semi-Furnished',
            parking: '2 Covered Cars',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Security', 'Garden', 'Swimming Pool', 'Gym', 'Club House', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: ownerId,
            title: 'High-Spec 3 BHK Flat in Manikonda',
            description: 'Premium flat located 10 mins from Lanco Hills and Financial District. Complete false ceiling, modular fittings, and high-speed elevators.',
            location: 'Manikonda',
            price: 8800000.00, // 88 Lakhs
            property_type: 'Apartment',
            area: 1750,
            bedrooms: 3,
            bathrooms: 3,
            furnishing: 'Furnished',
            parking: '2 Covered Cars',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Gym', 'Power Backup', 'Club House'],
            images: [
                'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Budget 5: ₹1 Crore – ₹2 Crore (1,00,00,000 - 2,00,00,000)
        {
            user_id: agent2Id,
            title: 'Ultra Luxury 4 BHK Sky Condominium in Gachibowli',
            description: 'Panoramic skyline views from high floor in Gachibowli financial corridor. Imported marble flooring, VRV air-conditioning, and 5-star concierge.',
            location: 'Gachibowli',
            price: 15000000.00, // 1.5 Crore
            property_type: 'Apartment',
            area: 2800,
            bedrooms: 4,
            bathrooms: 4,
            furnishing: 'Furnished',
            parking: '2 Covered Cars',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Garden', 'Swimming Pool', 'Gym', 'Power Backup', 'CCTV', 'Club House'],
            images: [
                'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: owner2Id,
            title: 'Modern Corporate IT Office Space in Madhapur',
            description: 'Furnished plug-and-play IT office space with 40 workstations, conference room, executive cabins, and cafeteria near HITEC City.',
            location: 'Madhapur',
            price: 12000000.00, // 1.2 Crore
            property_type: 'Office',
            area: 2200,
            bedrooms: null,
            bathrooms: 2,
            furnishing: 'Furnished',
            parking: '3 Cars Reserved',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Lift', 'Security', 'Power Backup', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: agentId,
            title: 'Spacious Commercial Logistics Warehouse in Secunderabad',
            description: 'Industrial warehouse facility with 24ft clear height, heavy vehicle loading docks, 3-phase high tension power, and broad approach road.',
            location: 'Secunderabad',
            price: 18000000.00, // 1.8 Crore
            property_type: 'Warehouse',
            area: 7500,
            bedrooms: null,
            bathrooms: 2,
            furnishing: 'Unfurnished',
            parking: 'Truck Yard',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Security', 'Power Backup', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: ownerId,
            title: 'Independent 4 BHK Villa in Kondapur',
            description: 'Vastu compliant 4 BHK designer villa with private swimming pool, landscaped lawn, rooftop gazebo, and servant quarters.',
            location: 'Kondapur',
            price: 20000000.00, // 2.0 Crore
            property_type: 'Villa',
            area: 3200,
            bedrooms: 4,
            bathrooms: 4,
            furnishing: 'Semi-Furnished',
            parking: '2 Covered Cars',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Security', 'Garden', 'Swimming Pool', 'Power Backup', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Budget 6: ₹2 Crore – ₹5 Crore (2,00,00,000 - 5,00,00,000)
        {
            user_id: agent2Id,
            title: 'Prime Commercial Corner Plot in Kondapur Main Road',
            description: 'High visibility commercial corner plot directly fronting 100ft road. Approved for multi-floor commercial complex or hospital building.',
            location: 'Kondapur',
            price: 32000000.00, // 3.2 Crore
            property_type: 'Commercial Plot',
            area: 4500,
            bedrooms: null,
            bathrooms: null,
            furnishing: 'N/A',
            parking: 'Frontage Parking',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Security', 'CCTV'],
            images: [
                'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?auto=format&fit=crop&w=800&q=80'
            ]
        },
        {
            user_id: ownerId,
            title: 'Royal 5 BHK Gated Mansion Villa in Gachibowli',
            description: 'Opulent European-styled royal mansion with private elevator, home gym, landscaped water bodies, Italian modular kitchen, and double height living room.',
            location: 'Gachibowli',
            price: 45000000.00, // 4.5 Crore
            property_type: 'Villa',
            area: 5200,
            bedrooms: 5,
            bathrooms: 6,
            furnishing: 'Furnished',
            parking: '4 Covered Cars',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Garden', 'Swimming Pool', 'Gym', 'Power Backup', 'CCTV', 'Club House'],
            images: [
                'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Budget 7: ₹5 Crore+ (5,00,00,000+)
        {
            user_id: agentId,
            title: 'Ultra-Bespoke 5 BHK Sky Penthouse in Madhapur',
            description: 'The pinnacle of luxury living over 7000 sq.ft with private 360-degree infinity pool overlooking Durgam Cheruvu lake, smart automation, and private helipad access.',
            location: 'Madhapur',
            price: 75000000.00, // 7.5 Crore
            property_type: 'Apartment',
            area: 7200,
            bedrooms: 5,
            bathrooms: 6,
            furnishing: 'Furnished',
            parking: '4 Reserved Cars',
            availability: 'Available',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Security', 'Garden', 'Swimming Pool', 'Gym', 'Power Backup', 'CCTV', 'Club House'],
            images: [
                'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
                'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80'
            ]
        },
        // Pending and Rejected properties for Admin verification testing
        {
            user_id: owner2Id,
            title: 'Brand New 3 BHK Apartment in Bachupally (Pending Approval)',
            description: 'Newly constructed 3 BHK apartment waiting for admin verification. 100% Vastu with zero common walls.',
            location: 'Bachupally',
            price: 6800000.00, // 68 Lakhs
            property_type: 'Apartment',
            area: 1550,
            bedrooms: 3,
            bathrooms: 3,
            furnishing: 'Unfurnished',
            parking: '1 Car',
            availability: 'Available',
            verified: 0,
            verification_status: 'Pending',
            amenities: ['Parking', 'Lift', 'Security', 'Power Backup'],
            images: [
                'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80'
            ]
        },
        {
            user_id: agent2Id,
            title: '4 BHK Duplex Villa in Nizampet (Pending Approval)',
            description: 'Spacious duplex villa with private terrace garden awaiting admin verification.',
            location: 'Nizampet',
            price: 11000000.00, // 1.1 Crore
            property_type: 'Villa',
            area: 2600,
            bedrooms: 4,
            bathrooms: 4,
            furnishing: 'Semi-Furnished',
            parking: '2 Cars',
            availability: 'Available',
            verified: 0,
            verification_status: 'Pending',
            amenities: ['Parking', 'Security', 'Garden'],
            images: [
                'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80'
            ]
        },
        {
            user_id: ownerId,
            title: 'Commercial Space in Secunderabad (Sold)',
            description: 'Sold prime retail property in Secunderabad commercial street.',
            location: 'Secunderabad',
            price: 8500000.00,
            property_type: 'Shop',
            area: 800,
            bedrooms: null,
            bathrooms: 1,
            furnishing: 'Furnished',
            parking: '1 Car',
            availability: 'Sold',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Power Backup', 'Security'],
            images: [
                'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=1200&q=80'
            ]
        },
        {
            user_id: agentId,
            title: 'Furnished 2 BHK Flat for Rent in Gachibowli (Rented)',
            description: 'Fully furnished rental apartment right next to DLF Cybercity. Currently rented out.',
            location: 'Gachibowli',
            price: 6000000.00,
            property_type: 'Apartment',
            area: 1200,
            bedrooms: 2,
            bathrooms: 2,
            furnishing: 'Furnished',
            parking: '1 Car',
            availability: 'Rented',
            verified: 1,
            verification_status: 'Verified',
            amenities: ['Parking', 'Lift', 'Gym', 'Swimming Pool'],
            images: [
                'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80'
            ]
        },
        {
            user_id: owner2Id,
            title: 'Sample Inappropriate Listing (Rejected)',
            description: 'Property with incomplete verification documents rejected by portal administrator.',
            location: 'Hyderabad',
            price: 5000000.00,
            property_type: 'Apartment',
            area: 1000,
            bedrooms: 2,
            bathrooms: 2,
            furnishing: 'Unfurnished',
            parking: 'None',
            availability: 'Available',
            verified: 0,
            verification_status: 'Rejected',
            amenities: ['Security'],
            images: [
                'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80'
            ]
        }
    ];

    // Fetch all amenities
    const [dbAmenities] = await connection.query('SELECT amenity_id, name FROM amenities');
    const amenityMap = {};
    dbAmenities.forEach(a => amenityMap[a.name] = a.amenity_id);

    for (const p of propertiesData) {
        const [res] = await connection.query(`
            INSERT INTO properties (
                user_id, title, description, location, price, property_type, area,
                bedrooms, bathrooms, furnishing, parking, availability, verified, verification_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            p.user_id, p.title, p.description, p.location, p.price, p.property_type, p.area,
            p.bedrooms, p.bathrooms, p.furnishing, p.parking, p.availability, p.verified, p.verification_status
        ]);
        const propId = res.insertId;

        // Insert images
        for (let i = 0; i < p.images.length; i++) {
            await connection.query(`
                INSERT INTO property_images (property_id, image_url, is_primary)
                VALUES (?, ?, ?)
            `, [propId, p.images[i], i === 0 ? 1 : 0]);
        }

        // Insert amenities
        if (p.amenities && p.amenities.length > 0) {
            for (const aName of p.amenities) {
                if (amenityMap[aName]) {
                    await connection.query(`
                        INSERT IGNORE INTO property_amenities (property_id, amenity_id)
                        VALUES (?, ?)
                    `, [propId, amenityMap[aName]]);
                }
            }
        }
    }

    console.log(`Seeded ${propertiesData.length} properties.`);

    // 4. Seed Favorites
    const [sampleProps] = await connection.query('SELECT property_id FROM properties LIMIT 4');
    if (sampleProps.length > 0) {
        await connection.query(`
            INSERT IGNORE INTO favorites (user_id, property_id) VALUES
            (?, ?), (?, ?)
        `, [buyerId, sampleProps[0].property_id, buyerId, sampleProps[1].property_id]);
        console.log('Favorites seeded.');
    }

    // 5. Seed Enquiries
    if (sampleProps.length > 1) {
        await connection.query(`
            INSERT INTO enquiries (user_id, property_id, name, email, phone, message, status) VALUES
            (?, ?, 'Vikram Reddy', 'user@propertyportal.com', '+91 9988776655', 'I am interested in scheduling a site visit this coming Saturday. Please share more details.', 'Pending'),
            (?, ?, 'Vikram Reddy', 'user@propertyportal.com', '+91 9988776655', 'Is the price negotiable for immediate token payment?', 'Contacted')
        `, [buyerId, sampleProps[0].property_id, buyerId, sampleProps[1].property_id]);
        console.log('Enquiries seeded.');
    }

    // 6. Seed Activity Logs
    await connection.query(`
        INSERT INTO activity_logs (user_id, action, description) VALUES
        (?, 'User Registered', 'New account created for Vikram Reddy (user)'),
        (?, 'User Registered', 'New account created for Rajesh Kumar (owner)'),
        (?, 'User Registered', 'New account created for Priya Sharma (agent)'),
        (?, 'User Login', 'System Administrator logged in to Admin Console'),
        (?, 'Property Added', 'New listing "Luxury 3 BHK Gated Villa in Bachupally" submitted'),
        (?, 'Property Verified', 'Admin verified and published listing #1'),
        (?, 'Enquiry Created', 'Vikram Reddy sent enquiry for listing #1');
    `, [buyerId, ownerId, agentId, adminId, agentId, adminId, buyerId]);

    console.log('Activity logs seeded.');
    console.log('🎉 Database initialization complete with all tables and realistic seed data!');
    await connection.end();
}

initializeDatabase().catch(err => {
    console.error('Database initialization failed:', err);
    process.exit(1);
});

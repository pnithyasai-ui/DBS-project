import pool from '../config/db.js';
import { logActivity } from '../utils/activityLogger.js';

// GET /api/admin/dashboard
export async function getAdminDashboardStats(req, res) {
    try {
        // Platform user counts
        const [usersByRole] = await pool.query(`
            SELECT role, COUNT(*) as count 
            FROM users 
            GROUP BY role
        `);
        const userStats = { total: 0, user: 0, owner: 0, agent: 0, admin: 0 };
        usersByRole.forEach(r => {
            userStats[r.role] = r.count;
            userStats.total += r.count;
        });

        // Property status counts
        const [propStats] = await pool.query(`
            SELECT 
                COUNT(*) as total_properties,
                SUM(CASE WHEN verification_status = 'Pending' THEN 1 ELSE 0 END) as pending_properties,
                SUM(CASE WHEN verification_status = 'Verified' THEN 1 ELSE 0 END) as verified_properties,
                SUM(CASE WHEN verification_status = 'Rejected' THEN 1 ELSE 0 END) as rejected_properties,
                SUM(CASE WHEN availability = 'Available' THEN 1 ELSE 0 END) as available_properties,
                SUM(CASE WHEN availability = 'Sold' THEN 1 ELSE 0 END) as sold_properties,
                SUM(CASE WHEN availability = 'Rented' THEN 1 ELSE 0 END) as rented_properties,
                AVG(price) as avg_price
            FROM properties
        `);

        // Enquiry counts
        const [enquiryStats] = await pool.query('SELECT COUNT(*) as total_enquiries FROM enquiries');

        // Recent activities
        const [recentActivities] = await pool.query(`
            SELECT a.*, u.name as user_name, u.email as user_email, u.role as user_role
            FROM activity_logs a
            LEFT JOIN users u ON a.user_id = u.user_id
            ORDER BY a.created_at DESC
            LIMIT 6
        `);

        return res.status(200).json({
            success: true,
            data: {
                total_users: userStats.total,
                total_owners: userStats.owner,
                total_agents: userStats.agent,
                total_buyers: userStats.user,
                total_admins: userStats.admin,
                total_properties: propStats[0].total_properties || 0,
                pending_properties: propStats[0].pending_properties || 0,
                verified_properties: propStats[0].verified_properties || 0,
                rejected_properties: propStats[0].rejected_properties || 0,
                available_properties: propStats[0].available_properties || 0,
                sold_properties: propStats[0].sold_properties || 0,
                rented_properties: propStats[0].rented_properties || 0,
                avg_price: propStats[0].avg_price ? Math.round(propStats[0].avg_price) : 0,
                total_enquiries: enquiryStats[0].total_enquiries || 0,
                recent_activities: recentActivities
            }
        });
    } catch (error) {
        console.error('Error fetching admin dashboard stats:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve admin dashboard stats.'
        });
    }
}

// GET /api/admin/analytics
export async function getAdminAnalytics(req, res) {
    try {
        // 1. Properties by Type
        const [byType] = await pool.query(`
            SELECT property_type as name, COUNT(*) as count, AVG(price) as avg_price
            FROM properties
            GROUP BY property_type
            ORDER BY count DESC
        `);

        // 2. Properties by Location
        const [byLocation] = await pool.query(`
            SELECT location as name, COUNT(*) as count
            FROM properties
            GROUP BY location
            ORDER BY count DESC
            LIMIT 10
        `);

        // 3. Properties by Budget Brackets
        const [byBudget] = await pool.query(`
            SELECT 
                SUM(CASE WHEN price < 2500000 THEN 1 ELSE 0 END) as "Under ₹25L",
                SUM(CASE WHEN price >= 2500000 AND price < 5000000 THEN 1 ELSE 0 END) as "₹25L-50L",
                SUM(CASE WHEN price >= 5000000 AND price < 7500000 THEN 1 ELSE 0 END) as "₹50L-75L",
                SUM(CASE WHEN price >= 7500000 AND price < 10000000 THEN 1 ELSE 0 END) as "₹75L-1Cr",
                SUM(CASE WHEN price >= 10000000 AND price < 20000000 THEN 1 ELSE 0 END) as "₹1Cr-2Cr",
                SUM(CASE WHEN price >= 20000000 AND price < 50000000 THEN 1 ELSE 0 END) as "₹2Cr-5Cr",
                SUM(CASE WHEN price >= 50000000 THEN 1 ELSE 0 END) as "₹5Cr+"
            FROM properties
        `);

        const budgetChartData = Object.entries(byBudget[0] || {}).map(([range, count]) => ({
            name: range,
            count: count || 0
        }));

        // 4. Availability Distribution
        const [byAvailability] = await pool.query(`
            SELECT availability as name, COUNT(*) as value
            FROM properties
            GROUP BY availability
        `);

        // 5. Users by Role
        const [byRole] = await pool.query(`
            SELECT role as name, COUNT(*) as value
            FROM users
            GROUP BY role
        `);

        // 6. Properties Added Over Time (by month or date)
        const [timeline] = await pool.query(`
            SELECT DATE_FORMAT(created_at, '%Y-%m-%d') as date, COUNT(*) as count
            FROM properties
            GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d')
            ORDER BY date ASC
            LIMIT 30
        `);

        return res.status(200).json({
            success: true,
            data: {
                by_type: byType,
                by_location: byLocation,
                by_budget: budgetChartData,
                by_availability: byAvailability,
                by_role: byRole,
                timeline: timeline
            }
        });
    } catch (error) {
        console.error('Error fetching analytics:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve analytics.'
        });
    }
}

// GET /api/admin/users
export async function getAllUsers(req, res) {
    try {
        const [users] = await pool.query(`
            SELECT u.user_id, u.name, u.email, u.role, u.phone, u.created_at,
                   (SELECT COUNT(*) FROM properties p WHERE p.user_id = u.user_id) as properties_count,
                   (SELECT COUNT(*) FROM enquiries e WHERE e.user_id = u.user_id) as enquiries_count
            FROM users u
            ORDER BY u.created_at DESC
        `);

        return res.status(200).json({
            success: true,
            data: users
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve users.'
        });
    }
}

// PATCH /api/admin/users/:id/role
export async function updateUserRole(req, res) {
    try {
        const { id } = req.params;
        const { role } = req.body;

        if (!['user', 'owner', 'agent', 'admin'].includes(role)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid role provided.'
            });
        }

        const [existing] = await pool.query('SELECT user_id, name, role FROM users WHERE user_id = ?', [id]);
        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'User not found.'
            });
        }

        await pool.query('UPDATE users SET role = ? WHERE user_id = ?', [role, id]);

        await logActivity(
            req.user.user_id,
            'Role Changed',
            `Admin ${req.user.name} changed role of ${existing[0].name} (#${id}) from ${existing[0].role} to ${role}`
        );

        return res.status(200).json({
            success: true,
            message: `User role successfully changed to ${role}.`
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to update user role.'
        });
    }
}

// GET /api/admin/properties
export async function getAllAdminProperties(req, res) {
    try {
        const [properties] = await pool.query(`
            SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.role as owner_role
            FROM properties p
            JOIN users u ON p.user_id = u.user_id
            ORDER BY 
                CASE p.verification_status 
                    WHEN 'Pending' THEN 1 
                    WHEN 'Verified' THEN 2 
                    ELSE 3 
                END,
                p.created_at DESC
        `);

        return res.status(200).json({
            success: true,
            data: properties
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve all properties.'
        });
    }
}

// PUT /api/admin/properties/:id/approve
export async function approveProperty(req, res) {
    try {
        const { id } = req.params;
        const [prop] = await pool.query('SELECT property_id, title FROM properties WHERE property_id = ?', [id]);

        if (prop.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        await pool.query(
            'UPDATE properties SET verification_status = "Verified", verified = 1 WHERE property_id = ?',
            [id]
        );

        await logActivity(
            req.user.user_id,
            'Property Verified',
            `Admin ${req.user.name} approved and published property #${id}: "${prop[0].title}"`
        );

        return res.status(200).json({
            success: true,
            message: 'Property approved and verified successfully!'
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to approve property.'
        });
    }
}

// PUT /api/admin/properties/:id/reject
export async function rejectProperty(req, res) {
    try {
        const { id } = req.params;
        const [prop] = await pool.query('SELECT property_id, title FROM properties WHERE property_id = ?', [id]);

        if (prop.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        await pool.query(
            'UPDATE properties SET verification_status = "Rejected", verified = 0 WHERE property_id = ?',
            [id]
        );

        await logActivity(
            req.user.user_id,
            'Property Rejected',
            `Admin ${req.user.name} rejected property #${id}: "${prop[0].title}"`
        );

        return res.status(200).json({
            success: true,
            message: 'Property rejected.'
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to reject property.'
        });
    }
}

// GET /api/admin/activity
export async function getActivityLogs(req, res) {
    try {
        const [logs] = await pool.query(`
            SELECT a.*, u.name as user_name, u.email as user_email, u.role as user_role
            FROM activity_logs a
            LEFT JOIN users u ON a.user_id = u.user_id
            ORDER BY a.created_at DESC
            LIMIT 100
        `);

        return res.status(200).json({
            success: true,
            data: logs
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve activity logs.'
        });
    }
}

// GET /api/admin/enquiries
export async function getAllEnquiries(req, res) {
    try {
        const [enquiries] = await pool.query(`
            SELECT e.*, p.title as property_title, p.location as property_location, p.price,
                   u.name as sender_name, u.email as sender_email,
                   owner.name as owner_name, owner.email as owner_email
            FROM enquiries e
            JOIN properties p ON e.property_id = p.property_id
            JOIN users u ON e.user_id = u.user_id
            JOIN users owner ON p.user_id = owner.user_id
            ORDER BY e.created_at DESC
        `);

        return res.status(200).json({
            success: true,
            data: enquiries
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve enquiries.'
        });
    }
}

import pool from '../config/db.js';
import { parseBudgetParam, formatIndianPrice } from '../utils/formatters.js';
import { logActivity } from '../utils/activityLogger.js';

// Helper to attach images and amenities to properties
async function populatePropertyDetails(properties, currentUserId = null) {
    if (!properties || properties.length === 0) return [];

    const propertyIds = properties.map(p => p.property_id);
    const placeholders = propertyIds.map(() => '?').join(',');

    // Fetch images
    const [images] = await pool.query(
        `SELECT property_id, image_url, is_primary FROM property_images WHERE property_id IN (${placeholders}) ORDER BY is_primary DESC, image_id ASC`,
        propertyIds
    );

    // Fetch amenities
    const [amenities] = await pool.query(
        `SELECT pa.property_id, a.amenity_id, a.name, a.icon 
         FROM property_amenities pa 
         JOIN amenities a ON pa.amenity_id = a.amenity_id 
         WHERE pa.property_id IN (${placeholders})`,
        propertyIds
    );

    // Fetch favorites if user is authenticated
    let favoriteIds = new Set();
    if (currentUserId) {
        const [favs] = await pool.query(
            `SELECT property_id FROM favorites WHERE user_id = ? AND property_id IN (${placeholders})`,
            [currentUserId, ...propertyIds]
        );
        favs.forEach(f => favoriteIds.add(f.property_id));
    }

    // Map attachments back to properties
    return properties.map(prop => {
        const propImages = images.filter(img => img.property_id === prop.property_id);
        const propAmenities = amenities.filter(a => a.property_id === prop.property_id);
        return {
            ...prop,
            formatted_price: formatIndianPrice(prop.price),
            primary_image: propImages.length > 0 ? propImages[0].image_url : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1000&q=80',
            images: propImages.map(img => img.image_url),
            amenities: propAmenities,
            is_favorite: favoriteIds.has(prop.property_id)
        };
    });
}

// GET /api/properties (Dynamic smart filtering)
export async function getProperties(req, res) {
    try {
        const {
            location,
            propertyType,
            category,
            budget,
            minPrice,
            maxPrice,
            bedrooms,
            bathrooms,
            minArea,
            maxArea,
            availability,
            furnishing,
            amenities,
            sort,
            page = 1,
            limit = 12,
            all
        } = req.query;

        const conditions = [];
        const params = [];

        // By default, public search only shows Verified properties
        if (!all || !req.user || req.user.role !== 'admin') {
            conditions.push('p.verification_status = "Verified"');
        }

        // Location partial match (e.g. "Hyd" matches "Hyderabad")
        if (location && location.trim() !== '') {
            conditions.push('p.location LIKE ?');
            params.push(`%${location.trim()}%`);
        }

        // Property Type or Category Group
        if (propertyType && propertyType !== 'All' && propertyType !== 'all') {
            if (propertyType === 'Apartments' || propertyType === 'Apartment') {
                conditions.push('p.property_type = "Apartment"');
            } else if (propertyType === 'Villas' || propertyType === 'Villa') {
                conditions.push('p.property_type = "Villa"');
            } else if (propertyType === 'Houses' || propertyType === 'House') {
                conditions.push('p.property_type = "House"');
            } else if (propertyType === 'Lands & Plots' || propertyType === 'Land' || propertyType === 'Plot') {
                conditions.push('p.property_type IN ("Residential Plot", "Agricultural Land", "Commercial Plot")');
            } else if (propertyType === 'Commercial') {
                conditions.push('p.property_type IN ("Commercial Plot", "Office", "Shop", "Warehouse")');
            } else {
                conditions.push('p.property_type = ?');
                params.push(propertyType);
            }
        }

        // Category group filter if passed directly
        if (category) {
            if (category === 'residential') {
                conditions.push('p.property_type IN ("Apartment", "Villa", "House")');
            } else if (category === 'land') {
                conditions.push('p.property_type IN ("Residential Plot", "Agricultural Land", "Commercial Plot")');
            } else if (category === 'commercial') {
                conditions.push('p.property_type IN ("Commercial Plot", "Office", "Shop", "Warehouse")');
            }
        }

        // Budget Filter
        if (budget) {
            const range = parseBudgetParam(budget);
            if (range) {
                if (range.min !== null && range.min !== undefined) {
                    conditions.push('p.price >= ?');
                    params.push(range.min);
                }
                if (range.max !== null && range.max !== undefined) {
                    conditions.push('p.price <= ?');
                    params.push(range.max);
                }
            }
        } else {
            if (minPrice) {
                conditions.push('p.price >= ?');
                params.push(Number(minPrice));
            }
            if (maxPrice) {
                conditions.push('p.price <= ?');
                params.push(Number(maxPrice));
            }
        }

        // Bedrooms Filter (Only for properties that have bedrooms)
        if (bedrooms && bedrooms !== 'Any' && bedrooms !== 'any') {
            if (bedrooms === '5+' || bedrooms === '5') {
                conditions.push('p.bedrooms >= 5');
            } else {
                conditions.push('p.bedrooms = ?');
                params.push(parseInt(bedrooms));
            }
        }

        // Bathrooms
        if (bathrooms && bathrooms !== 'Any' && bathrooms !== 'any') {
            conditions.push('p.bathrooms >= ?');
            params.push(parseInt(bathrooms));
        }

        // Area (sq.ft) filter
        if (minArea && !isNaN(parseInt(minArea))) {
            conditions.push('p.area >= ?');
            params.push(parseInt(minArea));
        }
        if (maxArea && !isNaN(parseInt(maxArea))) {
            conditions.push('p.area <= ?');
            params.push(parseInt(maxArea));
        }

        // Availability
        if (availability && availability !== 'All') {
            conditions.push('p.availability = ?');
            params.push(availability);
        }

        // Furnishing
        if (furnishing && furnishing !== 'All') {
            conditions.push('p.furnishing = ?');
            params.push(furnishing);
        }

        // Amenities filter
        if (amenities) {
            const amenityList = amenities.split(',').map(a => a.trim()).filter(Boolean);
            if (amenityList.length > 0) {
                const amenityPlaceholders = amenityList.map(() => '?').join(',');
                conditions.push(`
                    p.property_id IN (
                        SELECT pa.property_id FROM property_amenities pa
                        JOIN amenities a ON pa.amenity_id = a.amenity_id
                        WHERE a.name IN (${amenityPlaceholders})
                        GROUP BY pa.property_id
                        HAVING COUNT(DISTINCT a.name) = ${amenityList.length}
                    )
                `);
                params.push(...amenityList);
            }
        }

        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

        // Sorting
        let orderByClause = 'ORDER BY p.created_at DESC';
        if (sort === 'oldest') {
            orderByClause = 'ORDER BY p.created_at ASC';
        } else if (sort === 'price_asc' || sort === 'price_low_high') {
            orderByClause = 'ORDER BY p.price ASC';
        } else if (sort === 'price_desc' || sort === 'price_high_low') {
            orderByClause = 'ORDER BY p.price DESC';
        } else if (sort === 'area_asc' || sort === 'area_low_high') {
            orderByClause = 'ORDER BY p.area ASC';
        } else if (sort === 'area_desc' || sort === 'area_high_low') {
            orderByClause = 'ORDER BY p.area DESC';
        }

        // Count total matching
        const countQuery = `SELECT COUNT(*) as total FROM properties p ${whereClause}`;
        const [countResult] = await pool.query(countQuery, params);
        const total = countResult[0].total;

        // Pagination
        const pageNum = Math.max(1, parseInt(page));
        const limitNum = Math.max(1, parseInt(limit));
        const offset = (pageNum - 1) * limitNum;

        // Query properties
        const dataQuery = `
            SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.role as owner_role
            FROM properties p
            JOIN users u ON p.user_id = u.user_id
            ${whereClause}
            ${orderByClause}
            LIMIT ? OFFSET ?
        `;

        const queryParams = [...params, limitNum, offset];
        const [properties] = await pool.query(dataQuery, queryParams);

        // Populate images, amenities, and favorite status
        const currentUserId = req.user ? req.user.user_id : null;
        const populatedProperties = await populatePropertyDetails(properties, currentUserId);

        return res.status(200).json({
            success: true,
            message: 'Properties retrieved successfully.',
            data: {
                properties: populatedProperties,
                pagination: {
                    total,
                    page: pageNum,
                    limit: limitNum,
                    totalPages: Math.ceil(total / limitNum)
                }
            }
        });
    } catch (error) {
        console.error('Error fetching properties:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve properties.'
        });
    }
}

// GET /api/properties/featured
export async function getFeaturedProperties(req, res) {
    try {
        const query = `
            SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.role as owner_role
            FROM properties p
            JOIN users u ON p.user_id = u.user_id
            WHERE p.verification_status = 'Verified' AND p.availability = 'Available'
            ORDER BY p.price DESC
            LIMIT 6
        `;
        const [properties] = await pool.query(query);
        const currentUserId = req.user ? req.user.user_id : null;
        const populated = await populatePropertyDetails(properties, currentUserId);

        return res.status(200).json({
            success: true,
            data: populated
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve featured properties.'
        });
    }
}

// GET /api/properties/locations
export async function getPopularLocations(req, res) {
    try {
        const [locations] = await pool.query(`
            SELECT location, COUNT(*) as count 
            FROM properties 
            WHERE verification_status = 'Verified' 
            GROUP BY location 
            ORDER BY count DESC 
            LIMIT 10
        `);
        return res.status(200).json({
            success: true,
            data: locations
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve locations.'
        });
    }
}

// GET /api/properties/:id
export async function getPropertyById(req, res) {
    try {
        const { id } = req.params;
        const [properties] = await pool.query(`
            SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.role as owner_role
            FROM properties p
            JOIN users u ON p.user_id = u.user_id
            WHERE p.property_id = ?
        `, [id]);

        if (properties.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        const currentUserId = req.user ? req.user.user_id : null;
        const [populated] = await populatePropertyDetails(properties, currentUserId);

        return res.status(200).json({
            success: true,
            data: populated
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve property details.'
        });
    }
}

// POST /api/properties (Owner/Agent/Admin)
export async function createProperty(req, res) {
    try {
        const {
            title,
            description,
            location,
            price,
            property_type,
            area,
            bedrooms,
            bathrooms,
            furnishing,
            parking,
            availability,
            images = [],
            amenity_ids = []
        } = req.body;

        if (!title || !location || !price || !property_type || !area) {
            return res.status(400).json({
                success: false,
                message: 'Title, location, price, property type, and area are required.'
            });
        }

        // Automatic user_id from authenticated token - never allow frontend spoofing
        const userId = req.user.user_id;

        // Admin listings are immediately verified; Owner/Agent listings default to Pending
        const isAdmin = req.user.role === 'admin';
        const verificationStatus = isAdmin ? 'Verified' : 'Pending';
        const isVerified = isAdmin ? 1 : 0;

        // Bedroom adjustment: Land properties should not have bedrooms
        const isLand = ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(property_type);
        const bedCount = isLand ? null : (bedrooms ? parseInt(bedrooms) : null);
        const bathCount = isLand ? null : (bathrooms ? parseInt(bathrooms) : null);

        const [result] = await pool.query(`
            INSERT INTO properties (
                user_id, title, description, location, price, property_type, area,
                bedrooms, bathrooms, furnishing, parking, availability, verified, verification_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            userId,
            title.trim(),
            description || '',
            location.trim(),
            parseFloat(price),
            property_type,
            parseInt(area),
            bedCount,
            bathCount,
            furnishing || 'N/A',
            parking || 'N/A',
            availability || 'Available',
            isVerified,
            verificationStatus
        ]);

        const newPropertyId = result.insertId;

        // Insert images
        if (Array.isArray(images) && images.length > 0) {
            for (let i = 0; i < images.length; i++) {
                if (images[i] && images[i].trim()) {
                    await pool.query(`
                        INSERT INTO property_images (property_id, image_url, is_primary)
                        VALUES (?, ?, ?)
                    `, [newPropertyId, images[i].trim(), i === 0 ? 1 : 0]);
                }
            }
        } else {
            // Default image if none provided
            await pool.query(`
                INSERT INTO property_images (property_id, image_url, is_primary)
                VALUES (?, ?, 1)
            `, [newPropertyId, 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80']);
        }

        // Insert amenities
        if (Array.isArray(amenity_ids) && amenity_ids.length > 0) {
            for (const aId of amenity_ids) {
                await pool.query(`
                    INSERT IGNORE INTO property_amenities (property_id, amenity_id)
                    VALUES (?, ?)
                `, [newPropertyId, parseInt(aId)]);
            }
        }

        await logActivity(
            userId,
            'Property Added',
            `User ${req.user.name} added listing: "${title}" (${property_type}) - Status: ${verificationStatus}`
        );

        return res.status(201).json({
            success: true,
            message: isAdmin 
                ? 'Property created and published!' 
                : 'Property submitted successfully! It is currently pending Admin verification.',
            data: {
                property_id: newPropertyId,
                verification_status: verificationStatus
            }
        });
    } catch (error) {
        console.error('Create property error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to create property listing.'
        });
    }
}

// PUT /api/properties/:id (Strict ownership verification)
export async function updateProperty(req, res) {
    try {
        const { id } = req.params;
        const [existing] = await pool.query('SELECT * FROM properties WHERE property_id = ?', [id]);

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        const property = existing[0];

        // Strict ownership check: Only owner or admin can edit
        if (property.user_id !== req.user.user_id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access Denied: You do not have permission to edit this property.'
            });
        }

        const {
            title,
            description,
            location,
            price,
            property_type,
            area,
            bedrooms,
            bathrooms,
            furnishing,
            parking,
            availability,
            images,
            amenity_ids
        } = req.body;

        const isLand = ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(property_type || property.property_type);

        await pool.query(`
            UPDATE properties SET
                title = COALESCE(?, title),
                description = COALESCE(?, description),
                location = COALESCE(?, location),
                price = COALESCE(?, price),
                property_type = COALESCE(?, property_type),
                area = COALESCE(?, area),
                bedrooms = ?,
                bathrooms = ?,
                furnishing = COALESCE(?, furnishing),
                parking = COALESCE(?, parking),
                availability = COALESCE(?, availability)
            WHERE property_id = ?
        `, [
            title,
            description,
            location,
            price ? parseFloat(price) : null,
            property_type,
            area ? parseInt(area) : null,
            isLand ? null : (bedrooms !== undefined ? parseInt(bedrooms) : property.bedrooms),
            isLand ? null : (bathrooms !== undefined ? parseInt(bathrooms) : property.bathrooms),
            furnishing,
            parking,
            availability,
            id
        ]);

        // Update images if provided
        if (Array.isArray(images)) {
            await pool.query('DELETE FROM property_images WHERE property_id = ?', [id]);
            for (let i = 0; i < images.length; i++) {
                if (images[i] && images[i].trim()) {
                    await pool.query(`
                        INSERT INTO property_images (property_id, image_url, is_primary)
                        VALUES (?, ?, ?)
                    `, [id, images[i].trim(), i === 0 ? 1 : 0]);
                }
            }
        }

        // Update amenities if provided
        if (Array.isArray(amenity_ids)) {
            await pool.query('DELETE FROM property_amenities WHERE property_id = ?', [id]);
            for (const aId of amenity_ids) {
                await pool.query(`
                    INSERT IGNORE INTO property_amenities (property_id, amenity_id)
                    VALUES (?, ?)
                `, [id, parseInt(aId)]);
            }
        }

        await logActivity(
            req.user.user_id,
            'Property Updated',
            `User ${req.user.name} updated property #${id}: "${title || property.title}"`
        );

        return res.status(200).json({
            success: true,
            message: 'Property updated successfully.'
        });
    } catch (error) {
        console.error('Update property error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to update property.'
        });
    }
}

// DELETE /api/properties/:id (Strict ownership verification)
export async function deleteProperty(req, res) {
    try {
        const { id } = req.params;
        const [existing] = await pool.query('SELECT * FROM properties WHERE property_id = ?', [id]);

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        const property = existing[0];

        // Strict ownership check: Only owner or admin can delete
        if (property.user_id !== req.user.user_id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access Denied: You do not have permission to delete this property.'
            });
        }

        await pool.query('DELETE FROM properties WHERE property_id = ?', [id]);

        await logActivity(
            req.user.user_id,
            'Property Deleted',
            `User ${req.user.name} deleted property #${id}: "${property.title}"`
        );

        return res.status(200).json({
            success: true,
            message: 'Property deleted successfully.'
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to delete property.'
        });
    }
}

// PATCH /api/properties/:id/availability
export async function updateAvailability(req, res) {
    try {
        const { id } = req.params;
        const { availability } = req.body;

        if (!['Available', 'Sold', 'Rented'].includes(availability)) {
            return res.status(400).json({
                success: false,
                message: 'Availability must be Available, Sold, or Rented.'
            });
        }

        const [existing] = await pool.query('SELECT user_id, title FROM properties WHERE property_id = ?', [id]);
        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        if (existing[0].user_id !== req.user.user_id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access Denied: You do not have permission to change this property status.'
            });
        }

        await pool.query('UPDATE properties SET availability = ? WHERE property_id = ?', [availability, id]);
        await logActivity(req.user.user_id, 'Property Updated', `Changed availability of #${id} to ${availability}`);

        return res.status(200).json({
            success: true,
            message: `Property marked as ${availability}.`
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to update availability.'
        });
    }
}

// GET /api/my-properties (For Owner and Agent)
export async function getMyProperties(req, res) {
    try {
        const [properties] = await pool.query(`
            SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone,
                   (SELECT COUNT(*) FROM enquiries e WHERE e.property_id = p.property_id) as enquiry_count,
                   (SELECT COUNT(*) FROM favorites f WHERE f.property_id = p.property_id) as favorite_count
            FROM properties p
            JOIN users u ON p.user_id = u.user_id
            WHERE p.user_id = ?
            ORDER BY p.created_at DESC
        `, [req.user.user_id]);

        const populated = await populatePropertyDetails(properties, req.user.user_id);

        return res.status(200).json({
            success: true,
            data: populated
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve your properties.'
        });
    }
}

// GET /api/amenities (List all available amenities)
export async function getAmenities(req, res) {
    try {
        const [amenities] = await pool.query('SELECT * FROM amenities ORDER BY name ASC');
        return res.status(200).json({
            success: true,
            data: amenities
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve amenities.'
        });
    }
}

// GET /api/properties/:id/similar (Fetch up to 3 similar verified properties)
export async function getSimilarProperties(req, res) {
    try {
        const { id } = req.params;
        const [target] = await pool.query('SELECT property_id, location, property_type, price FROM properties WHERE property_id = ?', [id]);
        if (target.length === 0) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }
        const current = target[0];

        // Find up to 3 similar verified properties (same property type or similar location, excluding current)
        const [similar] = await pool.query(`
            SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.role as owner_role
            FROM properties p
            JOIN users u ON p.user_id = u.user_id
            WHERE p.property_id != ? 
              AND p.verification_status = 'Verified'
              AND p.availability = 'Available'
              AND (p.property_type = ? OR p.location LIKE ?)
            ORDER BY 
              CASE WHEN p.property_type = ? AND p.location LIKE ? THEN 1
                   WHEN p.property_type = ? THEN 2
                   ELSE 3
              END,
              p.price ASC
            LIMIT 3
        `, [id, current.property_type, `%${current.location}%`, current.property_type, `%${current.location}%`, current.property_type]);

        const currentUserId = req.user ? req.user.user_id : null;
        const populated = await populatePropertyDetails(similar, currentUserId);

        return res.status(200).json({
            success: true,
            data: populated
        });
    } catch (error) {
        console.error('Error fetching similar properties:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve similar properties.'
        });
    }
}


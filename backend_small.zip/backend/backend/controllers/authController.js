import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pool from '../config/db.js';
import { logActivity } from '../utils/activityLogger.js';

const JWT_SECRET = process.env.JWT_SECRET || 'property_portal_jwt_super_secret_key_2026_secure';

export async function register(req, res) {
    try {
        const { name, email, password, role, phone } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Name, email, and password are required.'
            });
        }

        // Validate role - strictly disallow public registration as admin
        const validRoles = ['user', 'owner', 'agent'];
        let assignedRole = 'user';
        if (role) {
            if (role === 'admin') {
                return res.status(403).json({
                    success: false,
                    message: 'Registration as Admin is strictly restricted.'
                });
            }
            if (validRoles.includes(role.toLowerCase())) {
                assignedRole = role.toLowerCase();
            }
        }

        // Check if user already exists
        const [existing] = await pool.query('SELECT user_id FROM users WHERE email = ?', [email.trim().toLowerCase()]);
        if (existing.length > 0) {
            return res.status(409).json({
                success: false,
                message: 'An account with this email already exists.'
            });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Insert user
        const [result] = await pool.query(
            'INSERT INTO users (name, email, password, role, phone) VALUES (?, ?, ?, ?, ?)',
            [name.trim(), email.trim().toLowerCase(), hashedPassword, assignedRole, phone || null]
        );

        const newUserId = result.insertId;

        // Log activity
        await logActivity(newUserId, 'User Registered', `New ${assignedRole} registered: ${name} (${email})`);

        // Generate JWT
        const token = jwt.sign(
            { user_id: newUserId, role: assignedRole },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        return res.status(201).json({
            success: true,
            message: 'Account registered successfully!',
            data: {
                user: {
                    user_id: newUserId,
                    name: name.trim(),
                    email: email.trim().toLowerCase(),
                    role: assignedRole,
                    phone: phone || null
                },
                token
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error during registration. Please try again.'
        });
    }
}

export async function login(req, res) {
    try {
        const { email, password, portal } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email and password are required.'
            });
        }

        const [users] = await pool.query(
            'SELECT user_id, name, email, password, role, phone, created_at FROM users WHERE email = ?',
            [email.trim().toLowerCase()]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        const user = users[0];

        // Verify password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        // Check portal authorization:
        // If attempting Admin login portal, user MUST have role 'admin'
        if (portal === 'admin' && user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'This account does not have Admin privileges.'
            });
        }

        // Log login activity
        await logActivity(user.user_id, 'User Login', `${user.name} (${user.role}) logged in via ${portal || 'general'} portal`);

        // Generate JWT
        const token = jwt.sign(
            { user_id: user.user_id, role: user.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        return res.status(200).json({
            success: true,
            message: 'Login successful!',
            data: {
                user: {
                    user_id: user.user_id,
                    name: user.name,
                    email: user.email,
                    role: user.role,
                    phone: user.phone,
                    created_at: user.created_at
                },
                token
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        return res.status(500).json({
            success: false,
            message: 'Server error during login. Please try again.'
        });
    }
}

export async function getMe(req, res) {
    try {
        return res.status(200).json({
            success: true,
            message: 'Current profile retrieved.',
            data: {
                user: req.user
            }
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Server error retrieving profile.'
        });
    }
}

export async function updateProfile(req, res) {
    try {
        const { name, phone } = req.body;
        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Name is required.'
            });
        }

        await pool.query(
            'UPDATE users SET name = ?, phone = ? WHERE user_id = ?',
            [name.trim(), phone || null, req.user.user_id]
        );

        const [updated] = await pool.query(
            'SELECT user_id, name, email, role, phone, created_at FROM users WHERE user_id = ?',
            [req.user.user_id]
        );

        await logActivity(req.user.user_id, 'Profile Updated', `User ${name} updated profile details`);

        return res.status(200).json({
            success: true,
            message: 'Profile updated successfully.',
            data: {
                user: updated[0]
            }
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to update profile.'
        });
    }
}

export async function changePassword(req, res) {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Current password and new password are required.'
            });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'New password must be at least 6 characters long.'
            });
        }

        const [users] = await pool.query('SELECT password FROM users WHERE user_id = ?', [req.user.user_id]);
        const isMatch = await bcrypt.compare(currentPassword, users[0].password);

        if (!isMatch) {
            return res.status(400).json({
                success: false,
                message: 'Current password is incorrect.'
            });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(newPassword, salt);

        await pool.query('UPDATE users SET password = ? WHERE user_id = ?', [hashedPassword, req.user.user_id]);
        await logActivity(req.user.user_id, 'Password Changed', `User changed password`);

        return res.status(200).json({
            success: true,
            message: 'Password changed successfully.'
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to change password.'
        });
    }
}

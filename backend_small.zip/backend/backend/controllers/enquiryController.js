import pool from '../config/db.js';
import { logActivity } from '../utils/activityLogger.js';

// POST /api/enquiries (User sends enquiry)
export async function createEnquiry(req, res) {
    try {
        const userId = req.user.user_id;
        const { property_id, name, email, phone, message } = req.body;

        if (!property_id || !message || !phone) {
            return res.status(400).json({
                success: false,
                message: 'Property, phone number, and message are required.'
            });
        }

        // Verify property exists
        const [prop] = await pool.query('SELECT property_id, title, user_id FROM properties WHERE property_id = ?', [property_id]);
        if (prop.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        const [result] = await pool.query(`
            INSERT INTO enquiries (user_id, property_id, name, email, phone, message, status)
            VALUES (?, ?, ?, ?, ?, ?, 'Pending')
        `, [
            userId,
            property_id,
            name || req.user.name,
            email || req.user.email,
            phone,
            message.trim()
        ]);

        await logActivity(
            userId,
            'Enquiry Created',
            `Enquiry sent by ${name || req.user.name} for property "${prop[0].title}"`
        );

        return res.status(201).json({
            success: true,
            message: 'Enquiry sent successfully! The owner/agent will contact you soon.',
            data: {
                enquiry_id: result.insertId
            }
        });
    } catch (error) {
        console.error('Create enquiry error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to send enquiry.'
        });
    }
}

// GET /api/enquiries (User's sent enquiries)
export async function getUserEnquiries(req, res) {
    try {
        const userId = req.user.user_id;

        const [enquiries] = await pool.query(`
            SELECT e.*, p.title as property_title, p.location as property_location, p.price, p.property_type,
                   u.name as owner_name, u.email as owner_email, u.phone as owner_phone
            FROM enquiries e
            JOIN properties p ON e.property_id = p.property_id
            JOIN users u ON p.user_id = u.user_id
            WHERE e.user_id = ?
            ORDER BY e.created_at DESC
        `, [userId]);

        return res.status(200).json({
            success: true,
            data: enquiries
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve enquiries.'
        });
    }
}

// GET /api/owner/enquiries (Enquiries received on Owner/Agent listings)
export async function getReceivedEnquiries(req, res) {
    try {
        const userId = req.user.user_id;

        const [enquiries] = await pool.query(`
            SELECT e.*, p.title as property_title, p.location as property_location, p.price,
                   u.name as sender_name, u.email as sender_email
            FROM enquiries e
            JOIN properties p ON e.property_id = p.property_id
            JOIN users u ON e.user_id = u.user_id
            WHERE p.user_id = ?
            ORDER BY e.created_at DESC
        `, [userId]);

        return res.status(200).json({
            success: true,
            data: enquiries
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve received enquiries.'
        });
    }
}

// PATCH /api/enquiries/:id/status (Update enquiry status)
export async function updateEnquiryStatus(req, res) {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!['Pending', 'Contacted', 'Closed'].includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Status must be Pending, Contacted, or Closed.'
            });
        }

        // Check ownership of the property for this enquiry
        const [enquiry] = await pool.query(`
            SELECT e.enquiry_id, p.user_id as property_owner_id
            FROM enquiries e
            JOIN properties p ON e.property_id = p.property_id
            WHERE e.enquiry_id = ?
        `, [id]);

        if (enquiry.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Enquiry not found.'
            });
        }

        if (enquiry[0].property_owner_id !== req.user.user_id && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access Denied: You cannot update enquiries for properties you do not own.'
            });
        }

        await pool.query('UPDATE enquiries SET status = ? WHERE enquiry_id = ?', [status, id]);

        return res.status(200).json({
            success: true,
            message: `Enquiry marked as ${status}.`
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to update enquiry status.'
        });
    }
}

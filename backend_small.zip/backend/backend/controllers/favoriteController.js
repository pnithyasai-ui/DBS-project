import pool from '../config/db.js';
import { formatIndianPrice } from '../utils/formatters.js';

export async function getFavorites(req, res) {
    try {
        const userId = req.user.user_id;

        const [favorites] = await pool.query(`
            SELECT f.favorite_id, f.created_at as favorited_at, p.*,
                   u.name as owner_name, u.email as owner_email, u.phone as owner_phone
            FROM favorites f
            JOIN properties p ON f.property_id = p.property_id
            JOIN users u ON p.user_id = u.user_id
            WHERE f.user_id = ?
            ORDER BY f.created_at DESC
        `, [userId]);

        if (favorites.length === 0) {
            return res.status(200).json({
                success: true,
                data: []
            });
        }

        // Attach primary images
        const propIds = favorites.map(f => f.property_id);
        const [images] = await pool.query(
            `SELECT property_id, image_url, is_primary FROM property_images WHERE property_id IN (${propIds.map(() => '?').join(',')})`,
            propIds
        );

        const enriched = favorites.map(fav => {
            const propImages = images.filter(img => img.property_id === fav.property_id);
            return {
                ...fav,
                formatted_price: formatIndianPrice(fav.price),
                primary_image: propImages.length > 0 ? propImages[0].image_url : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=80',
                is_favorite: true
            };
        });

        return res.status(200).json({
            success: true,
            data: enriched
        });
    } catch (error) {
        console.error('Error fetching favorites:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to fetch favorites.'
        });
    }
}

export async function addFavorite(req, res) {
    try {
        const userId = req.user.user_id;
        const { propertyId } = req.params;

        // Verify property exists
        const [prop] = await pool.query('SELECT property_id, title FROM properties WHERE property_id = ?', [propertyId]);
        if (prop.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Property not found.'
            });
        }

        // Insert ignore
        await pool.query(
            'INSERT IGNORE INTO favorites (user_id, property_id) VALUES (?, ?)',
            [userId, propertyId]
        );

        return res.status(201).json({
            success: true,
            message: 'Property saved to favorites!'
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to add favorite.'
        });
    }
}

export async function removeFavorite(req, res) {
    try {
        const userId = req.user.user_id;
        const { propertyId } = req.params;

        await pool.query(
            'DELETE FROM favorites WHERE user_id = ? AND property_id = ?',
            [userId, propertyId]
        );

        return res.status(200).json({
            success: true,
            message: 'Property removed from favorites.'
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: 'Failed to remove favorite.'
        });
    }
}

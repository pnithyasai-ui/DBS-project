const BASE_URL = 'http://localhost:5000/api';

async function runTests() {
    console.log('==============================================');
    console.log('RUNNING AUTOMATED PROPERTYPORTAL API TESTS');
    console.log('==============================================\n');

    let passed = 0;
    let failed = 0;

    function assert(condition, testName) {
        if (condition) {
            console.log(` PASS: ${testName}`);
            passed++;
        } else {
            console.error(`❌ FAIL: ${testName}`);
            failed++;
        }
    }

    // Helper for requests
    async function request(path, options = {}) {
        const url = `${BASE_URL}${path}`;
        const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
        const res = await fetch(url, {
            ...options,
            headers,
            body: options.body ? JSON.stringify(options.body) : undefined
        });
        const data = await res.json().catch(() => ({}));
        return { status: res.status, ok: res.ok, data };
    }

    // 1. Health check
    try {
        const health = await request('/health');
        assert(health.data.success === true, 'Backend health check responds with success: true');
    } catch (e) {
        assert(false, 'Backend health check failed: ' + e.message);
    }

    // 2. Security Test: Reject public registration with role="admin"
    try {
        const res = await request('/auth/register', {
            method: 'POST',
            body: {
                name: 'Hacker',
                email: 'hacker@test.com',
                password: 'password123',
                role: 'admin'
            }
        });
        assert(res.status === 403, 'Public registration with role="admin" returns 403 Forbidden');
    } catch (err) {
        assert(false, 'Security test failed');
    }

    // 3. Login for all 4 roles
    let adminToken, ownerToken, agentToken, userToken;

    try {
        const adminRes = await request('/auth/login', {
            method: 'POST',
            body: { email: 'admin@propertyportal.com', password: 'admin123', portal: 'admin' }
        });
        adminToken = adminRes.data.data?.token;
        assert(adminRes.data.data?.user.role === 'admin', 'Admin login successful and role is admin');

        const ownerRes = await request('/auth/login', {
            method: 'POST',
            body: { email: 'owner@propertyportal.com', password: 'owner123', portal: 'owner' }
        });
        ownerToken = ownerRes.data.data?.token;
        assert(ownerRes.data.data?.user.role === 'owner', 'Owner login successful and role is owner');

        const agentRes = await request('/auth/login', {
            method: 'POST',
            body: { email: 'agent@propertyportal.com', password: 'agent123', portal: 'agent' }
        });
        agentToken = agentRes.data.data?.token;
        assert(agentRes.data.data?.user.role === 'agent', 'Agent login successful and role is agent');

        const userRes = await request('/auth/login', {
            method: 'POST',
            body: { email: 'user@propertyportal.com', password: 'user123', portal: 'user' }
        });
        userToken = userRes.data.data?.token;
        assert(userRes.data.data?.user.role === 'user', 'User login successful and role is user');
    } catch (e) {
        assert(false, 'Login tests failed: ' + e.message);
    }

    // 4. Portal Security: Owner tries Admin Login Portal -> Rejected with 403
    try {
        const res = await request('/auth/login', {
            method: 'POST',
            body: { email: 'owner@propertyportal.com', password: 'owner123', portal: 'admin' }
        });
        assert(
            res.status === 403 && res.data?.message.includes('Admin privileges'),
            'Owner attempting Admin login portal rejected with "This account does not have Admin privileges."'
        );
    } catch (err) {
        assert(false, 'Portal security test failed');
    }

    // 5. Backend Admin Security: User/Owner calling Admin API directly -> 403 Forbidden
    try {
        const userAdminReq = await request('/admin/dashboard', {
            headers: { Authorization: `Bearer ${userToken}` }
        });
        assert(userAdminReq.status === 403, 'Normal user calling /api/admin/dashboard receives 403 Forbidden');

        const ownerAdminReq = await request('/admin/dashboard', {
            headers: { Authorization: `Bearer ${ownerToken}` }
        });
        assert(ownerAdminReq.status === 403, 'Owner calling /api/admin/dashboard receives 403 Forbidden');

        const adminDash = await request('/admin/dashboard', {
            headers: { Authorization: `Bearer ${adminToken}` }
        });
        assert(adminDash.data.success === true && adminDash.data.data.total_properties > 0, 'Admin can access /api/admin/dashboard with real metrics');
    } catch (err) {
        assert(false, 'Admin security tests failed: ' + err.message);
    }

    // 6. Search Tests: Property Types
    try {
        // Apartments only
        const apts = await request('/properties?propertyType=Apartment');
        const allApts = apts.data.data.properties.every(p => p.property_type === 'Apartment');
        assert(allApts && apts.data.data.properties.length > 0, 'Filter propertyType=Apartment returns only Apartments');

        // Villas only
        const villas = await request('/properties?propertyType=Villa');
        const allVillas = villas.data.data.properties.every(p => p.property_type === 'Villa');
        assert(allVillas && villas.data.data.properties.length > 0, 'Filter propertyType=Villa returns only Villas');

        // Lands & Plots
        const lands = await request('/properties?propertyType=Lands%20%26%20Plots');
        const allLands = lands.data.data.properties.every(p => ['Residential Plot', 'Agricultural Land', 'Commercial Plot'].includes(p.property_type));
        assert(allLands && lands.data.data.properties.length > 0, 'Filter propertyType=Lands & Plots returns only land/plot listings');
    } catch (err) {
        assert(false, 'Property type search failed: ' + err.message);
    }

    // 7. Budget Tests: Indian budget brackets
    try {
        // Under 25 Lakhs (0 - 2,500,000)
        const b1 = await request('/properties?budget=under_25_lakhs');
        const allB1 = b1.data.data.properties.every(p => Number(p.price) <= 2500000);
        assert(allB1 && b1.data.data.properties.length > 0, 'Budget "Under ₹25 Lakhs" returns only properties <= 25,00,000');

        // ₹50–75 Lakhs (5,000,000 - 7,500,000)
        const b3 = await request('/properties?budget=50_75_lakhs');
        const allB3 = b3.data.data.properties.every(p => Number(p.price) >= 5000000 && Number(p.price) <= 7500000);
        assert(allB3 && b3.data.data.properties.length > 0, 'Budget "₹50–75 Lakhs" returns only matching properties');

        // ₹1–2 Crore (10,000,000 - 20,000,000)
        const b5 = await request('/properties?budget=1_2_crore');
        const allB5 = b5.data.data.properties.every(p => Number(p.price) >= 10000000 && Number(p.price) <= 20000000);
        assert(allB5 && b5.data.data.properties.length > 0, 'Budget "₹1–2 Crore" returns only matching properties');
    } catch (err) {
        assert(false, 'Budget tests failed: ' + err.message);
    }

    // 8. Combined Filters Testing
    try {
        // Hyderabad + Apartment + ₹50–75 Lakhs + 2 Bedrooms
        const combined = await request('/properties?location=Hyderabad&propertyType=Apartment&budget=50_75_lakhs&bedrooms=2');
        const match = combined.data.data.properties.every(p => 
            p.location.toLowerCase().includes('hyderabad') &&
            p.property_type === 'Apartment' &&
            Number(p.price) >= 5000000 && Number(p.price) <= 7500000 &&
            p.bedrooms === 2
        );
        assert(match && combined.data.data.properties.length > 0, 'Combined filter (Hyderabad + Apartment + ₹50-75L + 2 BHK) returns only matching properties');

        // Partial Location Search: "Bach" matches "Bachupally"
        const partial = await request('/properties?location=Bach');
        const allBach = partial.data.data.properties.every(p => p.location.includes('Bachupally'));
        assert(allBach && partial.data.data.properties.length > 0, 'Partial location search "Bach" finds "Bachupally"');
    } catch (err) {
        assert(false, 'Combined filters failed: ' + err.message);
    }

    // 9. Property Ownership Security: Owner B trying to edit Owner A's property
    try {
        // Get owner 1 properties
        const myProps = await request('/properties/my-properties', {
            headers: { Authorization: `Bearer ${ownerToken}` }
        });
        const propToTest = myProps.data.data[0];

        // Login as Owner 2 (Sunita)
        const owner2Res = await request('/auth/login', {
            method: 'POST',
            body: { email: 'sunita.owner@propertyportal.com', password: 'owner123' }
        });
        const owner2Token = owner2Res.data.data?.token;

        // Owner 2 tries to edit Owner 1's property
        const editAttempt = await request(`/properties/${propToTest.property_id}`, {
            method: 'PUT',
            headers: { Authorization: `Bearer ${owner2Token}` },
            body: { title: 'Hacked Property Title' }
        });
        assert(editAttempt.status === 403, 'Owner 2 attempting to edit Owner 1 property receives 403 Forbidden');
    } catch (err) {
        assert(false, 'Ownership security test failed: ' + err.message);
    }

    // 10. Favorites & Enquiries
    try {
        const allProps = await request('/properties');
        const sampleProp = allProps.data.data.properties[0];

        // User adds favorite
        const addFav = await request(`/favorites/${sampleProp.property_id}`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${userToken}` }
        });
        assert(addFav.data.success === true, 'User can add property to favorites');

        // User checks favorites
        const myFavs = await request('/favorites', {
            headers: { Authorization: `Bearer ${userToken}` }
        });
        const hasFav = myFavs.data.data.some(f => f.property_id === sampleProp.property_id);
        assert(hasFav, 'Property is listed in user favorites');

        // User sends enquiry
        const enquiry = await request('/enquiries', {
            method: 'POST',
            headers: { Authorization: `Bearer ${userToken}` },
            body: {
                property_id: sampleProp.property_id,
                name: 'Vikram Reddy',
                email: 'user@propertyportal.com',
                phone: '+91 9988776655',
                message: 'Hello, is this property available for visit tomorrow?'
            }
        });
        assert(enquiry.data.success === true, 'User can send enquiry to property seller');
    } catch (err) {
        assert(false, 'Favorites/Enquiries test failed: ' + err.message);
    }

    console.log('\n==============================================');
    console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
    console.log('==============================================\n');
}

runTests();

import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT) : 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_NAME || 'property_portal',
    waitForConnections: true,
    connectionLimit: 15,
    queueLimit: 0,
    decimalNumbers: true
});

// Test connection on startup
(async () => {
    try {
        const connection = await pool.getConnection();
        console.log(` MySQL Pool connected successfully to database '${process.env.DB_NAME || 'property_portal'}'`);
        connection.release();
    } catch (err) {
        console.error(' MySQL Pool connection failed:', err.message);
    }
})();

export default pool;

import express from 'express';
import {
    getProperties,
    getFeaturedProperties,
    getPopularLocations,
    getPropertyById,
    createProperty,
    updateProperty,
    deleteProperty,
    updateAvailability,
    getMyProperties,
    getAmenities,
    getSimilarProperties
} from '../controllers/propertyController.js';
import { authenticateToken, optionalAuth, requireOwnerOrAgent } from '../middleware/auth.js';

const router = express.Router();

// Public & optional auth routes
router.get('/', optionalAuth, getProperties);
router.get('/featured', optionalAuth, getFeaturedProperties);
router.get('/locations', getPopularLocations);
router.get('/amenities', getAmenities);
router.get('/my-properties', authenticateToken, requireOwnerOrAgent, getMyProperties);
router.get('/:id/similar', optionalAuth, getSimilarProperties);
router.get('/:id', optionalAuth, getPropertyById);

// Protected routes (Owner / Agent / Admin)
router.post('/', authenticateToken, requireOwnerOrAgent, createProperty);
router.put('/:id', authenticateToken, requireOwnerOrAgent, updateProperty);
router.delete('/:id', authenticateToken, requireOwnerOrAgent, deleteProperty);
router.patch('/:id/availability', authenticateToken, requireOwnerOrAgent, updateAvailability);

export default router;

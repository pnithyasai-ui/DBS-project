import express from 'express';
import { createEnquiry, getUserEnquiries, getReceivedEnquiries, updateEnquiryStatus } from '../controllers/enquiryController.js';
import { authenticateToken, requireOwnerOrAgent } from '../middleware/auth.js';

const router = express.Router();

router.use(authenticateToken);

router.post('/', createEnquiry);
router.get('/', getUserEnquiries);
router.get('/received', requireOwnerOrAgent, getReceivedEnquiries);
router.patch('/:id/status', requireOwnerOrAgent, updateEnquiryStatus);

export default router;

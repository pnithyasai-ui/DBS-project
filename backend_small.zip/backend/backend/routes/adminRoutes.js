import express from 'express';
import {
    getAdminDashboardStats,
    getAdminAnalytics,
    getAllUsers,
    updateUserRole,
    getAllAdminProperties,
    approveProperty,
    rejectProperty,
    getActivityLogs,
    getAllEnquiries
} from '../controllers/adminController.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Enforce authentication AND admin role for all admin routes
router.use(authenticateToken, requireAdmin);

router.get('/dashboard', getAdminDashboardStats);
router.get('/analytics', getAdminAnalytics);
router.get('/users', getAllUsers);
router.patch('/users/:id/role', updateUserRole);
router.get('/properties', getAllAdminProperties);
router.put('/properties/:id/approve', approveProperty);
router.put('/properties/:id/reject', rejectProperty);
router.get('/activity', getActivityLogs);
router.get('/enquiries', getAllEnquiries);

export default router;

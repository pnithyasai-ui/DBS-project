import jwt from 'jsonwebtoken';
import pool from '../config/db.js';

export async function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

    if (!token) {
        return res.status(401).json({
            success: false,
            message: 'Authentication required. Please log in.'
        });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'property_portal_jwt_super_secret_key_2026_secure');
        
        // Fetch fresh user data from DB to ensure role is always accurate
        const [users] = await pool.query(
            'SELECT user_id, name, email, role, phone FROM users WHERE user_id = ?',
            [decoded.user_id]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'User account no longer exists.'
            });
        }

        req.user = users[0];
        next();
    } catch (err) {
        return res.status(401).json({
            success: false,
            message: 'Invalid or expired session. Please log in again.'
        });
    }
}

export async function optionalAuth(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

    if (!token) {
        req.user = null;
        return next();
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'property_portal_jwt_super_secret_key_2026_secure');
        const [users] = await pool.query(
            'SELECT user_id, name, email, role, phone FROM users WHERE user_id = ?',
            [decoded.user_id]
        );
        req.user = users.length > 0 ? users[0] : null;
    } catch (err) {
        req.user = null;
    }
    next();
}

export function requireRole(...allowedRoles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentication required.'
            });
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: `Access Denied: This action requires one of the following roles: [${allowedRoles.join(', ')}].`
            });
        }

        next();
    };
}

export function requireAdmin(req, res, next) {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            message: 'Authentication required.'
        });
    }

    if (req.user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            message: 'Access Denied: This account does not have Admin privileges.'
        });
    }

    next();
}

export function requireOwnerOrAgent(req, res, next) {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            message: 'Authentication required.'
        });
    }

    if (!['owner', 'agent', 'admin'].includes(req.user.role)) {
        return res.status(403).json({
            success: false,
            message: 'Access Denied: Only Owners and Agents can list and manage properties.'
        });
    }

    next();
}
